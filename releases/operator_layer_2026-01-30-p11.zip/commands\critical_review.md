---
name: critical_review
description: Emergency review - Security + Concurrency only. Fast triage for urgent issues.
---

# /critical_review

Run ONLY:
- `jh-security`
- `jh-concurrency`

Then merge:
- Top risks (ranked)
- Minimum-diff patch plan
- Proof commands + output excerpts
