# Document Generation Command

## Trigger
User runs `/docs` or asks for any legal document generation.

## What This Does
Loads the document generation context and router for creating and filing legal documents.

## Document Types Available
| Command | Document | Example |
|---------|----------|---------|
| `/docs lor` | Letter of Representation | `/docs lor Morgan 26-400327 montgomery` |
| `/docs alr` | ALR Hearing Request | `/docs alr Smith` |
| `/docs waiver` | Waiver of Arraignment | `/docs waiver Morgan 26-400327 montgomery` |
| `/docs contract` | Fee Agreement | `/docs contract Smith 26-123456 harris 3500 1500` |
| `/docs invoice` | Retainer Invoice | `/docs invoice Smith 26-123456 3500 1500` |

## Usage

### Quick Generation (parse from args)
```
/docs lor [name] [cause_number] [county]
/docs contract [name] [cause_number] [county] [flat_fee] [down_payment]
```

### Interactive (no args)
```
/docs
```
Then Claude will ask what document you need.

## Implementation

When this command runs:

1. **Parse arguments** (if provided):
   - First arg = document type (lor, alr, waiver, contract, invoice)
   - Remaining args = document-specific parameters

2. **If no args or incomplete**, ask the user:
   - What document type?
   - Client name or case number?
   - County?
   - Any additional required fields

3. **Look up client data** from Supabase if only partial info provided

4. **Generate the document** using the router:
```python
import sys
sys.path.insert(0, r"C:\AI_CORE\v4")
from core.document_router import get_router, process_request

router = get_router()

# Option 1: Natural language
result = router.from_request("Generate LOR for Morgan case 26-400327 in Montgomery")

# Option 2: Structured
result = router.generate(
    doc_type='lor',
    client_name='Matthew Morgan',
    cause_number='26-400327',
    county='montgomery'
)
```

5. **Report results** to user:
   - Document path
   - Any warnings or notes
   - Next steps (e.g., "Ready to file? Run `/docs file`")

6. **Filing** (if requested):
```python
result = router.file(
    doc_type='lor',
    document_path=path,
    cause_number='26-400327',
    county='montgomery',
    defendant_last_name='Morgan'
)
```

## Filing Support by County

| County | LOR | Waiver | ALR |
|--------|-----|--------|-----|
| Montgomery | ProDocFile e-file | ProDocFile e-file | Fax to DPS |
| Harris | Manual | Manual | Fax to DPS |
| Fort Bend | Manual | Manual | Fax to DPS |

## Output Locations
- Generated documents: `C:\AI_CORE\v4\data\lor_documents\`
- Templates: `C:\AI_CORE\v4\templates\`

## Examples

**Generate LOR**:
```
User: /docs lor
Claude: What's the client name and case number?
User: Morgan, 26-400327, Montgomery
Claude: Generated LOR for Matthew Morgan. Saved to C:\AI_CORE\v4\data\lor_documents\LOR_Morgan_26-400327_20260123.pdf
```

**Generate and File**:
```
User: Generate and file an LOR for the Morgan case
Claude: [Generates document]
Claude: [Opens browser, navigates ProDocFile]
Claude: Filing prepared. Browser at submit page - review and click Submit.
```

**Fee Agreement**:
```
User: /docs contract
Claude: I need: client name, case number, county, charge, flat fee, down payment
User: John Smith, 26-999999, Montgomery, DWI, $3500 flat, $1500 down
Claude: Generated fee agreement. Saved to C:\AI_CORE\v4\data\lor_documents\FEE_AGREEMENT_Smith_26-999999.pdf
```
