---
name: save_context
description: Save current session state to JSON for continuation in a future thread.
operator_layer_version: 2026-01-30-p8
---

# /save_context

Persist the current session state so the next thread can pick up where you left off.

## What Gets Saved

Write to `C:\Users\J\.claude\context\latest.json`:

```json
{
  "timestamp": "2026-01-30T10:30:00",
  "operator_layer_version": "2026-01-30",
  "project_loader": "/jhornlaw|/distress|/dfs|none",
  "execution_mode": "review_only|patch_plan|patch_apply|emergency",
  "project_path": "C:\\AI_CORE\\v4",
  "initiative_level": 2,
  "target": "repo_root|<path>|changed_since_commit",
  "last_commands": [
    "/boot",
    "/jhornlaw",
    "/execute_full_plan"
  ],
  "current_objective": "User-stated goal for this session",
  "work_completed": [
    "Fixed retry logic in core/retry.py",
    "Added timeout to HTTP calls"
  ],
  "next_actions": [
    "Run tests to verify fixes",
    "Update documentation"
  ],
  "open_questions": [
    "Should we add jitter to backoff?"
  ],
  "files_modified": [
    "core/retry.py",
    "core/http_client.py"
  ],
  "notes": "Any additional context for next session"
}
```

## How to Use

At end of session, say:
- "save context"
- "/save_context"
- "save session"

Claude will:
1. Summarize what was accomplished
2. List pending next actions
3. Note any open questions
4. Write the JSON file (atomic write)
5. Create timestamped archive (always)
6. Update memory bundle if in managed repo (Phase 3)

---

## Write-Back Process

### Step 1: Gather session state

Collect from current session:
- `project_loader`: Active loader or "none"
- `execution_mode`: Current mode
- `project_path`: Working directory
- `current_objective`: User's stated goal
- `work_completed`: Items finished this session
- `next_actions`: Pending tasks
- `open_questions`: Unresolved questions
- `files_modified`: Files touched
- `notes`: Freeform context

### Step 2: Generate timestamp (CRITICAL - capture ONCE at runtime)

**This is the single source of truth for the session timestamp.**

```powershell
powershell -Command "Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'"
```

**IMPORTANT:** Capture this value ONCE and use it for:
1. The `timestamp` field in latest.json
2. The archive filename
3. All bundle file entries

Store as `$SESSION_TIMESTAMP` (conceptually). Example: `2026-01-30T14:25:00`

Derive archive filename: `session_20260130_1425.json` (from same timestamp)

### Step 2.5: Machine Identifier (Phase 8)

**Get or create machine_id for conflict resolution tracking.**

Check if machine_id.txt exists:
```powershell
powershell -Command "if (Test-Path 'C:\Users\J\.claude\context\machine_id.txt') { Get-Content 'C:\Users\J\.claude\context\machine_id.txt' -Raw } else { $id = [guid]::NewGuid().ToString(); Set-Content -Path 'C:\Users\J\.claude\context\machine_id.txt' -Value $id; $id }"
```

Store as `$MACHINE_ID` (conceptually). Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

**Display shortened ID in output:** First 8 characters only (e.g., `a1b2c3d4`)

**Purpose:** When multiple machines sync to same context directory (OneDrive/Dropbox), the machine_id helps identify which machine wrote which context file. This is a sidecar file (not in JSON schema) to maintain backward compatibility.

### Step 3: Build and Write latest.json (atomic)

**Step 3.1: Build JSON with captured timestamp**

Construct the JSON object using `$SESSION_TIMESTAMP` for the `timestamp` field:

```json
{
  "timestamp": "<$SESSION_TIMESTAMP>",  // MUST be the captured runtime value
  "operator_layer_version": "2026-01-30-p4",
  ...
}
```

**Step 3.2: Atomic write**

Write to temp file first, then move:
```powershell
# Write to temp (use Write tool or Set-Content)
# Atomic move (overwrites existing)
powershell -Command "Move-Item -Force 'C:\Users\J\.claude\context\latest.json.tmp' 'C:\Users\J\.claude\context\latest.json'"
```

**Step 3.3: Post-write verification (MANDATORY)**

After the atomic move, verify the write succeeded:

```powershell
powershell -Command "(Get-Content 'C:\Users\J\.claude\context\latest.json' -Raw | ConvertFrom-Json).timestamp"
```

**Compare output to `$SESSION_TIMESTAMP`:**

- **If match:** Write succeeded. Continue to Step 4.
- **If mismatch or error:** Write failed.

**On write failure:**
```
── WRITEBACK ───────────────────────────
status: FAILED
reason: timestamp mismatch after write
expected: <$SESSION_TIMESTAMP>
actual: <read value>
path: C:\Users\J\.claude\context\latest.json

RECOVERY:
1. Restore from newest archive: dir C:\Users\J\.claude\context\session_*.json
2. Rerun /save_context
3. Check disk/permissions if repeated failures
─────────────────────────────────────────
```
**STOP. Do not proceed to archive or bundle.**

**Step 3.4: Schema validation (Phase 5)**

Verify the written JSON will pass /boot validation:

```powershell
powershell -Command "try { $j = Get-Content 'C:\Users\J\.claude\context\latest.json' | ConvertFrom-Json; if (-not $j.timestamp) { 'MISSING_TIMESTAMP' } elseif (-not [DateTime]::TryParse($j.timestamp, [ref]$null)) { 'INVALID_TIMESTAMP' } else { 'VALID' } } catch { 'PARSE_ERROR' }"
```

**If not VALID:**
```
── WRITEBACK ───────────────────────────
status: FAILED
reason: schema validation failed (<result>)
path: C:\Users\J\.claude\context\latest.json

The written JSON would not pass /boot validation.
This is a bug in /save_context JSON generation.

RECOVERY:
1. Restore from newest archive: dir C:\Users\J\.claude\context\session_*.json
2. Report bug in save_context.md
─────────────────────────────────────────
```
**STOP. Do not proceed to archive or bundle.**

**If VALID:** Continue to Step 4.

### Step 4: Create timestamped archive (MANDATORY)

Always create an archive copy using the same timestamp:

```powershell
powershell -Command "Copy-Item 'C:\Users\J\.claude\context\latest.json' 'C:\Users\J\.claude\context\session_<YYYYMMDD_HHMM>.json'"
```

Derive filename from `$SESSION_TIMESTAMP`: `2026-01-30T14:25:00` → `session_20260130_1425.json`

### Step 4.5: Write latest.pointer (Phase 8)

**Write a pointer file containing the newest archive filename.**

```powershell
powershell -Command "Set-Content -Path 'C:\Users\J\.claude\context\latest.pointer' -Value 'session_<YYYYMMDD_HHMM>.json'"
```

**Purpose:** Sync tools sometimes conflict on mutable JSON files. The pointer file is simpler and easier to reconcile—it just contains the filename of the newest valid archive. If latest.json becomes corrupted or conflicted, the pointer can help identify which archive to restore.

**Format:** Single line containing archive filename (e.g., `session_20260130_1425.json`)

### Step 5: Memory Bundle Write-Back (Phase 3)

**After JSON write succeeds**, attempt memory bundle update.

#### Step 5.1: Detect Managed Repo

Check if current project is a managed repo:
```powershell
powershell -Command "Test-Path '<project_path>\.claude\rules'"
```

**If `False`:** Skip bundle, set `memory_bundle: SKIPPED (not a managed repo)`

**If `True`:** Continue to Step 5.2

#### Step 5.2: Ensure .claude/memory/ exists

```powershell
powershell -Command "New-Item -ItemType Directory -Force -Path '<project_path>\.claude\memory'"
```

#### Step 5.3: Initialize missing bundle files

For each file that doesn't exist, create from template:

| File | Template |
|------|----------|
| `progress.md` | See template below |
| `decisions.md` | See template below |
| `verified.md` | See template below |
| `runbook.md` | See template below |
| `context.md` | See template below |
| `proof.md` | See template below |

#### Step 5.4: Append entries to bundle files

**progress.md** - Always append if `work_completed` has items:
```markdown

### [YYYY-MM-DD HH:MM] session_YYYYMMDD_HHMM

**Objective:** <current_objective>

**Completed:**
- <work_completed item 1>
- <work_completed item 2>

**Next:** <next_actions count> pending actions

---
```

**decisions.md** - Append only if session included explicit decisions (check `notes` for "DECISION:" prefix or similar patterns):
```markdown

### [YYYY-MM-DD HH:MM] session_YYYYMMDD_HHMM

- **Decision:** <extracted decision>
- **Rationale:** <extracted rationale>
- **Source:** session_YYYYMMDD_HHMM.json

---
```

**verified.md** - Append only if session included verified facts with proof (check `notes` for "VERIFIED:" prefix):
```markdown

### [YYYY-MM-DD HH:MM] session_YYYYMMDD_HHMM

- **Fact:** <extracted fact>
- **Proof:** <proof reference or "see session JSON">
- **Source:** session_YYYYMMDD_HHMM.json

---
```

**runbook.md** - Append only if session included failure/recovery patterns (check `notes` for "RUNBOOK:" or "FIX:" prefix):
```markdown

### [YYYY-MM-DD HH:MM] session_YYYYMMDD_HHMM

- **Symptom:** <what failed>
- **Fix:** <how it was resolved>
- **Source:** session_YYYYMMDD_HHMM.json

---
```

**context.md** - Update ONLY when explicitly flagged with `UPDATE_CONTEXT: true` in notes. Otherwise skip.

**proof.md** - Write once if missing (stable spec, never appended).

#### Step 5.5: Verify marker appends (self-auditing)

For each marker that was processed (DECISION:/VERIFIED:/RUNBOOK:):

1. Re-read the target file
2. Search for the session ID (e.g., `session_20260130_1425`)
3. If found: marker write confirmed
4. If not found: mark as FAILED for that file

Track results for reporting.

#### Step 5.6: Count appends

Track how many entries were appended to each file for reporting.

### Step 6: Report WRITEBACK status

Print structured output:

```
── WRITEBACK ───────────────────────────
status: OK
timestamp: 2026-01-30T14:25:00
machine_id: a1b2c3d4 (first 8 chars)
verified: timestamp in latest.json matches expected

json:
  latest.json: OK (timestamp verified)
  archive: session_20260130_1425.json
  pointer: latest.pointer (updated)

memory_bundle: OK
  path: C:\Users\J\the_brain\.claude\memory\
  progress.md: +1 entry (3 items completed)
  decisions.md: +0 entries (no DECISION: markers)
  verified.md: +0 entries (no VERIFIED: markers)
  runbook.md: +0 entries (no RUNBOOK: markers)
  markers_audited: 0 processed, 0 verified

summary:
  project: /jhornlaw
  objective: <first 60 chars>...
  completed: 5 items
  next_actions: 3 items

To resume: run /boot (auto-rehydrates from latest.json)
─────────────────────────────────────────
```

**If bundle skipped (not managed repo):**
```
memory_bundle: SKIPPED (not a managed repo)
```

**If bundle partially failed:**
```
memory_bundle: PARTIAL
  path: C:\Users\J\the_brain\.claude\memory\
  progress.md: OK (+1 entry)
  decisions.md: FAILED (permission denied)
  verified.md: OK (+0 entries)
  runbook.md: OK (+0 entries)

RECOVERY: Check file permissions on .claude/memory/
```

---

## Error Handling

**If JSON write fails:**

```
── WRITEBACK ───────────────────────────
status: FAILED
reason: <error message>
path: C:\Users\J\.claude\context\latest.json

RECOVERY:
1. Check disk space: dir C:\Users\J\.claude\context\
2. Check permissions: icacls C:\Users\J\.claude\context\
3. Try manual save: copy context to clipboard

Your session state (copy this if needed):
<JSON content here>
─────────────────────────────────────────
```

**If archive fails but latest.json succeeded:**
Continue to memory bundle. Report archive as PARTIAL.

**If bundle fails but JSON succeeded:**
JSON is authoritative. Report bundle as PARTIAL/FAILED but don't block.

---

## Bundle File Templates

### progress.md (initial)
```markdown
# Progress Log

Append-only log of work completed per session.

---

```

### decisions.md (initial)
```markdown
# Decisions

Append-only log of decisions made with rationale.

To add: include "DECISION: <summary>" in session notes before /save_context.

---

```

### verified.md (initial)
```markdown
# Verified Facts

Append-only log of facts verified with proof.

To add: include "VERIFIED: <fact>" in session notes before /save_context.

Invariant: Treat entries here as truth until explicitly disproven.

---

```

### runbook.md (initial)
```markdown
# Runbook

Append-only log of failure patterns and fixes.

To add: include "RUNBOOK: <symptom> -> <fix>" in session notes before /save_context.

---

```

### context.md (initial)
```markdown
# Project Context

Static context about this project. Updated only when explicitly flagged.

## Purpose

<describe project purpose>

## Key Paths

<list important paths>

## Invariants

<list project invariants>

## Integrations

<list external integrations>

---

*To update: include "UPDATE_CONTEXT: true" in session notes before /save_context*
```

### proof.md (initial, stable)
```markdown
# Proof Format

Standard format for proving claims in this project.

## Required Elements

1. **Claim:** What is being verified
2. **Command:** Exact command run
3. **Output:** Raw output (or key excerpt)
4. **Interpretation:** What the output means
5. **Timestamp:** When verified

## Example

```
Claim: API endpoint returns 200 on valid request
Command: curl -s -o /dev/null -w "%{http_code}" https://api.example.com/health
Output: 200
Interpretation: Health check passes
Timestamp: 2026-01-30T10:30:00
```

## Proof Levels

| Level | Requirement |
|-------|-------------|
| **Strong** | Command + raw output + interpretation |
| **Medium** | Command + summary output |
| **Weak** | Assertion without command (avoid) |

---

*This file is stable and should not be modified session-to-session.*
```

---

## Archive Management

Archives accumulate in `C:\Users\J\.claude\context\session_*.json`.

**List recent archives:**
```powershell
powershell -Command "Get-ChildItem 'C:\Users\J\.claude\context\session_*.json' | Sort-Object LastWriteTime -Descending | Select-Object -First 10 Name, LastWriteTime"
```

**Cleanup old archives (optional, manual):**
```powershell
# Keep last 20 archives, delete older
powershell -Command "Get-ChildItem 'C:\Users\J\.claude\context\session_*.json' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 20 | Remove-Item"
```

---

## When to Use

- End of work session
- Before switching projects (use `/tangent` first)
- Before closing Claude Code
- At natural breakpoints in multi-day work
- After completing a significant milestone

---

## Relationship to /boot

- `/boot` automatically reads `latest.json` and displays a REHYDRATION block
- `/boot` also reports memory bundle presence (non-blocking diagnostic)
- `/save_context` writes to `latest.json` + archive + memory bundle
- This forms a complete read/write cycle for session continuity

**Flow:**
```
Session N:                         Session N+1:
  work...                            /boot
  /save_context ─────────────────►   auto-rehydrate from latest.json
    ├─► latest.json                  └─► REHYDRATION: LOADED
    ├─► session_YYYYMMDD.json        └─► memory_bundle: present
    └─► .claude/memory/*.md
```

---

## Triggering Special Appends

To trigger writes to specific bundle files, include markers in your session `notes` before running `/save_context`:

| Marker | Target File | Example |
|--------|-------------|---------|
| `DECISION: <text>` | decisions.md | `DECISION: Use PostgreSQL over SQLite for scale` |
| `VERIFIED: <text>` | verified.md | `VERIFIED: API rate limit is 100 req/min` |
| `RUNBOOK: <symptom> -> <fix>` | runbook.md | `RUNBOOK: Chrome crash -> increase shared memory` |
| `UPDATE_CONTEXT: true` | context.md | Triggers context.md update |

If no markers are present, only `progress.md` is updated (from `work_completed`).

---

## Phase 4 Features (Implemented)

**Timestamp correctness:**
- Timestamp captured ONCE at runtime (single source of truth)
- Post-write verification ensures latest.json.timestamp matches expected
- Mismatch triggers WRITEBACK: FAILED with recovery instructions

**Marker self-auditing:**
- After writing DECISION:/VERIFIED:/RUNBOOK: entries, re-read target file
- Verify session ID appears in the file
- Report `markers_audited: N processed, N verified` in WRITEBACK

**Bundle read-back:**
- `/boot` loads and surfaces recent entries from verified.md, decisions.md, runbook.md
- See `/boot` documentation for MEMORY BUNDLE block format

---

## Phase 5 Notes (Future)

*Not implemented. Extension points for later:*

- **Auto-detect decisions:** Parse conversation for decision patterns without explicit markers
- **Proof linking:** Automatically link verified.md entries to proof artifacts
- **Bundle search:** Add `/memory search <term>` command to search across bundle files

---

## Operator Notes

**Canonical spec:** See `C:\Users\J\.claude\RUNBOOK_REHYDRATION.md`

- Run `/save_context` at end of every session or at natural breakpoints
- WRITEBACK `OK` = success; check timestamp_verified in output
- Use markers (`DECISION:`, `VERIFIED:`, `RUNBOOK:`) in notes to populate bundle
- Bundle writes are non-blocking; JSON write is authoritative
- Archives accumulate in `session_*.json`; cleanup is manual (keep ~20)
- **Phase 8:** machine_id.txt tracks which machine wrote context (sidecar, not in JSON)
- **Phase 8:** latest.pointer provides fallback reference to newest archive
- For conflict resolution details, see `lib\context_conflicts.ps1`
