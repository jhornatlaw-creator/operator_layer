---
name: dual-workspace
description: Auto-initializes context for both the_brain and AI_CORE/v4 - use when working on either interconnected system. These are tightly coupled: the_brain scrapes court data, AI_CORE/v4 processes and learns from it.
---

# Dual Workspace: the_brain + AI_CORE/v4

You are now working across TWO interconnected systems. Always maintain awareness of both.

---

## System Overview

### C:\Users\J\the_brain (Data Collection)
**Purpose**: Electron desktop app that scrapes court data from Texas counties

**Key Components**:
- `main.js` / `renderer.js` / `preload.js` - Electron app
- `orchestrator.py` - Python orchestration layer
- `counties/` - County-specific scrapers (Harris, Montgomery, Fort Bend)
- `adapters/` - Data adapters for different court systems
- `.claude/commands/` - Automation skills (harris-pipeline, montgomery-patterns, etc.)
- `bonds_output/` - Bond PDF storage

**Active Data**:
- `harris_unified.log` - Harris pipeline logs
- `montmisd_*.csv` - Montgomery misdemeanor outputs
- `run_log.db` - SQLite run tracking

### C:\AI_CORE\v4 (AI Processing & Learning)
**Purpose**: Law firm operating system - scores leads, predicts outcomes, learns from feedback

**Key Components**:
- `ai/brain/` - Core learning engine (EVO-6)
  - `case_scorer.py` - Scores cases for conversion probability
  - `bulk_ingest.py` - Data ingestion
  - `outcome_feed.py` - Processes hire/no-hire CSVs
  - `tuner.py` - Self-tuning from outcomes
- `core/` - Infrastructure (emailer, SMS, document generation)
  - `document_generator.py` - Generates legal documents
  - `email_router.py` - Routes incoming emails
  - `onboarding_engine.py` - Client onboarding automation
- `processors/` - File processors (CSV, PDF, video)
- `dashboard/` - Flask web UI
- `config/` - Settings and paths

---

## Data Flow

```
the_brain (scraping)          AI_CORE/v4 (processing)
─────────────────────         ─────────────────────────
County Scrapers ─────────────► csv_processor.py
                              │
Bond PDFs ───────────────────► affidavit_analyzer.py
                              │
Court filings ───────────────► case_scorer.py (EVO-6)
                              │
                              ▼
                         Hire/No-hire feedback
                              │
                              ▼
                         tuner.py (self-improvement)
```

---

## Common Cross-System Tasks

### 1. Adding a New County
- **the_brain**: Create scraper in `counties/new_county/`, add adapter in `adapters/`
- **AI_CORE**: Update `csv_processor.py` to handle new format, add to `config/paths.py`

### 2. Modifying Output Format
- **the_brain**: Update county script CSV columns
- **AI_CORE**: Update `bulk_ingest.py` column mappings, retrain scorer

### 3. Debugging Data Issues
- Check `the_brain/harris_unified.log` for scraping errors
- Check `AI_CORE/v4/dashboard/` logs for processing errors

### 4. Training the Brain
- Feed CSVs from `the_brain/` to `AI_CORE/v4/ai/brain/bulk_ingest.py`
- Run `outcome_feed.py` with hire/no-hire data

---

## Key Files to Read First

When starting work, read these for context:

**the_brain**:
- `C:\Users\J\the_brain\orchestrator.py` - How scrapers are orchestrated
- `C:\Users\J\the_brain\counties\harris\` - Harris county implementation

**AI_CORE/v4**:
- `C:\AI_CORE\v4\ai\brain\case_scorer.py` - How cases are scored
- `C:\AI_CORE\v4\core\document_generator.py` - Document generation
- `C:\AI_CORE\v4\config\paths.py` - Path configuration

---

## Working Rules

1. **Always consider both systems** - Changes in one often require changes in the other
2. **Test data flow end-to-end** - Scrape → Process → Score → Output
3. **Maintain column consistency** - CSV columns must match between systems
4. **Log changes in both** - Update README or comments in both repos

---

## Quick Commands

```bash
# the_brain
cd C:\Users\J\the_brain
npm start                    # Launch Electron app
python orchestrator.py       # Run orchestrator directly

# AI_CORE
cd C:\AI_CORE\v4
python -m dashboard.app      # Start web dashboard
python ai\brain\tuner.py     # Retune the scorer
```

---

You now have full context of both systems. When the user references either directory, consider implications for both.
