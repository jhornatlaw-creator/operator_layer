# /spread-arb - Spread Arbitrage Checker

Analyze spread betting positions across platforms to detect arbitrage opportunities.

## Usage

```bash
# Run example (Army/Lehigh from conversation)
python -m xprediction.tools.spread_arb --example

# Check your own positions
python -m xprediction.tools.spread_arb REF_TEAM OPPONENT \
  -p "TEAM:SPREAD:PRICE:STAKE:PLATFORM" \
  -p "TEAM:SPREAD:PRICE:STAKE:PLATFORM"

# Consider adding a position
python -m xprediction.tools.spread_arb REF_TEAM OPPONENT \
  -p "existing_position" \
  -c "position_to_consider"
```

## Position Format

```
TEAM:SPREAD:PRICE:STAKE:PLATFORM
```

**Price formats:**
- American odds: `-133`, `+150` (stake is dollar amount)
- Cents: `41c`, `57c` (stake is number of contracts)

## Examples

```bash
# Army +2.5 @ -133 on Underdog ($7.98 stake)
# Army -2.5 @ 41c on Kalshi (14 contracts)
python -m xprediction.tools.spread_arb Army Lehigh \
  -p "Army:+2.5:-133:7.98:underdog" \
  -p "Army:-2.5:41c:14:kalshi"

# Same, but considering Lehigh -1.5 @ 57c
python -m xprediction.tools.spread_arb Army Lehigh \
  -p "Army:+2.5:-133:7.98:underdog" \
  -p "Army:-2.5:41c:14:kalshi" \
  -c "Lehigh:-1.5:57c:14:kalshi"

# Output as JSON
python -m xprediction.tools.spread_arb --example --json
```

## Output

```
=================================================================
  SPREAD ANALYSIS: Army vs Lehigh
=================================================================

Total Stake: $13.72
Arbitrage:   NO
P&L Range:   $-13.72 to $14.26

-----------------------------------------------------------------
SCENARIO BREAKDOWN:
-----------------------------------------------------------------

> Lehigh wins by 3+
    [L] underdog: Army +2.5: $-7.98
    [L] kalshi: Army -2.5: $-5.74
    ----------------------------------------
    NET: $-13.72

> Close game (Lehigh by 2 to Army by 2)
    [W] underdog: Army +2.5: $+6.00
    [L] kalshi: Army -2.5: $-5.74
    ----------------------------------------
    NET: $+0.26

> Army wins by 3+
    [W] underdog: Army +2.5: $+6.00
    [W] kalshi: Army -2.5: $+8.26
    ----------------------------------------
    NET: $+14.26
```

## How It Works

1. **Collects all spread thresholds** from positions
2. **Generates outcome buckets** between thresholds (e.g., "Lehigh wins by 3+", "Close game", "Army wins by 3+")
3. **Evaluates each position** in each bucket (WIN/LOSE)
4. **Calculates net P&L** per scenario
5. **Determines arbitrage**: All scenarios must be profitable

## Key Rules

- **Spread S**: Bet wins when `team_margin > -S`
  - Army +2.5: wins if Army margin > -2.5 (Army wins or loses by ≤2)
  - Army -2.5: wins if Army margin > +2.5 (Army wins by 3+)
- **Reference team**: All margins calculated as REF - OPPONENT
- **Arb exists**: When MIN(scenario P&L) > 0

## Python API

```python
from xprediction.tools.spread_arb import (
    Position,
    analyze_positions,
    print_analysis,
)

positions = [
    Position.from_american("Army", +2.5, -133, 7.98, "underdog"),
    Position.from_cents("Army", -2.5, 41, 14, "kalshi"),
]

consider = Position.from_cents("Lehigh", -1.5, 57, 14, "kalshi")

result = analyze_positions(positions, "Army", "Lehigh", consider)
print_analysis(result)

# Or access programmatically
print(result["is_arb"])      # False
print(result["min_pnl"])     # -7.72
print(result["scenarios"])   # List of scenario dicts
```
