---
name: xprediction
description: Load cross-platform prediction market trading infrastructure
---

# /xprediction - Cross-Platform Prediction Market Infrastructure

Load the shared sports data and signal infrastructure for cross-platform trading (Polymarket → Kalshi).

## Workspace

| Item | Value |
|------|-------|
| Path | `C:\Users\J\xprediction` |
| GitHub | https://github.com/jhornatlaw-creator/xprediction |
| Tests | 15 passing |

## Boot Sequence

1. Read `C:\Users\J\xprediction\STATE.md`
2. Check git status: `git -C "C:\Users\J\xprediction" status --short`
3. Run tests: `cd C:\Users\J\xprediction && python -m pytest tests/ -q`

## Purpose

Shared data layer for cross-platform prediction market trading:
- **Sports Data**: Live scores, odds, lineups from balldontlie.io and RotoWire
- **Signal Storage**: Cross-platform signal transmission (File/SQLite)
- **Pilot Tools**: Lag measurement for score-shock edge detection

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      xprediction                            │
├─────────────────────────────────────────────────────────────┤
│  sports/                                                    │
│    ├── balldontlie.py  → NBA/NFL/MLB/NHL live data         │
│    └── rotowire.py     → Pre-game lineups & injuries       │
├─────────────────────────────────────────────────────────────┤
│  signals/                                                   │
│    └── store.py        → FileSignalStore, SqliteSignalStore│
├─────────────────────────────────────────────────────────────┤
│  pilot/                                                     │
│    └── score_pilot.py  → Lag measurement recorder          │
└─────────────────────────────────────────────────────────────┘
           │                           │
           ▼                           ▼
    ┌─────────────┐            ┌─────────────┐
    │ /polymarket │            │   /kalshi   │
    │   emitter   │            │  consumer   │
    └─────────────┘            └─────────────┘
```

## CLI Commands

```bash
# List live NBA games
python -m xprediction.sports.balldontlie

# Fetch lineups once
python -m xprediction.sports.rotowire --once

# Watch lineups for changes
python -m xprediction.sports.rotowire --watch --interval 60

# List live games for pilot
python -m xprediction.pilot.score_pilot --list-games

# Run score-shock pilot
python -m xprediction.pilot.score_pilot TICKER --game-id ID --duration 3600
```

## Quick Usage

```python
# Sports data
from xprediction.sports import BallDontLieClient, get_lineups_once

client = BallDontLieClient(api_key="...")
games = await client.get_live_games()
odds = await client.get_live_odds()

lineups = await get_lineups_once()

# Signal storage
from xprediction.signals import Signal, SqliteSignalStore

store = SqliteSignalStore("./signals.db")
store.put(Signal(target_ticker="KXTEST", fair_value=0.55))
signal = store.get_fresh("KXTEST", max_age_s=60)

# Pilot recording
from xprediction.pilot import run_pilot

report = await run_pilot(
    ticker="KXNBAGAME-...",
    game_id=12345,
    duration_s=3600,
)
```

## Data Sources

### balldontlie.io
| Tier | Req/Min | Cost | Poll Interval |
|------|---------|------|---------------|
| Free | 5 | $0 | 12s |
| ALL-STAR | 60 | $9.99/mo | 1s |
| GOAT | 600 | $39.99/mo | 100ms |

### RotoWire
- Free HTTP scraping
- No auth required

## Environment Variables

```bash
BALLDONTLIE_API_KEY=your_key_here
```

## Directory Structure

```
src/xprediction/
  sports/
    balldontlie.py   # NBA/NFL/MLB/NHL live data client
    rotowire.py      # Pre-game lineup scraper
  signals/
    store.py         # FileSignalStore + SqliteSignalStore
  pilot/
    score_pilot.py   # Lag measurement recorder
  logging.py
tests/
  test_signals.py
```

## Integration

### From Polymarket (emitter)
```python
from xprediction.signals import Signal, SqliteSignalStore

store = SqliteSignalStore("./signals.db")
store.put(Signal(
    target_ticker="KXNBA-...",
    fair_value=pm_mid,
    source_platform="polymarket",
))
```

### From Kalshi (consumer)
```python
from kalshi.strategies import CrossPlatformSignal
from xprediction.signals import SqliteSignalStore

store = SqliteSignalStore("./signals.db")
xp = CrossPlatformSignal(ticker="KXNBA-...", signal_store=store)
signal = xp.get_signal(kalshi_mid_cents)  # BUY/SELL/HOLD
```

## Related Projects

- `/polymarket` - Polymarket trading bot (signal emitter)
- `/kalshi` - Kalshi trading bot (signal consumer)

## Safety Rules

### NEVER
- Commit API keys or credentials
- Hardcode balldontlie.io API key

### ALWAYS
- Run tests before committing: `python -m pytest tests/ -q`
- Update STATE.md after significant changes
