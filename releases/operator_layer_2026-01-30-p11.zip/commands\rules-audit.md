# Rules Audit Command

Run a full compliance audit and generate a dated artifact.

## Execution Steps

1. **Run Preflight Gate**
   ```bash
   python scripts/rules_preflight.py --task "rules audit"
   ```
   - Paste output verbatim
   - If BLOCK: stop and report the blocker

2. **Generate Report**
   ```bash
   python scripts/rules_report.py
   ```
   - This aggregates latest preflight + evidence into a dated artifact

3. **Report Artifact Path**
   - Print the path to the generated artifact
   - Example: `.claude/artifacts/2026-01-29_rules_audit.md`

4. **Display Compliance Summary**
   - Show HS1/HS2/HS3 status
   - List any required actions

## Expected Output

```
RULES_PREFLIGHT: PASS
TASK: rules audit
MODE: autonomous
...

Report generated: C:\Users\J\.claude\artifacts\2026-01-29_rules_audit.md

Compliance Summary:
- HS1 (Preflight): PASS
- HS2 (Evidence Gate): (not applicable unless negative claim made)
- HS3 (Primary Source): (not applicable unless existence claim made)
```

## When to Use

- Periodic compliance check
- After significant task completion
- Before concluding negative existence claims
- When debugging rule enforcement issues

## Related Commands

- `/player-props` - Uses evidence gate for market claims
- `/execute_full_plan` - Six-lane review (includes compliance)
