# Operator Layer Installer

One-command installation and updates for the Claude Code operator layer.

**Version:** 2026-01-30-p10

---

## Quick Start

### Fresh Install

```powershell
# From local source
powershell -ExecutionPolicy Bypass -File install.ps1 -Source C:\path\to\source

# From git repository
powershell -ExecutionPolicy Bypass -File install.ps1 -Source https://github.com/user/repo.git

# From release zip (recommended for distribution)
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl C:\releases\operator_layer_p10.zip

# Self-install (if running from source directory)
powershell -ExecutionPolicy Bypass -File install.ps1
```

### Update

```powershell
# Check for updates (Local channel - git/path source)
powershell -ExecutionPolicy Bypass -File update.ps1 -VerifyOnly

# Check for updates (Release channel - zip)
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <path-to-zip> -VerifyOnly

# Apply update (Local channel)
powershell -ExecutionPolicy Bypass -File update.ps1

# Apply update (Release channel)
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <path-to-zip>

# Force update (even if same version)
powershell -ExecutionPolicy Bypass -File update.ps1 -Force
```

### Build Release

```powershell
# Build distributable zip from current installation
powershell -ExecutionPolicy Bypass -File release.ps1

# Output: releases\operator_layer_<version>.zip
```

### Scheduled Updates

```powershell
# Install automatic update checking
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install

# Check task status
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Query

# Remove scheduled tasks
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Remove
```

### Verify Installation

```powershell
powershell -ExecutionPolicy Bypass -File lib\verify_manifest.ps1
```

---

## What Gets Installed

### Managed Files (installed/updated)

| Path | Purpose |
|------|---------|
| `commands\*.md` | Claude Code slash commands |
| `lib\*.ps1` | PowerShell utilities |
| `RUNBOOK_REHYDRATION.md` | Canonical rehydration spec |
| `CHANGELOG_OPERATOR_LAYER.md` | Version history |
| `INSTALLER_README.md` | This file |
| `VERSION` | Current version string |
| `operator_layer_manifest.json` | File hashes for verification |

### Unmanaged Files (never touched)

| Path | Purpose |
|------|---------|
| `context\` | Session state (latest.json, archives) |
| `CLAUDE.md` | User's global config |
| `rules\` | User's custom rules |
| Any `.env` or credential files | Secrets (protected) |

---

## Directory Structure

```
C:\Users\J\.claude\
├── commands\
│   ├── boot.md
│   ├── save_context.md
│   ├── load_context.md
│   └── bootstrap_context.md
├── lib\
│   ├── maintenance.ps1
│   ├── smoke_tests.ps1
│   └── verify_manifest.ps1
├── context\                    # USER STATE - never touched
│   ├── latest.json
│   └── session_*.json
├── CLAUDE.md                   # USER CONFIG - never touched
├── RUNBOOK_REHYDRATION.md
├── CHANGELOG_OPERATOR_LAYER.md
├── INSTALLER_README.md
├── VERSION
├── operator_layer_manifest.json
├── install.ps1
└── update.ps1
```

---

## Recovery

### Manifest Verification Failed

```powershell
# Check what's wrong
powershell -File lib\verify_manifest.ps1

# Reinstall to fix
powershell -File install.ps1 -Source <original_source> -Force
```

### Rollback to Previous Version

See `RUNBOOK_REHYDRATION.md` → Rollback Procedure.

```powershell
# Quick rollback via git (if source is a repo)
cd <source_repo>
git checkout <previous_commit>
powershell -File install.ps1 -Source . -Force
```

### Complete Reinstall

```powershell
# Backup context first (optional but safe)
Copy-Item -Recurse C:\Users\J\.claude\context C:\Users\J\context_backup

# Reinstall everything
powershell -File install.ps1 -Source <source> -Force
```

---

## Source Requirements

The source (local path or git repo) must contain:

```
<source>/
├── VERSION              # Required
├── commands/
│   └── *.md
├── lib/
│   └── *.ps1
├── RUNBOOK_REHYDRATION.md
└── CHANGELOG_OPERATOR_LAYER.md
```

If source is a git repo with `.claude/` subfolder, the installer will find it automatically.

---

## Release Distribution

### Building a Release

```powershell
# Build from current installation
powershell -ExecutionPolicy Bypass -File release.ps1

# Build to custom output directory
powershell -ExecutionPolicy Bypass -File release.ps1 -OutputDir C:\my_releases

# Preview what would be included
powershell -ExecutionPolicy Bypass -File release.ps1 -DryRun
```

Output artifacts:
- `operator_layer_<version>.zip` - Distributable archive
- `operator_layer_<version>.sha256` - SHA256 hash file
- `operator_layer_manifest.json` - File manifest (also embedded in zip)

### Installing from Release

```powershell
# Install from local zip
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl C:\releases\operator_layer_p10.zip

# Install from URL with hash verification
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl https://example.com/release.zip -ExpectedHash abc123...
```

### Updating from Release

```powershell
# Update with verify-only (check what's available)
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <zip> -VerifyOnly

# Apply release update
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <zip>
```

### Release index.json Schema (Optional)

If hosting releases on a web server, you can create an `index.json`:

```json
{
  "latest_version": "2026-01-30-p10",
  "releases": [
    {
      "version": "2026-01-30-p10",
      "download_url": "https://example.com/operator_layer_2026-01-30-p10.zip",
      "sha256": "abc123...",
      "release_date": "2026-01-30"
    }
  ]
}
```

Then update using the index:
```powershell
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseIndexUrl https://example.com/index.json
```

---

## Automation

### Scheduled Update Check

```powershell
# Install automatic update tasks
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install

# Tasks created:
# - ClaudeOps\OperatorLayerVerifyDaily (daily at 7:00 AM, verify-only)
# - ClaudeOps\OperatorLayerUpdateWeekly (Sunday at 4:00 AM, configurable)

# Enable auto-apply (applies updates automatically)
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install -AutoApply
```

### Manual scheduled check
```powershell
# Run verify manually via Task Scheduler
schtasks /Run /TN "ClaudeOps\OperatorLayerVerifyDaily"
```

### CI/CD Integration

```powershell
# Unattended install from release (non-interactive)
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl $env:RELEASE_URL -Force

# Verify and fail if issues
powershell -ExecutionPolicy Bypass -File lib\verify_manifest.ps1
if ($LASTEXITCODE -ne 0) { exit 1 }
```

---

## Troubleshooting

### "git not found"

Install Git for Windows or use a local source path instead.

### "Permission denied"

Run PowerShell as Administrator, or check folder permissions:
```powershell
icacls C:\Users\J\.claude
```

### "Source path not found"

Ensure the path exists and contains VERSION file:
```powershell
Test-Path C:\path\to\source\VERSION
```

### "Manifest verification failed"

Files were modified outside of install/update. Reinstall:
```powershell
powershell -File install.ps1 -Source <source> -Force
```

---

## Version Scheme

Format: `YYYY-MM-DD-pN`

- `YYYY-MM-DD` = release date
- `pN` = patch number (p1, p2, ...)

Example: `2026-01-30-p7`

See `CHANGELOG_OPERATOR_LAYER.md` for full history.
