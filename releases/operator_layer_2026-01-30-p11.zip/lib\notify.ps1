<#
.SYNOPSIS
    Send local notifications for operator layer maintenance alerts.

.DESCRIPTION
    Sends Windows toast notifications with fallback to console output.
    Also writes to maintenance_status.json for visibility.

.PARAMETER Title
    Notification title.

.PARAMETER Message
    Notification body text.

.PARAMETER Severity
    Severity level: INFO, WARN, ERROR. Affects icon and urgency.

.PARAMETER Silent
    Suppress console output (useful when running as scheduled task).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File notify.ps1 -Title "Maintenance" -Message "All checks passed" -Severity INFO

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File notify.ps1 -Title "Maintenance Warning" -Message "3 stale archives found" -Severity WARN

.NOTES
    operator_layer_version: 2026-01-30-p9

    Notification methods (in priority order):
    1. Windows Toast (BurntToast module or native)
    2. Console output
    3. Status file update (always)
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Title,

    [Parameter(Mandatory=$true)]
    [string]$Message,

    [ValidateSet("INFO", "WARN", "ERROR")]
    [string]$Severity = "INFO",

    [switch]$Silent
)

$StatusFile = "C:\Users\J\.claude\lib\maintenance_status.json"

function Write-ToastNotification {
    param($title, $message, $severity)

    # Try BurntToast module first (most reliable)
    if (Get-Module -ListAvailable -Name BurntToast -ErrorAction SilentlyContinue) {
        try {
            Import-Module BurntToast -ErrorAction Stop

            $icon = switch ($severity) {
                "ERROR" { "Error" }
                "WARN"  { "Warning" }
                default { "None" }
            }

            New-BurntToastNotification -Text $title, $message -AppLogo $null
            return $true
        } catch {
            # Fall through to native method
        }
    }

    # Try native Windows toast (PowerShell 5.1+, Windows 10+)
    try {
        $null = [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
        $null = [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]

        $template = @"
<toast>
    <visual>
        <binding template="ToastText02">
            <text id="1">$([System.Security.SecurityElement]::Escape($title))</text>
            <text id="2">$([System.Security.SecurityElement]::Escape($message))</text>
        </binding>
    </visual>
</toast>
"@

        $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
        $xml.LoadXml($template)

        $appId = "ClaudeCode.OperatorLayer"
        $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
        [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId).Show($toast)

        return $true
    } catch {
        # Fall through to fallback
    }

    # Try Windows Script Host notification (older fallback)
    try {
        $shell = New-Object -ComObject Wscript.Shell
        $timeout = switch ($severity) {
            "ERROR" { 10 }
            "WARN"  { 7 }
            default { 5 }
        }
        $iconType = switch ($severity) {
            "ERROR" { 16 }  # Error icon
            "WARN"  { 48 }  # Warning icon
            default { 64 }  # Info icon
        }
        $shell.Popup($message, $timeout, $title, $iconType)
        return $true
    } catch {
        # All toast methods failed
    }

    return $false
}

function Write-ConsoleAlert {
    param($title, $message, $severity)

    $color = switch ($severity) {
        "ERROR" { "Red" }
        "WARN"  { "Yellow" }
        default { "Cyan" }
    }

    Write-Host ""
    Write-Host "========================================" -ForegroundColor $color
    Write-Host "[$severity] $title" -ForegroundColor $color
    Write-Host "========================================" -ForegroundColor $color
    Write-Host $message
    Write-Host ""
}

function Update-StatusFile {
    param($title, $message, $severity)

    $status = @{
        last_notification_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        last_notification_title = $title
        last_notification_message = $message
        last_notification_severity = $severity
    }

    # Merge with existing status if present
    if (Test-Path $StatusFile) {
        try {
            $existing = Get-Content $StatusFile -Raw | ConvertFrom-Json
            # Preserve other fields
            $status.last_run_at = $existing.last_run_at
            $status.status = $existing.status
            $status.counts = $existing.counts
            $status.warnings = $existing.warnings
            $status.errors = $existing.errors
        } catch {
            # Ignore parse errors, will overwrite
        }
    }

    $status | ConvertTo-Json -Depth 5 | Set-Content $StatusFile -Encoding UTF8
}

# ============================================================
# MAIN
# ============================================================

# Always update status file
Update-StatusFile -title $Title -message $Message -severity $Severity

# Try toast notification
$toastSent = Write-ToastNotification -title $Title -message $Message -severity $Severity

if ($toastSent) {
    if (-not $Silent) {
        Write-Host "[NOTIFY] Toast sent: $Title" -ForegroundColor Green
    }
} else {
    # Fallback to console
    if (-not $Silent) {
        Write-ConsoleAlert -title $Title -message $Message -severity $Severity
    }
}

# Return success
exit 0
