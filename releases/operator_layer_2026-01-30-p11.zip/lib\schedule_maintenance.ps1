<#
.SYNOPSIS
    Install, query, or remove scheduled maintenance tasks for the operator layer.

.DESCRIPTION
    Creates Windows scheduled tasks that run maintenance.ps1 automatically:
    - Daily: Integrity scan + conflict detection (DryRun mode)
    - Weekly: Archive retention enforcement (keep 30 days)
    - Optional: Weekly smoke tests

    Tasks run as the current user and send notifications on issues.

.PARAMETER Install
    Create the scheduled tasks.

.PARAMETER Query
    Show current task status.

.PARAMETER Remove
    Delete the scheduled tasks.

.PARAMETER DailyTime
    Time for daily task. Default: "06:00"

.PARAMETER WeeklyDay
    Day for weekly task. Default: "Sunday"

.PARAMETER WeeklyTime
    Time for weekly task. Default: "03:00"

.PARAMETER IncludeSmoke
    Include weekly smoke tests (adds ~30 seconds to weekly run).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_maintenance.ps1 -Install
    # Creates daily and weekly scheduled tasks

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_maintenance.ps1 -Query
    # Shows current task status

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_maintenance.ps1 -Remove
    # Removes all scheduled tasks

.NOTES
    operator_layer_version: 2026-01-30-p9

    Task names:
    - ClaudeOps\MaintenanceDaily
    - ClaudeOps\MaintenanceWeekly

    The tasks run silently and send Windows notifications on WARN/ERROR.
    Logs are written to: C:\Users\J\.claude\logs\maintenance\
#>

param(
    [switch]$Install,
    [switch]$Query,
    [switch]$Remove,
    [string]$DailyTime = "06:00",
    [string]$WeeklyDay = "Sunday",
    [string]$WeeklyTime = "03:00",
    [switch]$IncludeSmoke
)

$TaskFolder = "ClaudeOps"
$DailyTaskName = "$TaskFolder\MaintenanceDaily"
$WeeklyTaskName = "$TaskFolder\MaintenanceWeekly"
$MaintenanceScript = "C:\Users\J\.claude\lib\maintenance.ps1"
$PowerShellPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]     $msg" -ForegroundColor Green }
        "FAIL" { Write-Host "[FAIL]   $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO]   $msg" -ForegroundColor Gray }
        "WARN" { Write-Host "[WARN]   $msg" -ForegroundColor Yellow }
    }
}

function Test-AdminPrivileges {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-TaskExists($taskName) {
    try {
        $task = Get-ScheduledTask -TaskName ($taskName -replace "^$TaskFolder\\", "") -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue
        return $null -ne $task
    } catch {
        return $false
    }
}

function Install-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  INSTALLING SCHEDULED MAINTENANCE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    # Check if script exists
    if (-not (Test-Path $MaintenanceScript)) {
        Write-Status "FAIL" "Maintenance script not found: $MaintenanceScript"
        exit 1
    }
    Write-Status "OK" "Maintenance script found"

    # Create task folder if needed
    try {
        $folder = Get-ScheduledTask -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue
        if (-not $folder) {
            # Folder will be created with first task
        }
    } catch {
        # Ignore
    }

    # ── Daily Task ──
    Write-Host ""
    Write-Host "-- Daily Task --" -ForegroundColor Cyan
    Write-Status "INFO" "Task: $DailyTaskName"
    Write-Status "INFO" "Schedule: Every day at $DailyTime"
    Write-Status "INFO" "Action: Integrity scan + conflict detection (DryRun)"

    $dailyArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$MaintenanceScript`" -DryRun -RunConflicts -Silent -Notify"

    try {
        # Remove existing if present
        if (Get-TaskExists $DailyTaskName) {
            Unregister-ScheduledTask -TaskName "MaintenanceDaily" -TaskPath "\$TaskFolder\" -Confirm:$false -ErrorAction SilentlyContinue
        }

        $dailyAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument $dailyArgs
        $dailyTrigger = New-ScheduledTaskTrigger -Daily -At $DailyTime
        $dailySettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false
        $dailyPrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

        Register-ScheduledTask -TaskName "MaintenanceDaily" -TaskPath "\$TaskFolder\" -Action $dailyAction -Trigger $dailyTrigger -Settings $dailySettings -Principal $dailyPrincipal -Force | Out-Null
        Write-Status "OK" "Daily task created"
    } catch {
        Write-Status "FAIL" "Failed to create daily task: $_"
    }

    # ── Weekly Task ──
    Write-Host ""
    Write-Host "-- Weekly Task --" -ForegroundColor Cyan
    Write-Status "INFO" "Task: $WeeklyTaskName"
    Write-Status "INFO" "Schedule: Every $WeeklyDay at $WeeklyTime"

    $weeklyArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$MaintenanceScript`" -EnforceRetention -KeepDays 30 -RunConflicts -Silent -Notify"
    if ($IncludeSmoke) {
        $weeklyArgs += " -RunSmoke"
        Write-Status "INFO" "Action: Retention + conflicts + smoke tests"
    } else {
        Write-Status "INFO" "Action: Retention + conflicts"
    }

    try {
        # Remove existing if present
        if (Get-TaskExists $WeeklyTaskName) {
            Unregister-ScheduledTask -TaskName "MaintenanceWeekly" -TaskPath "\$TaskFolder\" -Confirm:$false -ErrorAction SilentlyContinue
        }

        $weeklyAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument $weeklyArgs
        $weeklyTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $WeeklyDay -At $WeeklyTime
        $weeklySettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false
        $weeklyPrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

        Register-ScheduledTask -TaskName "MaintenanceWeekly" -TaskPath "\$TaskFolder\" -Action $weeklyAction -Trigger $weeklyTrigger -Settings $weeklySettings -Principal $weeklyPrincipal -Force | Out-Null
        Write-Status "OK" "Weekly task created"
    } catch {
        Write-Status "FAIL" "Failed to create weekly task: $_"
    }

    # Summary
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  SCHEDULE: INSTALLED" -ForegroundColor Green
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""
    Write-Status "INFO" "Daily task:  $DailyTaskName (daily at $DailyTime)"
    Write-Status "INFO" "Weekly task: $WeeklyTaskName ($WeeklyDay at $WeeklyTime)"
    Write-Host ""
    Write-Status "INFO" "Logs: C:\Users\J\.claude\logs\maintenance\"
    Write-Status "INFO" "Status: C:\Users\J\.claude\lib\maintenance_status.json"
    Write-Host ""
    Write-Status "INFO" "To test: schtasks /Run /TN `"$DailyTaskName`""
    Write-Status "INFO" "To query: powershell ... schedule_maintenance.ps1 -Query"
    Write-Status "INFO" "To remove: powershell ... schedule_maintenance.ps1 -Remove"
}

function Query-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  SCHEDULED MAINTENANCE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    $tasks = @($DailyTaskName, $WeeklyTaskName)
    $found = 0

    foreach ($taskName in $tasks) {
        $shortName = $taskName -replace "^$TaskFolder\\", ""
        try {
            $task = Get-ScheduledTask -TaskName $shortName -TaskPath "\$TaskFolder\" -ErrorAction Stop
            $taskInfo = Get-ScheduledTaskInfo -TaskName $shortName -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue

            Write-Host "-- $taskName --" -ForegroundColor Cyan
            Write-Status "INFO" "State: $($task.State)"

            if ($taskInfo.LastRunTime -and $taskInfo.LastRunTime -ne [DateTime]::MinValue) {
                $age = ((Get-Date) - $taskInfo.LastRunTime).TotalHours
                Write-Status "INFO" "Last run: $($taskInfo.LastRunTime.ToString('yyyy-MM-dd HH:mm')) ($([math]::Round($age, 1))h ago)"
                Write-Status "INFO" "Last result: $($taskInfo.LastTaskResult)"
            } else {
                Write-Status "INFO" "Last run: Never"
            }

            if ($taskInfo.NextRunTime -and $taskInfo.NextRunTime -ne [DateTime]::MinValue) {
                Write-Status "INFO" "Next run: $($taskInfo.NextRunTime.ToString('yyyy-MM-dd HH:mm'))"
            }

            Write-Host ""
            $found++
        } catch {
            Write-Status "WARN" "${taskName}: Not found"
            Write-Host ""
        }
    }

    if ($found -eq 0) {
        Write-Status "WARN" "No scheduled tasks found"
        Write-Status "INFO" "Run with -Install to create tasks"
    }

    # Show last maintenance status
    $statusFile = "C:\Users\J\.claude\lib\maintenance_status.json"
    if (Test-Path $statusFile) {
        try {
            $status = Get-Content $statusFile -Raw | ConvertFrom-Json
            Write-Host "-- Last Maintenance Run --" -ForegroundColor Cyan
            Write-Status "INFO" "Time: $($status.last_run_at)"
            Write-Status "INFO" "Status: $($status.status)"
            Write-Status "INFO" "Passed: $($status.counts.passed), Warnings: $($status.counts.warnings), Errors: $($status.counts.errors)"
            if ($status.log_file) {
                Write-Status "INFO" "Log: $($status.log_file)"
            }
        } catch {
            # Ignore parse errors
        }
    }
}

function Remove-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  REMOVING SCHEDULED MAINTENANCE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    $tasks = @("MaintenanceDaily", "MaintenanceWeekly")
    $removed = 0

    foreach ($taskName in $tasks) {
        try {
            $task = Get-ScheduledTask -TaskName $taskName -TaskPath "\$TaskFolder\" -ErrorAction Stop
            Unregister-ScheduledTask -TaskName $taskName -TaskPath "\$TaskFolder\" -Confirm:$false
            Write-Status "OK" "Removed: $TaskFolder\$taskName"
            $removed++
        } catch {
            Write-Status "INFO" "${TaskFolder}\${taskName}: Not found (skipped)"
        }
    }

    # Try to remove folder if empty
    try {
        $remainingTasks = Get-ScheduledTask -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue
        if (-not $remainingTasks) {
            # Folder is empty, but we can't delete it directly
            Write-Status "INFO" "Task folder $TaskFolder is now empty"
        }
    } catch {
        # Ignore
    }

    Write-Host ""
    if ($removed -gt 0) {
        Write-Host "SCHEDULE: REMOVED ($removed tasks)" -ForegroundColor Green
    } else {
        Write-Host "SCHEDULE: No tasks to remove" -ForegroundColor Yellow
    }
}

# ============================================================
# MAIN
# ============================================================

if (-not ($Install -or $Query -or $Remove)) {
    Write-Host ""
    Write-Host "Usage:" -ForegroundColor Yellow
    Write-Host "  schedule_maintenance.ps1 -Install        # Create scheduled tasks"
    Write-Host "  schedule_maintenance.ps1 -Query          # Show task status"
    Write-Host "  schedule_maintenance.ps1 -Remove         # Remove scheduled tasks"
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -DailyTime <HH:MM>      Daily run time (default: 06:00)"
    Write-Host "  -WeeklyDay <Day>        Weekly run day (default: Sunday)"
    Write-Host "  -WeeklyTime <HH:MM>     Weekly run time (default: 03:00)"
    Write-Host "  -IncludeSmoke           Include smoke tests in weekly run"
    Write-Host ""
    exit 0
}

if ($Install) {
    Install-Tasks
} elseif ($Query) {
    Query-Tasks
} elseif ($Remove) {
    Remove-Tasks
}
