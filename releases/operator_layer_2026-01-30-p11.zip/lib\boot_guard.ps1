<#
.SYNOPSIS
    BOOT GUARD - Read-only safety check for /boot
.DESCRIPTION
    Detects risky conditions (dirty repo, conflicts, stale context, live processes)
    and classifies session into SAFE, CAUTION, or LOCKED mode.

    NON-DESTRUCTIVE: Never modifies git state, never kills processes.
.PARAMETER RepoPath
    Path to check for git status. Defaults to current directory.
.PARAMETER ContextPath
    Path to context directory. Defaults to C:\Users\J\.claude\context
.PARAMETER PolicyPath
    Path to guard_policy.json. Defaults to C:\Users\J\.claude\lib\guard_policy.json
.OUTPUTS
    JSON object with: guard_mode, reasons, recommended_actions, signals, policy_version
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File boot_guard.ps1
    powershell -ExecutionPolicy Bypass -File boot_guard.ps1 -RepoPath "C:\project"
#>

param(
    [string]$RepoPath = (Get-Location).Path,
    [string]$ContextPath = "C:\Users\J\.claude\context",
    [string]$PolicyPath = "C:\Users\J\.claude\lib\guard_policy.json"
)

# === Load Policy ===
$defaultPolicy = @{
    policy_version = "2026-01-30-guard-v1"
    lock_on_repo_dirty = $true
    lock_on_recent_conflicts = $false
    recent_conflicts_hours = 24
    context_stale_hours = 24
}

$policy = $defaultPolicy
if (Test-Path $PolicyPath) {
    try {
        $loaded = Get-Content $PolicyPath -Raw | ConvertFrom-Json
        # Merge loaded values over defaults
        if ($loaded.policy_version) { $policy.policy_version = $loaded.policy_version }
        if ($null -ne $loaded.lock_on_repo_dirty) { $policy.lock_on_repo_dirty = $loaded.lock_on_repo_dirty }
        if ($null -ne $loaded.lock_on_recent_conflicts) { $policy.lock_on_recent_conflicts = $loaded.lock_on_recent_conflicts }
        if ($loaded.recent_conflicts_hours) { $policy.recent_conflicts_hours = $loaded.recent_conflicts_hours }
        if ($loaded.context_stale_hours) { $policy.context_stale_hours = $loaded.context_stale_hours }
    } catch {
        # Use defaults on parse error
    }
}

# === Initialize Signals ===
$signals = @{
    repo_dirty = $false
    repo_unknown = $false
    repo_unpushed = $false
    unpushed_count = 0
    recent_context_conflicts = $false
    conflict_dirs = @()
    context_stale = $false
    context_age_hours = 0
    live_processes = $false
    process_names = @()
    is_git_repo = $false
}

# === Detector 1: Git Repo Status ===
$gitDir = Join-Path $RepoPath ".git"
if (Test-Path $gitDir) {
    $signals.is_git_repo = $true

    # Check for dirty working tree
    try {
        $status = & git -C $RepoPath status --porcelain 2>$null
        if ($status) {
            $signals.repo_dirty = $true
        }
    } catch {
        $signals.repo_unknown = $true
    }

    # Check for unpushed commits (if remote exists)
    try {
        $ahead = & git -C $RepoPath rev-list --count "@{u}..HEAD" 2>$null
        if ($ahead -and [int]$ahead -gt 0) {
            $signals.repo_unpushed = $true
            $signals.unpushed_count = [int]$ahead
        }
    } catch {
        # No upstream or error - not a lock condition
    }
} else {
    # Not a git repo - treat as unknown but don't lock
    $signals.repo_unknown = $true
}

# === Detector 2: Recent Context Conflicts ===
$conflictsDir = Join-Path $ContextPath "CONFLICTS"
if (Test-Path $conflictsDir) {
    $cutoff = (Get-Date).AddHours(-$policy.recent_conflicts_hours)
    $recentConflicts = Get-ChildItem $conflictsDir -Directory | Where-Object { $_.CreationTime -gt $cutoff }
    if ($recentConflicts) {
        $signals.recent_context_conflicts = $true
        $signals.conflict_dirs = @($recentConflicts | ForEach-Object { $_.Name })
    }
}

# === Detector 3: Context Staleness ===
$latestJson = Join-Path $ContextPath "latest.json"
if (Test-Path $latestJson) {
    try {
        $ctx = Get-Content $latestJson -Raw | ConvertFrom-Json
        if ($ctx.timestamp) {
            $ts = [DateTime]::Parse($ctx.timestamp)
            $age = (Get-Date) - $ts
            $signals.context_age_hours = [math]::Round($age.TotalHours, 1)
            if ($age.TotalHours -gt $policy.context_stale_hours) {
                $signals.context_stale = $true
            }
        }
    } catch {
        # Parse error - context system will handle this
    }
}

# === Detector 4: Live Processes (Best-Effort) ===
# Look for known bot/service patterns - names only, no secrets
$processPatterns = @(
    "python",
    "node",
    "chrome",
    "pwsh",
    "kalshi_bot",
    "pm_bot",
    "xprediction",
    "runner"
)

try {
    $running = Get-Process -ErrorAction SilentlyContinue |
        Where-Object {
            $name = $_.ProcessName.ToLower()
            $processPatterns | Where-Object { $name -like "*$_*" }
        } |
        Select-Object -ExpandProperty ProcessName -Unique

    if ($running) {
        $signals.live_processes = $true
        $signals.process_names = @($running)
    }
} catch {
    # Process enumeration failed - non-fatal
}

# === Determine Guard Mode ===
$guard_mode = "SAFE"
$reasons = @()
$recommended_actions = @()

# LOCKED conditions
if ($signals.repo_dirty -and $policy.lock_on_repo_dirty) {
    $guard_mode = "LOCKED"
    $reasons += "Uncommitted changes in working tree"
    $recommended_actions += "Run: git status"
    $recommended_actions += "Run: git add -A && git commit -m 'wip: checkpoint before /boot'"
    $recommended_actions += "Or: git stash -u"
}

if ($signals.recent_context_conflicts -and $policy.lock_on_recent_conflicts) {
    $guard_mode = "LOCKED"
    $reasons += "Recent context sync conflicts detected ($($signals.conflict_dirs.Count) in last $($policy.recent_conflicts_hours)h)"
    $recommended_actions += "Run: powershell -File C:\Users\J\.claude\lib\context_conflicts.ps1 -Normalize"
    $recommended_actions += "Then re-run /boot"
}

# CAUTION conditions (only if not already LOCKED)
if ($guard_mode -ne "LOCKED") {
    if ($signals.repo_unpushed) {
        $guard_mode = "CAUTION"
        $reasons += "Unpushed commits ($($signals.unpushed_count)) - work not backed up to remote"
        $recommended_actions += "Consider: git push before multi-agent operations"
    }

    if ($signals.context_stale) {
        $guard_mode = "CAUTION"
        $reasons += "Session context is $($signals.context_age_hours) hours old (threshold: $($policy.context_stale_hours)h)"
        $recommended_actions += "Verify objective is still current"
        $recommended_actions += "Run /save_context after confirming state"
    }

    if ($signals.live_processes) {
        $guard_mode = "CAUTION"
        $reasons += "Detected running processes: $($signals.process_names -join ', ')"
        $recommended_actions += "Avoid patch_apply mode"
        $recommended_actions += "Stay in review_only or patch_plan"
        $recommended_actions += "Do not restart services automatically"
    }

    if ($signals.repo_unknown -and -not $signals.is_git_repo) {
        # Only warn if not in a git repo at all - this is informational
        # Don't escalate to CAUTION just for being outside a repo
    }
}

# === Build Output ===
$output = @{
    guard_mode = $guard_mode
    reasons = $reasons
    recommended_actions = $recommended_actions
    signals = $signals
    policy_version = $policy.policy_version
}

# Output as JSON
$output | ConvertTo-Json -Depth 3
