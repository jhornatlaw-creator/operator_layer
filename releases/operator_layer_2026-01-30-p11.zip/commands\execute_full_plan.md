---
name: execute_full_plan
description: Launch a six-lane parallel engineering review and merge into a ranked patch plan.
operator_layer_version: 2026-01-15
---

# /execute_full_plan

## Preconditions
- If the current work is within law practice, run `/jhornlaw` first (and `/boot` before that).

## Step 0: Define Target (MANDATORY)

Before launching agents, explicitly set the review target:

| Target Type | When to Use |
|-------------|-------------|
| `target: repo_root` | Default - full repository review |
| `target: <path>` | User specified folder/file (e.g., `target: core/`) |
| `target: changed_since_commit` | Only files changed since last commit |
| `target: staged_files` | Only staged files (pre-commit review) |

**State the target explicitly in output.** Never assume "we reviewed everything."

## Step 0.5: Prepare Context Sharing (TOKEN OPTIMIZATION)

**If token_optimizer is enabled:**

Before launching agents, compile a PRELOADED CONTEXT list of files already read this session:

```
PRELOADED CONTEXT (do not re-read these files):
- {path1}: {1-line summary}
- {path2}: {1-line summary}
- ...
```

Include this block in EACH agent's prompt. Agents MUST:
1. Check this list before reading ANY file
2. If file is on list, use the summary or ask parent for details
3. NOT re-read files already loaded

**Token savings:** 50-80% reduction in agent file reads.

## Step 1: Launch six subagents in parallel

Use:
- `jh-security`
- `jh-concurrency`
- `jh-resilience`
- `jh-types`
- `jh-tests`
- `jh-maintainability`

**Each agent MUST begin its report with a self-sourcing header:**
```
finding_count: N (critical X / high Y / medium Z / low W)
```

**Each finding MUST be prefixed with severity:**
```
[CRITICAL] SQL injection in user_search()...
[HIGH] Missing timeout on HTTP call...
[MEDIUM] Retry without backoff...
[LOW] Inconsistent naming...
```

## Step 2: Merge outputs
- Deduplicate overlaps
- Score: Severity (CRITICAL/HIGH/MEDIUM/LOW) × Likelihood (High/Med/Low)
- **Copy finding counts directly from agent headers** (no manual counting)
- Produce:
  1) Master ranked findings list
  2) Quick wins (safe small diffs)
  3) Risky changes (needs staging or extra tests)
  4) Ordered patch plan (Security → Concurrency/Idempotency → Resilience/Timeouts/Retry → Tests → Refactors)

## Step 3: Proof
If code changes are proposed, include:
- Commands run
- Output excerpts
- Plain-English summary of what changed and why

## Step 4: Diagnostics Footer (MANDATORY)

**Self-sourced from agent headers.** Always end with:

```
===========================================
REVIEW DIAGNOSTICS
===========================================
timestamp: [current date/time]
project_loader: [/jhornlaw|/distress|/dfs|none]
execution_mode: [review_only|patch_plan|patch_apply|emergency]
target: [repo_root|<path>|changed_since_commit|staged_files]
agents_invoked:
  - jh-security: [from header]
  - jh-concurrency: [from header]
  - jh-resilience: [from header]
  - jh-types: [from header]
  - jh-tests: [from header]
  - jh-maintainability: [from header]
merge_method: severity × likelihood
total_findings: [sum of above]
critical: [sum] | high: [sum] | medium: [sum] | low: [sum]
proof_commands_run: [count]
token_optimization:
  context_shared: [count files passed to agents]
  agent_rereads_avoided: [count]
  estimated_savings: [tokens saved]
===========================================
```

## Patch Posture (IMPORTANT)

This command **produces a patch plan but does NOT modify code** unless:

| Condition | Action |
|-----------|--------|
| User says "apply patch set" or "apply fixes" | Apply patches, then report |
| `/jhornlaw` loaded AND user chose Level 3 posture | Apply patches, then report |
| Otherwise | **Present plan only, wait for approval** |

**Default is read-only.** The patch plan is a proposal, not an execution.

To apply:
- User must explicitly say "apply" or "fix it"
- Or be in a project loader with Level 3 initiative enabled

## Guardrails
- Never open/print/edit `.env` files, tokens, API keys, passwords, or secret stores.
- Do not run destructive commands.
- Do not apply patches without explicit approval (unless Level 3 posture).
