---
name: review_quick
description: Fast triage - six-lane review capped at top 3 findings per agent. Use before deciding whether to run full review.
---

# /review_quick

Fast triage mode. Same six lanes as `/execute_full_plan`, but capped for speed.

## Constraints
- **Each agent: top 3 findings only** (highest severity first)
- **No patch plan** (just findings)
- **No proof commands** (just identification)
- Target: same as `/execute_full_plan`

## Step 0: Define Target

Same rules as `/execute_full_plan`:
- `target: repo_root` (default)
- `target: <path>` (user-specified)
- `target: changed_since_commit`
- `target: staged_files`

## Step 1: Launch six subagents in parallel (CAPPED)

Each agent returns **maximum 3 findings**, prioritized by severity.

**Agent header format:**
```
finding_count: N of M (showing top 3, N total found)
```

**Finding format:**
```
[CRITICAL] Brief description - file:line
[HIGH] Brief description - file:line
[MEDIUM] Brief description - file:line
```

## Step 2: Quick Merge

- List all findings (max 18)
- Sort by severity
- **Do NOT deduplicate** (speed over precision)
- **Do NOT generate patch plan**

## Step 3: Triage Output

```
===========================================
QUICK TRIAGE
===========================================
target: [target]
findings_shown: [count] (of [total] identified)

CRITICAL ([count]):
- [finding] - file:line

HIGH ([count]):
- [finding] - file:line

MEDIUM ([count]):
- [finding] - file:line

LOW ([count]):
- [finding] - file:line

RECOMMENDATION:
- [ ] Run /execute_full_plan (if critical/high findings)
- [ ] Patch directly (if only low/medium)
- [ ] Skip (if clean)
===========================================
```

## When to Use

- Pre-commit sanity check
- "Is this worth a full review?"
- Time-boxed triage (< 2 min)
- Deciding whether to patch now or defer

## Guardrails
- Never open/print/edit `.env` files, tokens, API keys, passwords, or secret stores.
- Do not run destructive commands.
