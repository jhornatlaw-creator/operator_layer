<#
.SYNOPSIS
    Build a distributable release package of the operator layer.

.DESCRIPTION
    Creates a versioned zip file and manifest for distribution to other machines.
    Excludes user state (context\, logs\) and machine-local artifacts.

    Output artifacts:
    - operator_layer_<version>.zip
    - operator_layer_<version>.sha256
    - operator_layer_manifest.json (embedded in zip and copied to output)

.PARAMETER OutputDir
    Output directory for release artifacts. Default: releases\

.PARAMETER Version
    Version string for the release. Default: read from VERSION file.

.PARAMETER DryRun
    Show what would be included without creating the zip.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File release.ps1
    # Build release from current operator layer

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File release.ps1 -OutputDir C:\releases
    # Build to custom output directory

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File release.ps1 -DryRun
    # Preview what would be included

.NOTES
    operator_layer_version: 2026-01-30-p10

    INCLUDED in release:
    - commands\*.md
    - lib\*.ps1
    - RUNBOOK_REHYDRATION.md
    - CHANGELOG_OPERATOR_LAYER.md
    - INSTALLER_README.md
    - VERSION
    - install.ps1
    - update.ps1
    - release.ps1

    EXCLUDED from release:
    - context\* (user session state)
    - logs\* (runtime logs)
    - releases\* (build output)
    - CLAUDE.md (user config)
    - rules\* (user rules)
    - *.tmp, *.bak
    - Any .env or credential files
#>

param(
    [string]$OutputDir = "C:\Users\J\.claude\releases",
    [string]$Version,
    [switch]$DryRun
)

$SourceDir = "C:\Users\J\.claude"
$VersionPath = Join-Path $SourceDir "VERSION"

# Patterns to include (relative paths)
$IncludePatterns = @(
    "commands\*.md",
    "lib\*.ps1",
    "RUNBOOK_REHYDRATION.md",
    "CHANGELOG_OPERATOR_LAYER.md",
    "INSTALLER_README.md",
    "VERSION",
    "install.ps1",
    "update.ps1",
    "release.ps1"
)

# Patterns to explicitly exclude
$ExcludePatterns = @(
    "context\*",
    "logs\*",
    "releases\*",
    "rules\*",
    "CLAUDE.md",
    "*.tmp",
    "*.bak",
    ".env*",
    "*credentials*",
    "*secrets*",
    "operator_layer_manifest.json"  # Will be regenerated
)

function Write-Header($text) {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  $text" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
}

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]   $msg" -ForegroundColor Green }
        "SKIP" { Write-Host "[SKIP] $msg" -ForegroundColor Yellow }
        "FAIL" { Write-Host "[FAIL] $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO] $msg" -ForegroundColor Gray }
        "ADD"  { Write-Host "[ADD]  $msg" -ForegroundColor Cyan }
    }
}

function Get-FileHash256($path) {
    if (-not (Test-Path $path)) { return $null }
    return (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLower()
}

function Test-ShouldExclude($relativePath) {
    foreach ($pattern in $ExcludePatterns) {
        if ($relativePath -like $pattern) {
            return $true
        }
    }
    return $false
}

# ============================================================
# MAIN
# ============================================================

Write-Header "OPERATOR LAYER RELEASE BUILDER"

# Get version
if (-not $Version) {
    if (Test-Path $VersionPath) {
        $Version = (Get-Content $VersionPath -Raw).Trim()
    } else {
        Write-Status "FAIL" "VERSION file not found and -Version not specified"
        exit 1
    }
}

Write-Host "  Version: $Version" -ForegroundColor Gray
Write-Host "  Source: $SourceDir" -ForegroundColor Gray
Write-Host "  Output: $OutputDir" -ForegroundColor Gray
Write-Host "  Mode: $(if ($DryRun) { 'DRY RUN' } else { 'BUILD' })" -ForegroundColor Gray
Write-Host ""

# ── Step 1: Collect files ──
Write-Host "-- Collecting files --" -ForegroundColor Cyan

$filesToInclude = @()

foreach ($pattern in $IncludePatterns) {
    $searchPath = Join-Path $SourceDir $pattern
    $matches = Get-ChildItem -Path $searchPath -ErrorAction SilentlyContinue

    foreach ($file in $matches) {
        $relativePath = $file.FullName.Substring($SourceDir.Length + 1)

        if (Test-ShouldExclude $relativePath) {
            Write-Status "SKIP" "$relativePath (excluded)"
            continue
        }

        $filesToInclude += @{
            FullPath = $file.FullName
            RelativePath = $relativePath
            Size = $file.Length
        }
        Write-Status "ADD" $relativePath
    }
}

if ($filesToInclude.Count -eq 0) {
    Write-Status "FAIL" "No files found to include"
    exit 1
}

Write-Host ""
Write-Status "INFO" "Total files: $($filesToInclude.Count)"

if ($DryRun) {
    Write-Header "DRY RUN COMPLETE"
    Write-Host "  Files would be included: $($filesToInclude.Count)" -ForegroundColor Gray
    Write-Host "  No artifacts created." -ForegroundColor Yellow
    exit 0
}

# ── Step 2: Create staging directory ──
Write-Host ""
Write-Host "-- Creating staging directory --" -ForegroundColor Cyan

$stagingDir = Join-Path $env:TEMP "operator_layer_release_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $stagingDir -Force | Out-Null
Write-Status "OK" "Staging: $stagingDir"

# Copy files to staging
foreach ($file in $filesToInclude) {
    $targetPath = Join-Path $stagingDir $file.RelativePath
    $targetDir = Split-Path -Parent $targetPath

    if (-not (Test-Path $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    Copy-Item -Path $file.FullPath -Destination $targetPath -Force
}

Write-Status "OK" "Copied $($filesToInclude.Count) files to staging"

# ── Step 3: Generate manifest for staged files ──
Write-Host ""
Write-Host "-- Generating manifest --" -ForegroundColor Cyan

$manifestFiles = @()
foreach ($file in $filesToInclude) {
    $stagedPath = Join-Path $stagingDir $file.RelativePath
    $hash = Get-FileHash256 $stagedPath
    $size = (Get-Item $stagedPath).Length

    $manifestFiles += @{
        path = $file.RelativePath
        sha256 = $hash
        bytes = $size
    }
}

$manifest = @{
    version = $Version
    generated_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
    source = "release_build"
    files = $manifestFiles
}

$manifestPath = Join-Path $stagingDir "operator_layer_manifest.json"
$manifest | ConvertTo-Json -Depth 10 | Set-Content $manifestPath -Encoding UTF8
Write-Status "OK" "Generated manifest ($($manifestFiles.Count) files)"

# ── Step 4: Create output directory ──
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    Write-Status "OK" "Created output directory"
}

# ── Step 5: Create zip ──
Write-Host ""
Write-Host "-- Creating release archive --" -ForegroundColor Cyan

$zipName = "operator_layer_$Version.zip"
$zipPath = Join-Path $OutputDir $zipName
$hashName = "operator_layer_$Version.sha256"
$hashPath = Join-Path $OutputDir $hashName

# Remove existing if present
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

try {
    Compress-Archive -Path "$stagingDir\*" -DestinationPath $zipPath -Force
    Write-Status "OK" "Created: $zipName"
} catch {
    Write-Status "FAIL" "Failed to create zip: $_"
    Remove-Item -Recurse -Force $stagingDir -ErrorAction SilentlyContinue
    exit 1
}

# ── Step 6: Compute zip hash ──
$zipHash = Get-FileHash256 $zipPath
"$zipHash  $zipName" | Set-Content $hashPath -Encoding UTF8
Write-Status "OK" "Created: $hashName"

# Copy manifest to output for reference
$manifestOutputPath = Join-Path $OutputDir "operator_layer_manifest.json"
Copy-Item $manifestPath $manifestOutputPath -Force
Write-Status "OK" "Copied manifest to output"

# ── Step 7: Cleanup staging ──
Remove-Item -Recurse -Force $stagingDir -ErrorAction SilentlyContinue

# ── Summary ──
$zipSize = (Get-Item $zipPath).Length
$zipSizeKB = [math]::Round($zipSize / 1024, 1)

Write-Header "RELEASE: OK"
Write-Host ""
Write-Host "  Version: $Version" -ForegroundColor Green
Write-Host "  Files: $($filesToInclude.Count)" -ForegroundColor Gray
Write-Host "  Size: $zipSizeKB KB" -ForegroundColor Gray
Write-Host ""
Write-Host "  Artifacts:" -ForegroundColor Cyan
Write-Host "    $zipPath" -ForegroundColor Gray
Write-Host "    $hashPath" -ForegroundColor Gray
Write-Host "    $manifestOutputPath" -ForegroundColor Gray
Write-Host ""
Write-Host "  SHA256: $zipHash" -ForegroundColor Gray
Write-Host ""
Write-Host "  Install command:" -ForegroundColor Yellow
Write-Host "    install.ps1 -ReleaseUrl `"$zipPath`"" -ForegroundColor Gray
Write-Host ""

exit 0
