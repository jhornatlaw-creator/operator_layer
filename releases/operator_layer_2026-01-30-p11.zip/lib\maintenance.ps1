<#
.SYNOPSIS
    Maintenance script for the Rehydration & Memory Persistence system.

.DESCRIPTION
    Performs health checks, archive retention enforcement, conflict detection,
    and smoke tests. Designed for periodic or on-demand maintenance.
    Writes logs and status for scheduled task visibility.

    Canonical spec: C:\Users\J\.claude\RUNBOOK_REHYDRATION.md
    Changelog: C:\Users\J\.claude\CHANGELOG_OPERATOR_LAYER.md

.PARAMETER DryRun
    Show what would be done without making changes.

.PARAMETER EnforceRetention
    Delete archives older than retention threshold.

.PARAMETER KeepDays
    Keep archives from the last N days. Default: 30.

.PARAMETER KeepCount
    Keep the last N archives (overrides KeepDays if both specified).

.PARAMETER RunSmoke
    Run smoke tests after maintenance checks.

.PARAMETER RunConflicts
    Run conflict detection scan.

.PARAMETER Silent
    Suppress console output (for scheduled tasks). Logs still written.

.PARAMETER Notify
    Send notification on WARN/ERROR (default: true for scheduled runs).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File maintenance.ps1 -DryRun
    # Shows what would be deleted/repaired without making changes

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File maintenance.ps1 -EnforceRetention -KeepDays 30
    # Deletes archives older than 30 days

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File maintenance.ps1 -RunSmoke -RunConflicts
    # Runs integrity checks + smoke tests + conflict scan

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File maintenance.ps1 -Silent -Notify
    # Silent mode with notifications (for scheduled tasks)

.NOTES
    operator_layer_version: 2026-01-30-p9

    SAFETY:
    - No secrets accessed
    - No network required
    - DryRun mode available for safe preview
    - Archives are only deleted with explicit -EnforceRetention flag

    LOGGING:
    - Logs written to: C:\Users\J\.claude\logs\maintenance\
    - Status snapshot: C:\Users\J\.claude\lib\maintenance_status.json
#>

param(
    [switch]$DryRun,
    [switch]$EnforceRetention,
    [int]$KeepDays = 30,
    [int]$KeepCount = 0,
    [switch]$RunSmoke,
    [switch]$RunConflicts,
    [switch]$Silent,
    [switch]$Notify
)

# Paths
$ContextDir = "C:\Users\J\.claude\context"
$LatestJson = "$ContextDir\latest.json"
$SmokeTestScript = "C:\Users\J\.claude\lib\smoke_tests.ps1"
$ConflictScript = "C:\Users\J\.claude\lib\context_conflicts.ps1"
$NotifyScript = "C:\Users\J\.claude\lib\notify.ps1"
$StatusFile = "C:\Users\J\.claude\lib\maintenance_status.json"
$LogDir = "C:\Users\J\.claude\logs\maintenance"
$ManagedRepos = @(
    "C:\Users\J\the_brain",
    "C:\AI_CORE\v4"
)

# Counters and tracking
$script:ErrorCount = 0
$script:WarningCount = 0
$script:PassCount = 0
$script:Warnings = @()
$script:Errors = @()
$script:LogLines = @()

# Initialize logging
$script:RunTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$script:LogFile = Join-Path $LogDir "maintenance_$($script:RunTimestamp).log"

# Ensure log directory exists
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

function Write-Log($line) {
    $script:LogLines += $line
    if (-not $Silent) {
        Write-Host $line
    }
}

function Write-Header($text) {
    Write-Log ""
    Write-Log "======================================================="
    Write-Log "  $text"
    Write-Log "======================================================="
    if (-not $Silent) {
        Write-Host ""
        Write-Host "=======================================================" -ForegroundColor White
        Write-Host "  $text" -ForegroundColor White
        Write-Host "=======================================================" -ForegroundColor White
    }
}

function Write-SubHeader($text) {
    $line = "-- $text --"
    $script:LogLines += ""
    $script:LogLines += $line
    if (-not $Silent) {
        Write-Host ""
        Write-Host "-- $text --" -ForegroundColor Cyan
    }
}

function Write-Pass($msg) {
    $line = "[PASS] $msg"
    $script:LogLines += $line
    if (-not $Silent) {
        Write-Host $line -ForegroundColor Green
    }
    $script:PassCount++
}

function Write-Fail($msg) {
    $line = "[FAIL] $msg"
    $script:LogLines += $line
    $script:Errors += $msg
    if (-not $Silent) {
        Write-Host $line -ForegroundColor Red
    }
    $script:ErrorCount++
}

function Write-Warn($msg) {
    $line = "[WARN] $msg"
    $script:LogLines += $line
    $script:Warnings += $msg
    if (-not $Silent) {
        Write-Host $line -ForegroundColor Yellow
    }
    $script:WarningCount++
}

function Write-Info($msg) {
    $line = "[INFO] $msg"
    $script:LogLines += $line
    if (-not $Silent) {
        Write-Host $line -ForegroundColor Gray
    }
}

function Write-Action($msg) {
    if ($DryRun) {
        $line = "[DRY-RUN] Would: $msg"
    } else {
        $line = "[ACTION] $msg"
    }
    $script:LogLines += $line
    if (-not $Silent) {
        if ($DryRun) {
            Write-Host $line -ForegroundColor Magenta
        } else {
            Write-Host $line -ForegroundColor Blue
        }
    }
}

# ============================================================
# INTEGRITY CHECKS
# ============================================================

function Test-LatestJsonIntegrity {
    Write-SubHeader "Checking latest.json integrity"

    # Check existence
    if (-not (Test-Path $LatestJson)) {
        Write-Fail "latest.json not found at $LatestJson"
        Write-Info "Recovery: Run /bootstrap_context"
        return $false
    }
    Write-Pass "latest.json exists"

    # Check JSON parse
    try {
        $content = Get-Content $LatestJson -Raw
        $json = $content | ConvertFrom-Json
    } catch {
        Write-Fail "latest.json is not valid JSON"
        Write-Info "Recovery: Restore from newest session_*.json archive"
        return $false
    }
    Write-Pass "latest.json parses as valid JSON"

    # Check timestamp field exists
    if (-not $json.timestamp) {
        Write-Fail "latest.json missing 'timestamp' field"
        Write-Info "Recovery: Run /bootstrap_context"
        return $false
    }
    Write-Pass "timestamp field exists"

    # Check timestamp is parseable
    try {
        $ts = [DateTime]::Parse($json.timestamp)
        $age = (Get-Date) - $ts
        $ageHours = [math]::Round($age.TotalHours, 1)

        if ($ageHours -gt 168) {
            Write-Warn "Context is $ageHours hours old (>7 days)"
        } elseif ($ageHours -gt 24) {
            Write-Warn "Context is $ageHours hours old (>24 hours)"
        } else {
            Write-Pass "timestamp is valid and fresh ($ageHours hours old)"
        }
    } catch {
        Write-Fail "timestamp field is not a valid datetime: $($json.timestamp)"
        Write-Info "Recovery: Run /bootstrap_context"
        return $false
    }

    # Check operator_layer_version
    if ($json.operator_layer_version) {
        Write-Pass "operator_layer_version: $($json.operator_layer_version)"
    } else {
        Write-Warn "operator_layer_version field missing (optional)"
    }

    return $true
}

function Test-ArchiveIntegrity {
    Write-SubHeader "Checking archive integrity"

    $archives = Get-ChildItem "$ContextDir\session_*.json" -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending

    if ($archives.Count -eq 0) {
        Write-Warn "No archives found"
        return $true
    }

    Write-Info "Found $($archives.Count) archive(s)"

    # Check newest archive
    $newest = $archives[0]
    try {
        $content = Get-Content $newest.FullName -Raw
        $json = $content | ConvertFrom-Json
        if ($json.timestamp) {
            Write-Pass "Newest archive is valid: $($newest.Name)"
        } else {
            Write-Warn "Newest archive missing timestamp: $($newest.Name)"
        }
    } catch {
        Write-Fail "Newest archive is corrupt: $($newest.Name)"
        Write-Info "Consider deleting and relying on older archives"
    }

    # Summary
    $oldestDate = $archives[-1].LastWriteTime.ToString("yyyy-MM-dd")
    $newestDate = $archives[0].LastWriteTime.ToString("yyyy-MM-dd")
    Write-Info "Archive range: $oldestDate to $newestDate"

    return $true
}

function Test-BundlePresence {
    Write-SubHeader "Checking memory bundles in managed repos"

    foreach ($repo in $ManagedRepos) {
        $bundlePath = Join-Path $repo ".claude\memory"

        if (-not (Test-Path $repo)) {
            Write-Info "Repo not found (skipped): $repo"
            continue
        }

        if (Test-Path $bundlePath) {
            $files = Get-ChildItem "$bundlePath\*.md" -ErrorAction SilentlyContinue
            $fileCount = $files.Count
            Write-Pass "Bundle present in $repo ($fileCount files)"
        } else {
            Write-Warn "No bundle in $repo"
            Write-Info "Bundle will be created on first /save_context in that repo"
        }
    }

    return $true
}

# ============================================================
# RETENTION ENFORCEMENT
# ============================================================

function Invoke-RetentionPolicy {
    Write-SubHeader "Archive retention"

    $archives = Get-ChildItem "$ContextDir\session_*.json" -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending

    if ($archives.Count -eq 0) {
        Write-Info "No archives to process"
        return
    }

    Write-Info "Total archives: $($archives.Count)"

    $toDelete = @()

    if ($KeepCount -gt 0) {
        # Keep by count
        Write-Info "Retention policy: Keep last $KeepCount archives"

        if ($archives.Count -gt $KeepCount) {
            $toDelete = $archives | Select-Object -Skip $KeepCount
        }
    } else {
        # Keep by days
        Write-Info "Retention policy: Keep archives from last $KeepDays days"

        $cutoff = (Get-Date).AddDays(-$KeepDays)
        $toDelete = $archives | Where-Object { $_.LastWriteTime -lt $cutoff }
    }

    if ($toDelete.Count -eq 0) {
        Write-Pass "No archives exceed retention threshold"
        return
    }

    Write-Info "Archives to delete: $($toDelete.Count)"

    foreach ($file in $toDelete) {
        $age = ((Get-Date) - $file.LastWriteTime).Days

        if ($DryRun) {
            Write-Action "Delete $($file.Name) (${age}d old)"
        } else {
            try {
                Remove-Item $file.FullName -Force
                Write-Info "Deleted: $($file.Name) (${age}d old)"
            } catch {
                Write-Fail "Failed to delete: $($file.Name)"
            }
        }
    }

    if (-not $DryRun) {
        $remaining = (Get-ChildItem "$ContextDir\session_*.json" -ErrorAction SilentlyContinue).Count
        Write-Pass "Retention enforced. Remaining archives: $remaining"
    }
}

# ============================================================
# CONFLICT DETECTION
# ============================================================

function Test-Conflicts {
    Write-SubHeader "Checking for sync conflicts"

    if (-not (Test-Path $ConflictScript)) {
        Write-Info "Conflict detection script not found (skipped)"
        return $true
    }

    try {
        $output = & powershell -ExecutionPolicy Bypass -File $ConflictScript 2>&1
        $exitCode = $LASTEXITCODE

        if ($exitCode -eq 0) {
            Write-Pass "No conflicts detected"
            return $true
        } elseif ($exitCode -eq 1) {
            Write-Warn "Conflicts detected and resolved"
            $script:LogLines += $output
            return $true
        } else {
            Write-Fail "Conflict detection failed"
            return $false
        }
    } catch {
        Write-Fail "Conflict detection error: $_"
        return $false
    }
}

# ============================================================
# SMOKE TESTS
# ============================================================

function Invoke-SmokeTests {
    Write-SubHeader "Running smoke tests"

    if (-not (Test-Path $SmokeTestScript)) {
        Write-Fail "Smoke test script not found: $SmokeTestScript"
        return $false
    }

    Write-Info "Executing: $SmokeTestScript -RunAll"

    try {
        $result = & powershell -ExecutionPolicy Bypass -File $SmokeTestScript -RunAll
        $exitCode = $LASTEXITCODE

        # Display output
        $result | ForEach-Object { Write-Host $_ }

        if ($exitCode -eq 0) {
            Write-Pass "Smoke tests completed successfully"
            return $true
        } else {
            Write-Fail "Smoke tests failed (exit code: $exitCode)"
            return $false
        }
    } catch {
        Write-Fail "Smoke test execution failed: $_"
        return $false
    }
}

# ============================================================
# STATUS AND NOTIFICATION
# ============================================================

function Write-StatusFile {
    $status = if ($script:ErrorCount -gt 0) { "ERROR" }
              elseif ($script:WarningCount -gt 0) { "WARN" }
              else { "OK" }

    $statusObj = @{
        last_run_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        status = $status
        dry_run = $DryRun.IsPresent
        counts = @{
            passed = $script:PassCount
            warnings = $script:WarningCount
            errors = $script:ErrorCount
        }
        warnings = $script:Warnings | Select-Object -First 5
        errors = $script:Errors | Select-Object -First 5
        log_file = $script:LogFile
    }

    $statusObj | ConvertTo-Json -Depth 5 | Set-Content $StatusFile -Encoding UTF8
}

function Write-LogFile {
    $script:LogLines | Set-Content $script:LogFile -Encoding UTF8
}

function Send-Notification {
    param($title, $message, $severity)

    if (-not (Test-Path $NotifyScript)) {
        Write-Info "Notify script not found, skipping notification"
        return
    }

    try {
        & powershell -ExecutionPolicy Bypass -File $NotifyScript -Title $title -Message $message -Severity $severity -Silent:$Silent
    } catch {
        Write-Info "Notification failed: $_"
    }
}

# ============================================================
# MAIN
# ============================================================

$startTime = Get-Date

Write-Header "OPERATOR LAYER MAINTENANCE"
$script:LogLines += "  Version: 2026-01-30-p9"
$script:LogLines += "  Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$script:LogLines += "  Mode: $(if ($DryRun) { 'DRY-RUN' } else { 'LIVE' })"

if (-not $Silent) {
    Write-Host "  Version: 2026-01-30-p9" -ForegroundColor Gray
    Write-Host "  Mode: $(if ($DryRun) { 'DRY-RUN (no changes)' } else { 'LIVE' })" -ForegroundColor $(if ($DryRun) { 'Magenta' } else { 'Green' })
}

# Always run integrity checks
Test-LatestJsonIntegrity | Out-Null
Test-ArchiveIntegrity | Out-Null
Test-BundlePresence | Out-Null

# Conflict detection (if flag set)
if ($RunConflicts) {
    Test-Conflicts | Out-Null
} else {
    Write-SubHeader "Conflict detection"
    Write-Info "Skipped (use -RunConflicts to enable)"
}

# Retention enforcement (only if flag set)
if ($EnforceRetention) {
    Invoke-RetentionPolicy
} else {
    Write-SubHeader "Archive retention"
    Write-Info "Skipped (use -EnforceRetention to enable)"

    # Show preview
    $archives = Get-ChildItem "$ContextDir\session_*.json" -ErrorAction SilentlyContinue
    if ($archives.Count -gt 20) {
        Write-Warn "$($archives.Count) archives present. Consider running with -EnforceRetention"
    }
}

# Smoke tests (only if flag set)
if ($RunSmoke) {
    Invoke-SmokeTests | Out-Null
} else {
    Write-SubHeader "Smoke tests"
    Write-Info "Skipped (use -RunSmoke to enable)"
}

# Summary
$duration = ((Get-Date) - $startTime).TotalSeconds
Write-Header "SUMMARY"

$summaryLines = @(
    "  Checks passed: $script:PassCount",
    "  Warnings:      $script:WarningCount",
    "  Errors:        $script:ErrorCount",
    "  Duration:      $([math]::Round($duration, 1))s"
)
$summaryLines | ForEach-Object { $script:LogLines += $_ }

if (-not $Silent) {
    Write-Host "  Checks passed: $script:PassCount" -ForegroundColor Green
    Write-Host "  Warnings:      $script:WarningCount" -ForegroundColor Yellow
    Write-Host "  Errors:        $script:ErrorCount" -ForegroundColor $(if ($script:ErrorCount -gt 0) { 'Red' } else { 'Gray' })
    Write-Host "  Duration:      $([math]::Round($duration, 1))s" -ForegroundColor Gray
}

if ($DryRun -and -not $Silent) {
    Write-Host ""
    Write-Host "  DRY-RUN: No changes were made." -ForegroundColor Magenta
    Write-Host "  Remove -DryRun flag to apply changes." -ForegroundColor Magenta
}

# Write status and log files
Write-StatusFile
Write-LogFile

# Determine final status and notify if needed
$finalStatus = "OK"
$exitCode = 0

if ($script:ErrorCount -gt 0) {
    $finalStatus = "ERROR"
    $exitCode = 1
    $script:LogLines += "MAINTENANCE: ISSUES FOUND"
    if (-not $Silent) {
        Write-Host ""
        Write-Host "MAINTENANCE: ISSUES FOUND" -ForegroundColor Red
    }
    if ($Notify) {
        $errorSummary = ($script:Errors | Select-Object -First 3) -join "; "
        Send-Notification -title "Claude Ops: Maintenance ERROR" -message "Errors found: $errorSummary" -severity "ERROR"
    }
} elseif ($script:WarningCount -gt 0) {
    $finalStatus = "WARN"
    $script:LogLines += "MAINTENANCE: OK (with warnings)"
    if (-not $Silent) {
        Write-Host ""
        Write-Host "MAINTENANCE: OK (with warnings)" -ForegroundColor Yellow
    }
    if ($Notify) {
        $warnSummary = ($script:Warnings | Select-Object -First 3) -join "; "
        Send-Notification -title "Claude Ops: Maintenance Warning" -message "Warnings: $warnSummary" -severity "WARN"
    }
} else {
    $script:LogLines += "MAINTENANCE: ALL CLEAR"
    if (-not $Silent) {
        Write-Host ""
        Write-Host "MAINTENANCE: ALL CLEAR" -ForegroundColor Green
    }
}

# Update log file with final status
Write-LogFile

if (-not $Silent) {
    Write-Host "  Log: $script:LogFile" -ForegroundColor Gray
}

exit $exitCode
