---
name: token_optimizer
description: Enforced token reduction via persistent summaries, read gates, and agent contracts.
operator_layer_version: 2026-01-15
version: 2.0.0
---

# /token_optimizer

Manage token usage across sessions. Tracks budgets, caches context, suggests optimizations.

## Quick Reference

| Command | Action |
|---------|--------|
| `/token_optimizer` | Show current status |
| `/token_optimizer report` | Full usage report |
| `/token_optimizer budget <n>` | Set session budget |
| `/token_optimizer cache status` | Cache statistics |
| `/token_optimizer cache clear` | Clear cache |
| `/token_optimizer unload <pattern>` | Free tokens |
| `/token_optimizer help` | Show this reference |

---

# MODEL POLICY (NON-NEGOTIABLE)

**Token optimization reduces WASTE, never REASONING QUALITY.**

| Model | Use For |
|-------|---------|
| **Opus** | Architecture, planning, scaffolding, coding, review, debugging, design, security, complex reasoning, ALL user-facing tasks |
| **Haiku** | ONLY token analysis itself (cache stats, manifest maintenance, usage reports) |

**Rules:**
- Default model: **Opus** — always
- Never downgrade to save tokens on substantive work
- Haiku is ONLY for meta-optimization (analyzing token usage)
- If in doubt, use Opus

**The six-lane review agents (`jh-security`, etc.) use Sonnet for cost efficiency on parallel scans, but final synthesis and decisions stay on Opus.**

---

# ACTIVE TOKEN REDUCTION (ENFORCED MECHANISMS)

These mechanisms are **mandatory** and enforced via persistent state. No "mental" storage—everything writes to manifest.

---

## READ DECISION GATE (Execute Before EVERY Read)

**This gate is MANDATORY. Do not skip.**

### Step 1: Check Manifest

```powershell
# Check if file exists in manifest
powershell -Command "Get-Content 'C:\Users\J\.claude\token-optimizer\cache\manifest.json' -Raw"
```

Look for path in `entries` keys or `current_session.files_read_this_session`.

**If file IS in manifest with valid summary_1l:**
```
→ STOP. Return: "[CACHED: {path}] {summary_1l}"
→ Increment stats.rereads_avoided
→ Add tokens_estimated to stats.tokens_saved
→ DO NOT call Read tool
```

**If file NOT in manifest or no summary:** Proceed to Step 2.

### Step 2: File Size Check

```powershell
powershell -Command "(Get-Item '<path>').Length"
```

| Size | Action |
|------|--------|
| ≤ 50 KB | Full read allowed |
| 50-200 KB | MUST use offset/limit (default: offset=0, limit=500) |
| > 200 KB | MUST grep-first, then targeted read |

### Step 3: Query Type Check

Is this an **exploration query**? (user asked "where is X", "find Y", "how does Z work")

| Query Type | Action |
|------------|--------|
| Exploration + file not in manifest | MUST grep-first |
| Direct path from user | Proceed with read (respecting size limits) |
| User said "re-read" or "refresh" | Proceed with read, update manifest |

### Step 4: Execute Read + Write Summary

After successful Read:

1. **Generate summary_1l** (MUST be ≤100 chars):
   ```
   {filename}: {primary_purpose} - {key_exports_or_functions}
   ```

2. **Get file hash:**
   ```powershell
   powershell -Command "(Get-FileHash '<path>' -Algorithm SHA256).Hash.Substring(0,8)"
   ```

3. **Write to manifest.entries:**
   ```json
   {
     "file:<path>:<mtime>:<size>:<hash>": {
       "type": "file",
       "path": "<path>",
       "tokens_estimated": <len/4>,
       "summary_1l": "<generated summary>",
       "source_hash": "<8-char hash>",
       "last_read_turn": <current_session.current_turn>,
       "read_count": 1,
       "created": "<now>"
     }
   }
   ```

4. **Add path to current_session.files_read_this_session**

5. **Write manifest atomically** (temp + rename)

---

## MANIFEST ENTRY SCHEMA (v2)

Every file read MUST create an entry:

```json
{
  "file:C:\\path\\file.py:1705312000000:4523:a1b2c3d4": {
    "type": "file",
    "path": "C:\\path\\file.py",
    "tokens_estimated": 1130,

    "summary_1l": "retry.py: Exponential backoff - retry_with_backoff(), RetryConfig",
    "source_hash": "a1b2c3d4",

    "last_read_turn": 12,
    "read_count": 1,

    "created": "2026-01-15T19:45:00Z",
    "ttl_minutes": 1440
  }
}
```

**Required fields:** type, path, tokens_estimated, summary_1l, source_hash, last_read_turn, read_count, created

---

## AGENT CONTEXT CONTRACT

**When launching ANY Task agent, MUST include this block:**

Generate from manifest:

```
══════════════════════════════════════════
PRELOADED CONTEXT — DO NOT RE-READ
══════════════════════════════════════════
Files already read this session. Use summaries.
DO NOT call Read tool on these paths.

{For each entry in manifest.entries where last_read_turn >= current_turn - 10:}
• {path}
  Summary: {summary_1l}
  Tokens: {tokens_estimated}

{End for each}

IF YOU NEED MORE DETAIL:
1. State: "CONTEXT_REQUEST: {path} — need {what}"
2. Return to parent
3. Parent will provide targeted excerpt
4. DO NOT re-read yourself

Violation wastes tokens. Comply.
══════════════════════════════════════════
```

**Generation procedure:**
```
1. Read manifest.entries
2. Filter: last_read_turn >= (current_turn - 10)
3. Format each entry
4. Prepend to agent prompt
```

**When agent returns CONTEXT_REQUEST:**
- Parent reads targeted section (offset/limit based on request)
- Parent provides excerpt to agent (if continuing)
- No full re-read by anyone

---

## SUMMARY GENERATION RULES

**Format:** `{filename}: {purpose} - {key_items}`

**Examples:**
```
retry.py: Exponential backoff retry logic - retry_with_backoff(), RetryConfig
http_client.py: HTTP wrapper with timeouts - HttpClient.get/post/delete
config.json: Token optimizer settings - budgets, cache, estimation
boot.md: Session init sequence - Steps 0-3, project detection, diagnostics
manifest.json: Token cache state - stats, entries, current_session
```

**Rules:**
- Max 100 characters
- Start with filename (no path)
- Include primary purpose
- List 2-3 key exports/functions/sections
- No fluff words ("This file contains...", "Used for...")

---

## SEARCH-FIRST TRIGGERS

**MUST grep-first when:**
1. File > 200KB
2. Exploration query ("where is", "find", "how does")
3. Unknown file not in manifest

**Grep-first pattern:**
```
1. Grep "<pattern>" --files_with_matches
2. Identify top 3 relevant files
3. For each file: Grep "<pattern>" -C 3 -n (get context)
4. Read only the specific line ranges needed
```

**Example:**
```
User: "Where is retry logic?"

WRONG:
  Read core/http.py (2000 lines)
  Read core/client.py (1500 lines)
  Read utils/retry.py (800 lines)
  = 4300 lines = ~1075 tokens

RIGHT:
  Grep "retry" --files_with_matches
  → core/retry.py
  Grep "retry" core/retry.py -n -C 3
  → lines 42-58 relevant
  Read core/retry.py offset=40 limit=25
  = 25 lines = ~6 tokens + summary stored
```

---

## TURN COUNTER

**Increment current_session.current_turn:**
- After each user message + assistant response pair
- Used for: last_read_turn tracking, stale detection, agent context filtering

**Update manifest atomically after each turn.**

---

## STALE ENTRY HANDLING

**Entry is stale when:** `current_turn - last_read_turn > 10`

**On stale entry access:**
1. Check source_hash against current file
2. If hash matches: refresh last_read_turn, return summary
3. If hash differs: re-read file, update entry

**Eviction (optional, Phase 2):** Remove entries where last_read_turn < current_turn - 50

---

## ATOMIC WRITE PATTERN

**ALL manifest writes MUST use:**

```powershell
# 1. Write to temp
$json | Out-File 'C:\Users\J\.claude\token-optimizer\cache\manifest.json.tmp' -Encoding UTF8

# 2. Atomic rename
Move-Item 'C:\Users\J\.claude\token-optimizer\cache\manifest.json.tmp' `
          'C:\Users\J\.claude\token-optimizer\cache\manifest.json' -Force
```

**Corruption recovery:** If manifest.json is invalid JSON, restore from manifest.json.bak (keep last good copy).

---

# RUNTIME IMPLEMENTATION

## Constants

```
CONFIG_PATH    = C:\Users\J\.claude\token-optimizer\config.json
MANIFEST_PATH  = C:\Users\J\.claude\token-optimizer\cache\manifest.json
METRICS_PATH   = C:\Users\J\.claude\token-optimizer\metrics\aggregate.json
CACHE_DIR      = C:\Users\J\.claude\token-optimizer\cache\files
BUDGETS_DIR    = C:\Users\J\.claude\token-optimizer\budgets
```

---

## Token Estimation Function

**estimate_tokens(content, content_type)**

```
1. base_estimate = len(content) / 4

2. Apply multiplier based on content_type:
   - code_python:     base × 0.95
   - code_javascript: base × 0.95
   - code_json:       base × 1.10
   - prose_english:   base × 1.00
   - prose_legal:     base × 0.90
   - mixed:           base × 1.00

3. Return round(adjusted_estimate)

Error bound: ±15%
```

**Detect content_type:**
- `.py` files → code_python
- `.js`, `.ts` files → code_javascript
- `.json` files → code_json
- `.md`, `.txt` files → prose_english
- Legal docs (contracts, pleadings) → prose_legal
- Everything else → mixed

---

## Session Initialization (called by /boot Step 2.5)

**Procedure:**

1. Check if CONFIG_PATH exists:
   ```powershell
   powershell -Command "Test-Path 'C:\Users\J\.claude\token-optimizer\config.json'"
   ```

2. If FALSE → set `token_optimizer_enabled: false`, skip remaining steps

3. If TRUE → Read config:
   ```powershell
   powershell -Command "Get-Content 'C:\Users\J\.claude\token-optimizer\config.json' -Raw"
   ```

4. Read manifest:
   ```powershell
   powershell -Command "Get-Content 'C:\Users\J\.claude\token-optimizer\cache\manifest.json' -Raw"
   ```

5. Determine session budget:
   - Get current workstream from project loader (e.g., "jhornlaw", "xprediction", "global")
   - Check `config.workstream_overrides[workstream].session_default_tokens`
   - If exists, use override; else use `config.budgets.session_default_tokens`

6. Generate session_id:
   ```powershell
   powershell -Command "[guid]::NewGuid().ToString().Substring(0,8)"
   ```

7. Get current timestamp:
   ```powershell
   powershell -Command "Get-Date -Format 'yyyy-MM-ddTHH:mm:ssZ'"
   ```

8. Update manifest.current_session:
   ```json
   {
     "id": "<session_id>",
     "started": "<timestamp>",
     "workstream": "<workstream>",
     "budget_tokens": <budget>,
     "tokens_used": {
       "input": 0,
       "output": 0,
       "cached_input": 0
     },
     "by_category": {
       "file_reads": 0,
       "search_results": 0,
       "system_prompts": 0,
       "tool_outputs": 0
     }
   }
   ```

9. Write manifest using atomic pattern (see below)

10. Set `token_optimizer_enabled: true`

11. Return for diagnostics:
    - budget: `<budget / 1000>K`
    - cache hit_rate: `manifest.stats.hit_rate × 100`%

---

## Atomic Write Pattern

**ALL writes to manifest.json or config.json MUST use this pattern:**

```powershell
# Step 1: Write content to temp file
$content = @'
<JSON_CONTENT>
'@
$content | Out-File -FilePath 'C:\Users\J\.claude\token-optimizer\cache\manifest.json.tmp' -Encoding UTF8 -NoNewline

# Step 2: Atomic rename
Move-Item -Path 'C:\Users\J\.claude\token-optimizer\cache\manifest.json.tmp' -Destination 'C:\Users\J\.claude\token-optimizer\cache\manifest.json' -Force
```

**Why:** Prevents corruption if write is interrupted.

---

## Track Token Usage (called during session)

**track_tokens(category, content, source)**

Called whenever context is loaded. Categories:
- `file_reads` — when Read tool is used
- `search_results` — when Grep/Glob returns results
- `system_prompts` — CLAUDE.md, project loaders
- `tool_outputs` — other tool results

**Procedure:**

1. Estimate tokens: `tokens = estimate_tokens(content, detect_type(source))`

2. Read current manifest

3. Check cache for hit (see Cache Lookup below)
   - If HIT: increment `manifest.stats.cache_hits`, use cached token count
   - If MISS: increment `manifest.stats.cache_misses`, add to cache if cacheable

4. Update manifest.current_session:
   - `tokens_used.input += tokens`
   - `by_category[category] += tokens`

5. Calculate new totals and check alerts (see Alert Check)

6. Write manifest atomically

7. Return token count for logging

---

## Cache Key Generation

**generate_cache_key(type, source)**

For files:
```powershell
# Get file stats
$file = Get-Item '<path>'
$mtime = [DateTimeOffset]::new($file.LastWriteTimeUtc).ToUnixTimeMilliseconds()
$size = $file.Length
$hash = (Get-FileHash '<path>' -Algorithm SHA256).Hash.Substring(0,8)

# Key format
"file:<path>:<mtime>:<size>:<hash>"
```

For searches:
```powershell
$patternHash = [System.BitConverter]::ToString(
  [System.Security.Cryptography.SHA256]::Create().ComputeHash(
    [System.Text.Encoding]::UTF8.GetBytes('<pattern>')
  )
).Replace('-','').Substring(0,8)
$timestamp = Get-Date -Format 'yyyyMMddHHmm'

# Key format
"search:<tool>:<patternHash>:<scope>:<timestamp>"
```

---

## Cache Lookup

**cache_lookup(key)**

1. Read manifest.entries

2. If `key` exists in entries:
   - Check if expired: `now > entry.created + (entry.ttl_minutes × 60000)`
   - If expired: return MISS, mark for eviction
   - If valid:
     - Update `entry.last_accessed` to now
     - Update `entry.last_referenced_turn` to current turn index
     - Increment `entry.access_count`
     - Increment `manifest.stats.cache_hits`
     - Return HIT with `entry.tokens_estimated`

3. If key not found:
   - Increment `manifest.stats.cache_misses`
   - Return MISS

4. Update hit_rate: `manifest.stats.hit_rate = cache_hits / (cache_hits + cache_misses)`

---

## Cache Write

**cache_write(key, tokens, content_summary)**

1. Read manifest

2. Check capacity:
   - If `manifest.stats.total_entries >= config.cache.max_entries`:
     - Evict LRU entries until under limit

3. Determine TTL from config based on key type:
   - `file:*` → `config.cache.ttl_by_type_minutes.file` (1440 = 24hr)
   - `search:grep:*` → `config.cache.ttl_by_type_minutes.search_grep` (60)
   - `search:glob:*` → `config.cache.ttl_by_type_minutes.search_glob` (120)

4. Create entry:
   ```json
   {
     "type": "<file|search>",
     "tokens_estimated": <tokens>,
     "tier": "hot",
     "created": "<now>",
     "last_accessed": "<now>",
     "last_referenced_turn": <current_turn>,
     "access_count": 1,
     "ttl_minutes": <ttl>,
     "summary": "<first 200 chars of content>"
   }
   ```

5. Add to manifest.entries[key]

6. Update stats:
   - `manifest.stats.total_entries++`
   - `manifest.stats.total_tokens_cached += tokens`

7. Write manifest atomically

---

## Cache Eviction

**evict_stale_entries()**

1. Read manifest

2. Get current time

3. For each entry in manifest.entries:
   - Calculate age: `age_minutes = (now - entry.created) / 60000`
   - Determine tier:
     - `age < 60` → hot
     - `age < 1440` → warm
     - `age < 10080` → cold
     - `age >= 10080` → evict
   - If evict OR `age > entry.ttl_minutes`:
     - Remove from entries
     - Decrement stats.total_entries
     - Subtract from stats.total_tokens_cached

4. Update manifest.last_cleanup to now

5. Write manifest atomically

6. Return count of evicted entries

---

## Alert Check

**check_budget_alert()**

1. Read manifest.current_session

2. Calculate usage percentage:
   ```
   total_used = tokens_used.input + tokens_used.output
   pct = (total_used / budget_tokens) × 100
   ```

3. Read config.budgets.alert_thresholds_pct (default: [50, 75, 90])

4. Determine highest crossed threshold:
   - If pct >= 90: severity = "CRITICAL"
   - If pct >= 75: severity = "HIGH"
   - If pct >= 50: severity = "WARN"
   - Else: no alert

5. If threshold crossed AND not already alerted at this level:
   - Output alert block (see output format below)
   - Mark threshold as alerted in session

---

## Cost Calculation

**calculate_cost(input_tokens, output_tokens)**

Using Claude pricing (adjust as needed):
```
INPUT_COST_PER_1K  = 0.003   # $3.00 per 1M input
OUTPUT_COST_PER_1K = 0.015   # $15.00 per 1M output
CACHED_COST_PER_1K = 0.0003  # $0.30 per 1M cached

input_cost = (input_tokens / 1000) × INPUT_COST_PER_1K
output_cost = (output_tokens / 1000) × OUTPUT_COST_PER_1K
cached_savings = (cached_tokens / 1000) × (INPUT_COST_PER_1K - CACHED_COST_PER_1K)
```

---

# COMMAND IMPLEMENTATIONS

## `/token_optimizer` (status)

**Procedure:**

1. Read manifest:
   ```powershell
   powershell -Command "Get-Content 'C:\Users\J\.claude\token-optimizer\cache\manifest.json' -Raw"
   ```

2. Extract current_session data

3. Calculate totals:
   - `total_used = current_session.tokens_used.input + current_session.tokens_used.output`
   - `pct = round((total_used / current_session.budget_tokens) × 100)`
   - `status = pct >= 90 ? "ALERT" : pct >= 75 ? "WARN" : "OK"`

4. Calculate category percentages from `current_session.by_category`

5. Output:
```
===========================================
TOKEN OPTIMIZER STATUS
===========================================
session_id: <current_session.id>
workstream: <current_session.workstream>
started: <current_session.started>

BUDGET
──────────────────────────────────────────
session:    <total_used> / <budget_tokens> (<pct>%)  [<status>]

CACHE
──────────────────────────────────────────
entries: <stats.total_entries> | tokens: <stats.total_tokens_cached> | hit_rate: <stats.hit_rate × 100>%

TOP CONSUMERS (this session)
──────────────────────────────────────────
1. file reads:      <by_category.file_reads> tokens (<pct>%)
2. search results:  <by_category.search_results> tokens (<pct>%)
3. system prompts:  <by_category.system_prompts> tokens (<pct>%)
4. tool outputs:    <by_category.tool_outputs> tokens (<pct>%)

type "/token_optimizer help" for commands
===========================================
```

---

## `/token_optimizer report`

**Procedure:**

1. Read manifest

2. Read metrics/aggregate.json if exists, else use current session only

3. Determine period:
   - Default: current session
   - `--period=day`: last 24 hours
   - `--period=week`: last 7 days
   - `--period=month`: last 30 days

4. Aggregate stats for period

5. Calculate costs using cost function

6. Generate recommendations:
   - If any file accessed > 10 times: "Consider pre-caching on /boot"
   - If search cache miss rate > 50%: "Increase search TTL"
   - If file_reads > 60% of total: "Use lazy loading for large files"

7. Output formatted report

---

## `/token_optimizer budget <amount>`

**Procedure:**

1. Parse amount (e.g., "100000" or "100K" → 100000)

2. Read manifest

3. Store old budget: `old = current_session.budget_tokens`

4. Update: `current_session.budget_tokens = amount`

5. Recalculate percentages

6. Write manifest atomically

7. Output:
```
===========================================
BUDGET UPDATED
===========================================
session budget: <old> → <amount> tokens
current usage:  <total_used> tokens (<pct>%)
remaining:      <amount - total_used> tokens

alert thresholds: 50% | 75% | 90%
===========================================
```

---

## `/token_optimizer cache status`

**Procedure:**

1. Read manifest

2. Count entries by tier:
   ```
   For each entry:
     age_minutes = (now - entry.created) / 60000
     if age < 60: hot++, hot_tokens += entry.tokens_estimated
     elif age < 1440: warm++, warm_tokens += ...
     else: cold++, cold_tokens += ...
   ```

3. Calculate hit rates by type:
   - Iterate entries, group by type prefix
   - Track hits/misses per type (stored in entry or inferred)

4. Sort entries by access_count descending, take top 3

5. Output formatted status

---

## `/token_optimizer cache clear`

**Procedure:**

1. Parse arguments:
   - `--all`: clear everything
   - `--stale`: clear only cold tier + expired
   - `file:*pattern*`: clear matching file entries
   - `search:*`: clear all search entries

2. Read manifest

3. Build list of entries to remove based on filter

4. For each entry to remove:
   - Delete from manifest.entries
   - If cached file exists in CACHE_DIR, delete it
   - Update stats

5. Reset stats if `--all`:
   ```json
   "stats": {
     "total_entries": 0,
     "total_tokens_cached": 0,
     "total_size_bytes": 0,
     "cache_hits": 0,
     "cache_misses": 0,
     "hit_rate": 0.0
   }
   ```

6. Write manifest atomically

7. Output:
```
===========================================
CACHE CLEARED
===========================================
removed: <count> entries
freed: <tokens> tokens
manifest reset: <yes if --all, else no>
===========================================
```

---

## `/token_optimizer unload <pattern>`

**Procedure:**

1. Parse pattern (glob-style)

2. Read manifest

3. Find matching entries:
   ```
   For each entry in manifest.entries:
     if entry.path matches pattern:
       matched.append(entry)
   ```

4. For each matched entry:
   - Remove from manifest.entries
   - Update stats
   - Record for output

5. Write manifest atomically

6. Output:
```
===========================================
CONTEXT UNLOADED
===========================================
pattern: <pattern>
matched: <count> entries
tokens freed: <sum of tokens>

remaining budget: <updated> / <limit> (<pct>%)

unloaded:
  - <path> (<tokens> tokens)
  - <path> (<tokens> tokens)
===========================================
```

---

## Budget Alert Output

When threshold crossed:
```
===========================================
TOKEN BUDGET ALERT (<pct>%)
===========================================
session: <used> / <limit> tokens used
remaining: <remaining> tokens

ACTIONS:
- /token_optimizer unload <suggest pattern based on stale entries>
- /token_optimizer cache clear --stale
- Consider new session if near limit
===========================================
```

---

# INTEGRATION HOOKS

## On File Read (Read tool)

After every Read tool call, track:
```
track_tokens("file_reads", <file_content>, <file_path>)
```

## On Search (Grep/Glob tool)

After every Grep/Glob call, track:
```
track_tokens("search_results", <search_output>, "search:<tool>:<pattern>")
```

## On /save_context

Include in saved JSON:
```json
"token_usage_summary": {
  "session_tokens_used": <total>,
  "cache_hit_rate": <rate>,
  "top_consumer": "<category>",
  "savings_tokens": <cached>,
  "cost_usd": <cost>
}
```

## On /load_context

Display in output:
```
PREVIOUS SESSION TOKENS:
  used: <n> | saved by cache: <n> (<pct>%)
```

## On /execute_full_plan

Add to diagnostics footer:
```
token_usage:
  - jh-security:        <n> tokens
  - jh-concurrency:     <n> tokens
  - ...
  - total_agent:        <n> tokens
  - cache_reused:       <n> tokens
```

---

# DATA SCHEMAS

## manifest.json (full)

```json
{
  "$schema": "token-optimizer-manifest-v1",
  "version": "1.0.0",
  "created": "2026-01-15T18:00:00Z",
  "last_cleanup": "2026-01-15T18:00:00Z",

  "stats": {
    "total_entries": 47,
    "total_tokens_cached": 12400,
    "total_size_bytes": 2400000,
    "cache_hits": 234,
    "cache_misses": 89,
    "hit_rate": 0.724
  },

  "current_session": {
    "id": "a1b2c3d4",
    "started": "2026-01-15T18:03:00Z",
    "workstream": "jhornlaw",
    "budget_tokens": 180000,
    "tokens_used": {
      "input": 45000,
      "output": 12000,
      "cached_input": 8000
    },
    "by_category": {
      "file_reads": 28000,
      "search_results": 9000,
      "system_prompts": 4000,
      "tool_outputs": 4000
    },
    "alerts_fired": []
  },

  "entries": {
    "file:C:\\Users\\J\\the_brain\\core\\retry.py:1705312000000:4523:a1b2c3d4": {
      "type": "file",
      "path": "C:\\Users\\J\\the_brain\\core\\retry.py",
      "tokens_estimated": 1130,
      "tier": "hot",
      "created": "2026-01-15T18:05:00Z",
      "last_accessed": "2026-01-15T18:30:00Z",
      "last_referenced_turn": 12,
      "access_count": 5,
      "ttl_minutes": 1440,
      "summary": "# retry.py - Exponential backoff retry logic..."
    }
  }
}
```

---

# CONFIGURATION REFERENCE

## config.json fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| budgets.session_default_tokens | int | 150000 | Default per-session budget |
| budgets.alert_thresholds_pct | int[] | [50,75,90] | Alert trigger points |
| cache.enabled | bool | true | Enable/disable caching |
| cache.max_entries | int | 500 | Max cache entries |
| cache.max_size_mb | int | 50 | Max cache disk size |
| cache.ttl_by_type_minutes.file | int | 1440 | File cache TTL (24hr) |
| cache.ttl_by_type_minutes.search_grep | int | 60 | Grep result TTL (1hr) |
| estimation.chars_per_token_base | int | 4 | Base char/token ratio |
| unload.staleness_turns | int | 10 | Turns before stale |
| workstream_overrides.{name} | object | {} | Per-project settings |

---

# QUICK START

1. Run `/boot` — initializes optimizer if configured
2. Work normally — tokens are tracked automatically
3. Run `/token_optimizer` — check status anytime
4. If alert fires — run suggested actions
5. Run `/token_optimizer report` — see full analysis
