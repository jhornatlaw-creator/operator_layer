---
name: jhornlaw
description: Law practice loader. Loads the_brain + AI_CORE/v4 as ONE system and applies the dual-workspace operating rules.
---

# JHORN Law Practice Loader

## Rule 0: Ensure Global Boot
If `/boot` has not been run in this thread, run `/boot` FIRST.

## Step 1: Load Dual Workspace State (MANDATORY)

Read:
- `C:\AI_CORE\v4\STATE.md` (canonical)
- `C:\Users\Dell\the_brain\STATE.md` (mirror)

These define the current architecture, operating rules, and propagation contract.

## Step 2: Confirm Dual Workspace Invariant

Restate:
- the_brain (`C:\Users\Dell\the_brain`) + AI_CORE/v4 (`C:\AI_CORE\v4`) are treated as ONE system.
- If a request touches either workspace, load both before doing any work.

## Step 3: Apply Law-Project Operating Defaults

Override initiative for this project:
- Initiative Level **3**: apply fixes, report after (no pre-approval), unless the user explicitly asks otherwise.

Also enforce:
- Self-test required before presenting results.
- Plain English + proof.
- Credentials sacred: never touch `.env`/tokens/keys.
- Use impact_scan/propagate patterns when changing mapped core units.

## Step 4: Optional Tooling (Only if needed)

If the task requires it and the user is in a local environment:
- Start the MCP legal tools server:
```powershell
Start-Process -NoNewWindow -FilePath "python" -ArgumentList "C:\AI_CORE\v4\.claude\mcp\legal_tools_server.py"
```

## Step 5: Report Ready

Confirm:
- both workspaces loaded
- last change summary (from STATE.md)
- initiative level set for this project (Level 3)

Then ask: "What are we doing inside law practice today?"
