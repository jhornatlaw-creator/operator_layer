# Rehydration & Memory Persistence (Operator Layer)

**Version:** 2026-01-30-p11
**Canonical spec for:** `/boot`, `/save_context`, `/load_context`, `/bootstrap_context`
**Changelog:** `C:\Users\J\.claude\CHANGELOG_OPERATOR_LAYER.md`
**Installer:** `C:\Users\J\.claude\INSTALLER_README.md`

---

## What Problem This Solves

Claude Code sessions are stateless by default. Each new thread starts fresh with no memory of previous work. This system provides:

1. **Automatic rehydration** - `/boot` loads previous session context without manual intervention
2. **Session persistence** - `/save_context` captures work for the next thread
3. **First-run bootstrap** - `/bootstrap_context` resolves the chicken-and-egg problem for new users
4. **One-command install** - `install.ps1` sets up operator layer on new machines
5. **Project memory** - Per-project `.claude/memory/` bundles accumulate verified facts, decisions, and runbook entries
6. **Multi-machine sync** - Conflict detection resolves sync conflicts (OneDrive/Dropbox) deterministically

---

## System Components

### Commands

| Command | Purpose | When to Use |
|---------|---------|-------------|
| `/boot` | Session startup + auto-rehydrate | Every new thread (mandatory) |
| `/save_context` | Persist session state | End of session or at breakpoints |
| `/load_context` | Deep restore (interactive) | When you want full session resume with loader |
| `/bootstrap_context` | Create baseline from scratch | First-time users or lost context |

### Files

| Path | Purpose | Written By |
|------|---------|------------|
| `C:\Users\J\.claude\context\latest.json` | Current session state | `/save_context`, `/bootstrap_context` |
| `C:\Users\J\.claude\context\session_*.json` | Timestamped archives | `/save_context`, `/bootstrap_context` |
| `C:\Users\J\.claude\context\machine_id.txt` | Machine identifier (sidecar) | `/save_context` |
| `C:\Users\J\.claude\context\latest.pointer` | Pointer to newest archive | `/save_context` |
| `C:\Users\J\.claude\context\CONFLICTS\` | Preserved conflict artifacts | `/boot` conflict detection |
| `<project>\.claude\memory\*.md` | Project memory bundle | `/save_context` |

### Install/Update Scripts

| Script | Purpose |
|--------|---------|
| `install.ps1` | One-command installer (new machines) |
| `update.ps1` | Pull updates, preserve user state |
| `release.ps1` | Build distributable release zip |
| `lib/download_release.ps1` | Download + verify release zip |
| `lib/schedule_updates.ps1` | Install/query/remove scheduled update tasks |
| `lib/verify_manifest.ps1` | Verify file integrity |

**Full docs:** See `INSTALLER_README.md`

---

## Install & Update

### Fresh Install

```powershell
# From local source
powershell -ExecutionPolicy Bypass -File install.ps1 -Source C:\path\to\source

# From git repository
powershell -ExecutionPolicy Bypass -File install.ps1 -Source https://github.com/user/repo.git

# From release zip (recommended for distribution)
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl C:\releases\operator_layer_p10.zip
```

### Update Existing

```powershell
# Check for updates (Local channel)
powershell -ExecutionPolicy Bypass -File update.ps1 -VerifyOnly

# Apply update (Local channel)
powershell -ExecutionPolicy Bypass -File update.ps1

# Check for updates (Release channel)
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <zip> -VerifyOnly

# Apply update (Release channel)
powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl <zip>
```

### Build Release

```powershell
# Build distributable zip from current installation
powershell -ExecutionPolicy Bypass -File release.ps1

# Output: releases\operator_layer_<version>.zip + .sha256
```

### Scheduled Updates

```powershell
# Install automatic update checking
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install

# Check status
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Query

# Remove tasks
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Remove
```

### Verify Installation

```powershell
powershell -ExecutionPolicy Bypass -File lib\verify_manifest.ps1
```

### What's Preserved

- `context\` (latest.json, archives) - **NEVER touched**
- `CLAUDE.md` (user config) - **NEVER touched**
- `rules\` (user rules) - **NEVER touched**

---

## Release Distribution (Phase 10A)

### Building a Release

From an existing installation:

```powershell
powershell -ExecutionPolicy Bypass -File release.ps1
```

Creates:
- `releases/operator_layer_<version>.zip` - Distributable archive
- `releases/operator_layer_<version>.sha256` - SHA256 hash
- `releases/operator_layer_manifest.json` - File manifest

**Excluded from release:**
- `context\*` (user session state)
- `logs\*` (runtime logs)
- `CLAUDE.md` (user config)
- `rules\*` (user rules)

### Installing on New Machines

1. Copy release zip to new machine
2. Run install:

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl <path-to-zip>
```

The installer:
- Verifies zip integrity
- Extracts to temp
- Verifies manifest
- Installs managed files (atomic)
- Preserves any existing `context\`

### Auto-Updates

Scheduled tasks can automatically check for and apply updates:

```powershell
# Install tasks (verify daily, update weekly)
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install

# Enable auto-apply (use with caution)
powershell -ExecutionPolicy Bypass -File lib\schedule_updates.ps1 -Install -AutoApply
```

Tasks:
- `ClaudeOps\OperatorLayerVerifyDaily` - 7:00 AM daily (check only)
- `ClaudeOps\OperatorLayerUpdateWeekly` - Sunday 4:00 AM (apply if -AutoApply)

---

## Normal Loop (Happy Path)

```
┌─────────────────────────────────────────────────────────────────┐
│  SESSION N                         SESSION N+1                  │
│                                                                 │
│  /boot ──────────────────────────► /boot                        │
│    │                                 │                          │
│    ▼                                 ▼                          │
│  REHYDRATION: LOADED              REHYDRATION: LOADED           │
│  (from previous session)          (from session N)              │
│    │                                 │                          │
│    ▼                                 ▼                          │
│  Work...                          Work...                       │
│    │                                                            │
│    ▼                                                            │
│  /save_context ─────────────────────────────────────────────────┤
│    │                                                            │
│    ├── latest.json (updated)                                    │
│    ├── session_YYYYMMDD_HHMM.json (archive)                     │
│    └── .claude/memory/*.md (bundle, if in managed repo)         │
└─────────────────────────────────────────────────────────────────┘
```

### Step-by-step

1. **Start session:** Run `/boot`
2. **Auto-rehydrate:** `/boot` reads `latest.json`, displays REHYDRATION block
3. **Load bundle:** `/boot` reads project memory (if present), displays MEMORY BUNDLE block
4. **Work:** Complete your tasks
5. **Persist:** Run `/save_context` before ending
6. **Verify:** Check WRITEBACK block shows `status: OK`

---

## Status Definitions

### REHYDRATION Status

| Status | Meaning | Action |
|--------|---------|--------|
| `LOADED` | Context loaded successfully | Proceed with session |
| `BLOCKED` | Cannot load context | Must resolve before proceeding |

**BLOCKED reasons:**
- `latest.json not found` → Run `/bootstrap_context`
- `invalid JSON` → Restore from archive
- `missing timestamp field` → Run `/bootstrap_context`
- `timestamp not parseable` → Run `/bootstrap_context`

### MEMORY BUNDLE Status

| Status | Meaning | Action |
|--------|---------|--------|
| `OK` | All bundle files loaded | None needed |
| `PARTIAL` | Some files missing/unreadable | Non-blocking; check permissions |
| `SKIPPED` | Not in a managed project | Non-blocking; expected for global work |

**Bundle is non-blocking.** Missing bundle does not halt boot.

### WRITEBACK Status

| Status | Meaning | Action |
|--------|---------|--------|
| `OK` | All writes succeeded | None needed |
| `PARTIAL` | Some writes failed | Check specific failures |
| `FAILED` | Critical write failed | See recovery section |

---

## BOOT GUARD (Safety Rails)

BOOT GUARD is a read-only safety check that runs early in `/boot` (after rehydration). It detects risky conditions and classifies the session into a safety mode.

### What It Detects

| Signal | Detection | Impact |
|--------|-----------|--------|
| Dirty repo | `git status --porcelain` non-empty | LOCKED (by default) |
| Unpushed commits | `git rev-list --count @{u}..HEAD` > 0 | CAUTION |
| Recent conflicts | Dirs in `context\CONFLICTS\` < 24h old | LOCKED (if policy enables) |
| Stale context | `latest.json` timestamp > 24h old | CAUTION |
| Live processes | Known bot/service patterns running | CAUTION |

### Safety Modes

| Mode | Meaning | Allowed Actions |
|------|---------|-----------------|
| **SAFE** | Environment is clean | All operations allowed |
| **CAUTION** | Minor risks detected | Proceed with warnings; avoid patch_apply |
| **LOCKED** | Critical risks detected | Boot halts; must resolve before proceeding |

### Non-Destructive Guarantee

BOOT GUARD is **read-only**. It will NEVER:
- Auto-stash or auto-commit
- Kill processes
- Modify git state
- Delete files

It only **reports** risks and **recommends** actions.

### Policy Configuration

Edit `C:\Users\J\.claude\lib\guard_policy.json`:

```json
{
  "policy_version": "2026-01-30-guard-v1",
  "lock_on_repo_dirty": true,
  "lock_on_recent_conflicts": false,
  "recent_conflicts_hours": 24,
  "context_stale_hours": 24
}
```

| Setting | Default | Effect |
|---------|---------|--------|
| `lock_on_repo_dirty` | `true` | LOCKED if uncommitted changes |
| `lock_on_recent_conflicts` | `false` | LOCKED if recent sync conflicts |
| `recent_conflicts_hours` | `24` | How recent is "recent" for conflicts |
| `context_stale_hours` | `24` | Threshold for stale context warning |

### Recovery from LOCKED

**Dirty repo:**
```powershell
git status
git add -A && git commit -m "wip: checkpoint"
# or
git stash -u
```

**Recent conflicts:**
```powershell
powershell -File C:\Users\J\.claude\lib\context_conflicts.ps1 -Normalize
```

Then re-run `/boot`.

### Manual Override

To bypass BOOT GUARD in emergencies:
1. Edit `guard_policy.json` and set `lock_on_repo_dirty: false`
2. Run `/boot`
3. **Restore** `lock_on_repo_dirty: true` immediately after

⚠️ **Not recommended.** BOOT GUARD exists to protect your work.

---

## Recovery Playbook

### Missing latest.json

**Symptom:**
```
REHYDRATION: BLOCKED
reason: latest.json not found
```

**Fix:**
```
/bootstrap_context
/boot
```

### Corrupt latest.json

**Symptom:**
```
REHYDRATION: BLOCKED
reason: invalid JSON in latest.json
```

**Fix:**
```powershell
# List available archives
dir C:\Users\J\.claude\context\session_*.json

# Restore newest valid archive
copy C:\Users\J\.claude\context\session_YYYYMMDD_HHMM.json C:\Users\J\.claude\context\latest.json

# Reboot
/boot
```

### Bundle PARTIAL

**Symptom:**
```
MEMORY BUNDLE: PARTIAL
missing: verified.md, runbook.md
```

**Fix:**
```powershell
# Ensure directory exists with correct permissions
mkdir <project>\.claude\memory

# Run save_context to create missing files
/save_context
```

### WRITEBACK FAILED

**Symptom:**
```
WRITEBACK: FAILED
reason: timestamp mismatch after write
```

**Fix:**
1. Check disk space: `dir C:\Users\J\.claude\context\`
2. Check permissions: `icacls C:\Users\J\.claude\context\`
3. Retry: `/save_context`
4. If repeated failures, restore from archive and report bug

---

## Conflict Resolution (Phase 8)

When multiple machines sync to the same context directory (OneDrive, Dropbox, etc.), conflicts can occur. The system automatically detects and resolves these.

### What Gets Detected

| Pattern | Example | Description |
|---------|---------|-------------|
| OneDrive conflict | `latest (DESKTOP-ABC conflicted copy).json` | OneDrive's conflict marker |
| Dropbox conflict | `latest (1).json` | Dropbox's duplicate marker |
| Generic copy | `latest - Copy.json` | Windows copy-paste duplicate |
| Stale latest | `latest.json` older than newest archive by >5 min | Indicates sync didn't complete |

### Resolution Rules (Deterministic)

When conflicts are detected, `/boot` resolves them automatically:

1. **Primary rule:** Newest parsed `timestamp` from JSON wins
2. **Tie-breaker 1:** Newest file `mtime` wins
3. **Tie-breaker 2:** Lexical filename sort (stable)

Invalid JSON files are preserved but cannot be winners.

### CONTEXT_CONFLICT Block

When `/boot` detects conflicts:

```
── CONTEXT_CONFLICT ────────────────────
status: RESOLVED
winner: latest (conflicted copy).json
rule: timestamp_newest
candidates: 3
preserved: context\CONFLICTS\20260130_120000\
normalized: true
────────────────────────────────────────
```

### Preservation Guarantee

All competing candidates are **copied** (never moved/deleted) to:
```
C:\Users\J\.claude\context\CONFLICTS\<YYYYMMDD_HHMMSS>\
```

Each folder contains:
- All candidate files
- `resolution.json` with full audit trail (winner, all candidates, timestamps, rule used)

### Manual Conflict Resolution

If automatic resolution is wrong:

```powershell
# List preserved conflicts
dir C:\Users\J\.claude\context\CONFLICTS\

# Read resolution.json to understand what happened
type C:\Users\J\.claude\context\CONFLICTS\<timestamp>\resolution.json

# Restore a different candidate as latest.json
copy C:\Users\J\.claude\context\CONFLICTS\<timestamp>\<preferred_file> C:\Users\J\.claude\context\latest.json
```

### Machine Identifier

Each machine writes a stable GUID to `context\machine_id.txt`. This helps identify which machine wrote which context file when debugging sync issues.

```powershell
# View machine ID
type C:\Users\J\.claude\context\machine_id.txt
```

### Pointer File

`context\latest.pointer` contains the filename of the newest archive. This provides a fallback reference when `latest.json` is corrupted or conflicted.

```powershell
# View pointer
type C:\Users\J\.claude\context\latest.pointer

# Restore from pointer
$archive = Get-Content 'C:\Users\J\.claude\context\latest.pointer'
copy "C:\Users\J\.claude\context\$archive" C:\Users\J\.claude\context\latest.json
```

---

## When to Use /load_context

| Scenario | Use |
|----------|-----|
| Starting fresh session | `/boot` (auto-rehydrates passively) |
| Resuming complex multi-day work | `/load_context` (deep restore) |
| Want project loader auto-run | `/load_context` |
| Just need context awareness | `/boot` |

**Key difference:**
- `/boot` = passive load (displays context, does NOT run project loader)
- `/load_context` = active restore (displays context AND runs project loader)

---

## Smoke Tests

### Location
```
C:\Users\J\.claude\lib\smoke_tests.ps1
```

### How to Run
```powershell
# Run all tests
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\smoke_tests.ps1" -RunAll

# Run specific test
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\smoke_tests.ps1" -TestA
```

### Available Tests

| Flag | Test | Verifies |
|------|------|----------|
| `-TestA` | Bootstrap → Boot | First-run recovery works |
| `-TestB` | Save → Boot | Timestamp updates correctly |
| `-TestC` | Corrupt JSON | Invalid JSON is blocked |
| `-TestD` | Bundle detection | OK/PARTIAL/SKIPPED logic |
| `-RunAll` | All tests | Full system validation |

### Expected Output
```
ALL TESTS PASSED (4/4)
```

### Safety
- No secrets accessed
- No network required
- Backs up and restores `latest.json` automatically

---

## FAQ

### Why gate on JSON but not bundle?

**JSON is authoritative.** The `latest.json` file is the single source of truth for session state. If it's missing or corrupt, we cannot safely proceed because we don't know what the user was working on.

**Bundle is supplementary.** The memory bundle (verified facts, decisions, runbook) enhances context but isn't required for basic operation. A missing bundle just means less historical context—not a broken session.

### How is freshness calculated?

```
age_hours = (current_time - timestamp_from_json) in hours
```

The `timestamp` field in `latest.json` is set by `/save_context` at the moment of save. `/boot` compares this to current time.

**Warnings:**
- `> 24 hours`: "Session context is >24 hours old"
- `> 168 hours (7 days)`: "Consider starting fresh"

### What are the markers?

When running `/save_context`, include these prefixes in your session `notes` to trigger bundle writes:

| Marker | Target File | Example |
|--------|-------------|---------|
| `DECISION: <text>` | decisions.md | `DECISION: Use PostgreSQL for scale` |
| `VERIFIED: <text>` | verified.md | `VERIFIED: API rate limit is 100/min` |
| `RUNBOOK: <symptom> -> <fix>` | runbook.md | `RUNBOOK: Chrome crash -> increase shm` |
| `UPDATE_CONTEXT: true` | context.md | Triggers full context rewrite |

If no markers present, only `progress.md` is updated.

### Is /bootstrap_context idempotent?

**Yes, but destructive.** Running `/bootstrap_context` overwrites `latest.json` with a minimal baseline. If you have existing context, it will be lost (though an archive is created).

Use only when:
- First-time setup
- All archives are corrupt/missing
- Intentional context reset

### What's the schema for latest.json?

See `boot.md` Appendix: latest.json Schema Reference.

**Required:** `timestamp` (ISO8601 string)
**Optional:** All other fields (default safely to empty/none)

---

## Maintenance

### Maintenance Script

Location: `C:\Users\J\.claude\lib\maintenance.ps1`

**Capabilities:**
- Validate `latest.json` integrity (parse, timestamp, schema)
- Validate newest archive integrity
- Check memory bundle presence in managed repos
- Enforce archive retention policy
- Run smoke tests

### How to Run

```powershell
# Preview what would happen (no changes)
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1" -DryRun

# Run integrity checks only
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1"

# Enforce retention (keep last 30 days)
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1" -EnforceRetention -KeepDays 30

# Enforce retention (keep last 20 archives)
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1" -EnforceRetention -KeepCount 20

# Run with smoke tests
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1" -RunSmoke

# Full maintenance (dry-run first!)
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\maintenance.ps1" -EnforceRetention -KeepDays 30 -RunSmoke
```

### Recommended Schedule

| Frequency | Command |
|-----------|---------|
| Weekly | `-DryRun` to preview |
| Monthly | `-EnforceRetention -KeepDays 30` |
| After issues | `-RunSmoke` |

---

## Retention Policy

### Default Policy

- **Keep:** Last 30 days of archives OR last 20 archives (whichever is more conservative)
- **Location:** `C:\Users\J\.claude\context\session_*.json`
- **Enforcement:** Manual via `maintenance.ps1 -EnforceRetention`

### Why Retention Matters

Archives accumulate with each `/save_context`. Without cleanup:
- Disk usage grows indefinitely
- Listing archives becomes slow
- Old archives lose relevance

### Manual Cleanup

If not using the maintenance script:
```powershell
# List archives by date
Get-ChildItem 'C:\Users\J\.claude\context\session_*.json' | Sort-Object LastWriteTime

# Delete archives older than 30 days
Get-ChildItem 'C:\Users\J\.claude\context\session_*.json' |
  Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } |
  Remove-Item
```

---

## Scheduled Maintenance (Phase 9)

Automate maintenance with Windows scheduled tasks.

### Installation

```powershell
# Install scheduled tasks
powershell -ExecutionPolicy Bypass -File C:\Users\J\.claude\lib\schedule_maintenance.ps1 -Install

# Optional: Include weekly smoke tests
powershell -ExecutionPolicy Bypass -File C:\Users\J\.claude\lib\schedule_maintenance.ps1 -Install -IncludeSmoke
```

### What Gets Scheduled

| Task | Schedule | Action |
|------|----------|--------|
| `ClaudeOps\MaintenanceDaily` | Daily at 6:00 AM | Integrity scan + conflict detection (DryRun) |
| `ClaudeOps\MaintenanceWeekly` | Sunday at 3:00 AM | Archive retention (keep 30 days) + conflicts |

### Verification

```powershell
# Query task status
powershell -ExecutionPolicy Bypass -File C:\Users\J\.claude\lib\schedule_maintenance.ps1 -Query

# Or use schtasks directly
schtasks /Query /TN "ClaudeOps\MaintenanceDaily"
schtasks /Query /TN "ClaudeOps\MaintenanceWeekly"
```

### Manual Trigger

```powershell
# Run daily task on-demand
schtasks /Run /TN "ClaudeOps\MaintenanceDaily"

# Check result
Get-Content C:\Users\J\.claude\lib\maintenance_status.json
```

### Removal

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\J\.claude\lib\schedule_maintenance.ps1 -Remove
```

### Alerts and Logs

**Notifications:**
- On WARN/ERROR: Windows toast notification sent
- Status written to `lib\maintenance_status.json`

**Log files:**
- Location: `C:\Users\J\.claude\logs\maintenance\`
- Format: `maintenance_YYYYMMDD_HHMMSS.log`
- Contains full output of each maintenance run

**Viewing last status:**
```powershell
Get-Content C:\Users\J\.claude\lib\maintenance_status.json | ConvertFrom-Json
```

### /boot Integration

When scheduled maintenance is configured, `/boot` displays:
```
maintenance_last: 4.2h | status: OK
```

A WARNING is shown if last status was ERROR.

---

## Rollback Procedure

### When to Rollback

- Command behavior changed unexpectedly
- `/boot` started blocking incorrectly
- `/save_context` corrupts data
- Need to restore previous operator layer version

### Steps

**1. Identify target version**

Check changelog: `C:\Users\J\.claude\CHANGELOG_OPERATOR_LAYER.md`

**2. Restore command files**

If using git:
```bash
git checkout <commit> -- .claude/commands/
```

If backup exists:
```powershell
# Restore from backup
Copy-Item "backup\commands\*" "C:\Users\J\.claude\commands\" -Force
```

**3. Restore latest.json from archive**

```powershell
# List available archives
Get-ChildItem 'C:\Users\J\.claude\context\session_*.json' | Sort-Object LastWriteTime -Descending

# Restore from specific archive
Copy-Item 'C:\Users\J\.claude\context\session_20260130_0934.json' 'C:\Users\J\.claude\context\latest.json' -Force
```

**4. Verify**

```powershell
# Run smoke tests
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\smoke_tests.ps1" -RunAll
```

### Emergency Recovery

If everything is broken:
```powershell
# 1. Delete corrupt latest.json
Remove-Item 'C:\Users\J\.claude\context\latest.json' -Force

# 2. Bootstrap fresh
# (Run /bootstrap_context in Claude Code)

# 3. Or restore from any valid archive
Copy-Item 'C:\Users\J\.claude\context\session_*.json' 'C:\Users\J\.claude\context\latest.json'
```

---

## Release Management

### Version Naming

Format: `YYYY-MM-DD-pN`
- `YYYY-MM-DD` = release date
- `pN` = patch number (p1, p2, p3...)

Example: `2026-01-30-p6`

### Release Checklist

Before releasing a new version:

1. **Run smoke tests:** `smoke_tests.ps1 -RunAll` → ALL PASS
2. **Run maintenance:** `maintenance.ps1 -DryRun` → no errors
3. **Update version:** Bump `operator_layer_version` in command files
4. **Update changelog:** Add entry to `CHANGELOG_OPERATOR_LAYER.md`
5. **Update runbook:** Bump version + add to Version History

### Current Version

```
operator_layer_version: 2026-01-30-p9
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| p11 | 2026-01-30 | BOOT GUARD safety rails, guard_mode diagnostic, policy configuration |
| p10 | 2026-01-30 | Release distribution, scheduled updates, -ReleaseUrl install |
| p9 | 2026-01-30 | Scheduled maintenance, notifications, logging, /boot status integration |
| p8 | 2026-01-30 | Multi-machine sync, conflict detection/resolution, machine_id.txt, latest.pointer |
| p7 | 2026-01-30 | One-command installer, updater, manifest verification |
| p6 | 2026-01-30 | Maintenance script, retention policy, rollback procedure, changelog |
| p5 | 2026-01-30 | Bootstrap command, schema validation, smoke tests |
| p4 | 2026-01-30 | Memory bundle loading, timestamp verification |
| p3 | 2026-01-30 | Bundle write-back, marker system |
| p2 | 2026-01-30 | Atomic writes, mandatory archiving |
| p1 | 2026-01-30 | Auto-rehydration gate in /boot |

---

## Quick Reference Card

```
FRESH INSTALL:  powershell ... install.ps1 -Source <path>
UPDATE:         powershell ... update.ps1
FIRST TIME:     /bootstrap_context → /boot
EVERY SESSION:  /boot → work → /save_context
DEEP RESTORE:   /load_context
SMOKE TEST:     powershell ... smoke_tests.ps1 -RunAll
MAINTENANCE:    powershell ... maintenance.ps1 -DryRun
VERIFY:         powershell ... verify_manifest.ps1
CONFLICTS:      powershell ... context_conflicts.ps1
SCHEDULE:       powershell ... schedule_maintenance.ps1 -Install

BLOCKED?        Check reason, follow recovery playbook
PARTIAL?        Non-blocking, check permissions
FAILED?         Check disk/permissions, retry
CONFLICT?       Check context\CONFLICTS\, see Conflict Resolution section
ROLLBACK?       See Rollback Procedure section
SCHEDULE?       powershell ... schedule_maintenance.ps1 -Query
```
