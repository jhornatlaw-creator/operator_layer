---
name: polymarket
description: Load Polymarket prediction market trading bot context
---

# /polymarket - Prediction Market Trading Bot

Load the Polymarket trading bot workspace for development, testing, and operations.

## Workspace

| Item | Value |
|------|-------|
| Path | `C:\Users\J\polymarket` |
| GitHub | https://github.com/jhornatlaw-creator/polymarket-bot |
| Tests | 1753+ passing |

## Boot Sequence

1. Read `C:\Users\J\polymarket\STATE.md`
2. Check git status: `git -C "C:\Users\J\polymarket" status --short`
3. Check test count: `powershell -Command "Set-Location C:\Users\J\polymarket; python -m pytest --collect-only -q 2>$null | Select-String 'test'"`

## Critical Safety Rules

### NEVER
- Commit secrets, API keys, or credentials
- Enable live trading without explicit `--yes-really-launch` flag
- Bypass kill switch or robustness checks
- Log sensitive data (private keys, API responses with PII)

### ALWAYS
- Run tests before committing: `python -m pytest tests/ -q`
- Update STATE.md after significant changes
- Use Decimal for all prices (never floats)
- Check robustness gate before live launch

## Price Convention

**ALL prices are Decimal (0.01-0.99).** Polymarket uses probability pricing.
- BUY YES at 0.55 = pay 55 cents, win $1 if YES
- Spread = best_ask - best_bid

## CLI Quick Reference

```powershell
# Zero-creds demo (proves code works)
pm demo

# Confidence ladder
pm ladder
pm ladder --robust  # Robustness gate

# Release check
pm ops release-check
pm ops release-check --require-robust

# Paper trading
pm run-paper TOKEN_ID --fair-value 0.55

# Live trading (DANGER - requires flag + robustness)
pm launch-live TOKEN_ID -f TOKEN_ID:0.55 --require-robust --yes-really-launch

# Kill switch
pm ops kill-switch on --reason "manual stop"
pm ops kill-switch off

# Doctor/health
pm ops doctor
pm ops preflight-live --network
```

## Ticket Status (Current: 54)

### Complete
- Tickets 1-54: Full trading infrastructure
- Demo pipeline, backtest, sweep, walkforward
- Confidence ladder, robustness gate
- Launch pipeline with canary, gate, ramp
- Resume from crash
- Realism Pack v1 (5 datasets)

### Key Features
- **Demo**: Zero-dependency proof-of-concept
- **Ladder**: demo → backtest → sweep → walkforward → export
- **Robustness**: Scenario regression testing across datasets
- **Launch**: preflight → canary → gate → ramp → live
- **Resume**: Crash-safe continuation from bundle

## Directory Structure

```
src/pm/
  backtest/     # Replay engine, IO, events
  clob/         # CLOB client, models, WebSocket
  config.py     # Pydantic Settings
  datasets/     # Realism Pack v1, generators
  demo/         # Demo, ladder, robustness
  live/         # Launch, canary, ramp, runner
  ops/          # Alerts, preflight, backup, bundle
  risk/         # Risk manager, policies
  strategy/     # DirectionalV1 strategy
tests/
  fixtures/     # Golden traces, payloads
```

## Workflow

| Role | Owner |
|------|-------|
| Planning | Claude |
| Architecture | GPT |
| Building | Claude |
| Review | GPT + Claude |
| GitHub | Claude (lead) |

## Config

- `.env` - Local environment (gitignored)
- `.env.example` - Template with placeholders
- `src/pm/config.py` - Pydantic Settings

Required for live:
```
POLYGON_PRIVATE_KEY=
CLOB_FUNDER=
```

## Release Workflow

```bash
# 1. Run robustness gate
pm ladder --robust

# 2. Validate release
pm ops release-check --require-robust

# 3. Launch with robustness required
pm launch-live TOKEN -f TOKEN:0.55 --require-robust --yes-really-launch
```
