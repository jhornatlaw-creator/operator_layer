<#
.SYNOPSIS
    Download and verify a release package.

.DESCRIPTION
    Downloads a release zip from URL or local path, verifies SHA256 hash,
    and extracts to a staging directory for installation.

    Supports:
    - Local file paths
    - HTTPS URLs
    - Optional hash verification via .sha256 file or direct hash

.PARAMETER Url
    URL or local path to the release zip file.

.PARAMETER ExpectedHash
    Expected SHA256 hash (optional). If provided, verifies against this.

.PARAMETER HashUrl
    URL to .sha256 file containing hash (optional).

.PARAMETER OutputDir
    Directory to extract the release. Default: temp directory.

.PARAMETER KeepZip
    Don't delete the downloaded zip after extraction.

.EXAMPLE
    $result = & download_release.ps1 -Url "C:\releases\operator_layer_p10.zip"
    # Extract from local file

.EXAMPLE
    $result = & download_release.ps1 -Url "https://example.com/release.zip" -HashUrl "https://example.com/release.sha256"
    # Download and verify from URL

.OUTPUTS
    Returns a hashtable:
    @{
        Success = $true/$false
        ExtractPath = "path to extracted files"
        ZipHash = "sha256 of zip"
        ManifestPath = "path to manifest in extracted files"
        Error = "error message if failed"
    }

.NOTES
    operator_layer_version: 2026-01-30-p10

    Fail-safe behavior:
    - Network failure: retry 3x with backoff
    - Hash mismatch: delete downloaded file, return failure
    - Missing manifest in zip: return failure
    - Never proceeds with corrupt/unverified release
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Url,

    [string]$ExpectedHash,
    [string]$HashUrl,
    [string]$OutputDir,
    [switch]$KeepZip
)

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]   $msg" -ForegroundColor Green }
        "FAIL" { Write-Host "[FAIL] $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO] $msg" -ForegroundColor Gray }
        "WARN" { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
    }
}

function Get-FileHash256($path) {
    if (-not (Test-Path $path)) { return $null }
    return (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLower()
}

function Test-IsUrl($str) {
    return $str -match "^https?://"
}

function Invoke-DownloadWithRetry {
    param(
        [string]$DownloadUrl,
        [string]$DestinationPath,
        [int]$MaxRetries = 3
    )

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
        try {
            Write-Status "INFO" "Download attempt $attempt of $MaxRetries..."

            # Use TLS 1.2
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $webClient = New-Object System.Net.WebClient
            $webClient.DownloadFile($DownloadUrl, $DestinationPath)
            $webClient.Dispose()

            if (Test-Path $DestinationPath) {
                return $true
            }
        } catch {
            Write-Status "WARN" "Attempt $attempt failed: $_"

            if ($attempt -lt $MaxRetries) {
                $backoffSeconds = [math]::Pow(2, $attempt)
                Write-Status "INFO" "Waiting $backoffSeconds seconds before retry..."
                Start-Sleep -Seconds $backoffSeconds
            }
        }
    }

    return $false
}

# ============================================================
# MAIN
# ============================================================

$result = @{
    Success = $false
    ExtractPath = $null
    ZipHash = $null
    ManifestPath = $null
    Error = $null
}

Write-Host ""
Write-Host "-- Downloading Release --" -ForegroundColor Cyan

$isUrl = Test-IsUrl $Url
$zipPath = $null
$tempZipCreated = $false

# ── Step 1: Get the zip file ──
if ($isUrl) {
    Write-Status "INFO" "Source: $Url (HTTPS)"

    # Download to temp
    $tempZip = Join-Path $env:TEMP "operator_layer_download_$(Get-Date -Format 'yyyyMMdd_HHmmss').zip"

    $downloadSuccess = Invoke-DownloadWithRetry -DownloadUrl $Url -DestinationPath $tempZip
    if (-not $downloadSuccess) {
        $result.Error = "Failed to download from $Url after 3 attempts"
        Write-Status "FAIL" $result.Error
        return $result
    }

    $zipPath = $tempZip
    $tempZipCreated = $true
    Write-Status "OK" "Downloaded to temp"
} else {
    Write-Status "INFO" "Source: $Url (local file)"

    if (-not (Test-Path $Url)) {
        $result.Error = "File not found: $Url"
        Write-Status "FAIL" $result.Error
        return $result
    }

    $zipPath = $Url
}

# ── Step 2: Get expected hash ──
$verifyHash = $null

if ($ExpectedHash) {
    $verifyHash = $ExpectedHash.ToLower()
    Write-Status "INFO" "Expected hash provided: $($verifyHash.Substring(0, 16))..."
}
elseif ($HashUrl) {
    Write-Status "INFO" "Fetching hash from: $HashUrl"

    try {
        if (Test-IsUrl $HashUrl) {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $hashContent = (Invoke-WebRequest -Uri $HashUrl -UseBasicParsing).Content
        } else {
            $hashContent = Get-Content $HashUrl -Raw
        }

        # Parse hash file (format: "hash  filename" or just "hash")
        $hashContent = $hashContent.Trim()
        if ($hashContent -match "^([a-fA-F0-9]{64})") {
            $verifyHash = $matches[1].ToLower()
            Write-Status "OK" "Got hash: $($verifyHash.Substring(0, 16))..."
        } else {
            Write-Status "WARN" "Could not parse hash file"
        }
    } catch {
        Write-Status "WARN" "Failed to fetch hash file: $_"
    }
}
else {
    # Try to find .sha256 file alongside the zip
    $autoHashPath = $Url -replace "\.zip$", ".sha256"

    if (-not $isUrl -and (Test-Path $autoHashPath)) {
        try {
            $hashContent = (Get-Content $autoHashPath -Raw).Trim()
            if ($hashContent -match "^([a-fA-F0-9]{64})") {
                $verifyHash = $matches[1].ToLower()
                Write-Status "INFO" "Auto-found hash file: $autoHashPath"
            }
        } catch {
            # Ignore
        }
    }
}

# ── Step 3: Verify hash ──
Write-Host ""
Write-Host "-- Verifying integrity --" -ForegroundColor Cyan

$actualHash = Get-FileHash256 $zipPath
$result.ZipHash = $actualHash

Write-Status "INFO" "Actual hash: $($actualHash.Substring(0, 16))..."

if ($verifyHash) {
    if ($actualHash -eq $verifyHash) {
        Write-Status "OK" "Hash verified"
    } else {
        $result.Error = "Hash mismatch! Expected $($verifyHash.Substring(0, 16))..., got $($actualHash.Substring(0, 16))..."
        Write-Status "FAIL" $result.Error

        # Clean up downloaded file
        if ($tempZipCreated) {
            Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
        }

        return $result
    }
} else {
    Write-Status "WARN" "No hash provided - cannot verify integrity"
    Write-Status "INFO" "Proceeding without verification (use -ExpectedHash or -HashUrl for security)"
}

# ── Step 4: Extract ──
Write-Host ""
Write-Host "-- Extracting release --" -ForegroundColor Cyan

if (-not $OutputDir) {
    $OutputDir = Join-Path $env:TEMP "operator_layer_extract_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
}

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

try {
    Expand-Archive -Path $zipPath -DestinationPath $OutputDir -Force
    Write-Status "OK" "Extracted to: $OutputDir"
} catch {
    $result.Error = "Failed to extract zip: $_"
    Write-Status "FAIL" $result.Error

    if ($tempZipCreated) {
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    }

    return $result
}

$result.ExtractPath = $OutputDir

# ── Step 5: Verify manifest exists ──
$manifestPath = Join-Path $OutputDir "operator_layer_manifest.json"

if (-not (Test-Path $manifestPath)) {
    $result.Error = "Release is invalid: missing operator_layer_manifest.json"
    Write-Status "FAIL" $result.Error

    # Clean up
    Remove-Item -Recurse -Force $OutputDir -ErrorAction SilentlyContinue
    if ($tempZipCreated) {
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    }

    return $result
}

$result.ManifestPath = $manifestPath
Write-Status "OK" "Manifest found"

# Verify manifest is valid JSON
try {
    $manifestContent = Get-Content $manifestPath -Raw | ConvertFrom-Json
    Write-Status "OK" "Manifest valid (version: $($manifestContent.version))"
} catch {
    $result.Error = "Invalid manifest JSON: $_"
    Write-Status "FAIL" $result.Error

    Remove-Item -Recurse -Force $OutputDir -ErrorAction SilentlyContinue
    if ($tempZipCreated) {
        Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    }

    return $result
}

# ── Step 6: Cleanup temp zip ──
if ($tempZipCreated -and -not $KeepZip) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Write-Status "INFO" "Cleaned up temp zip"
}

# ── Success ──
$result.Success = $true

Write-Host ""
Write-Status "OK" "DOWNLOAD: VERIFIED"
Write-Host "  Extract path: $OutputDir" -ForegroundColor Gray
Write-Host "  Hash: $actualHash" -ForegroundColor Gray
Write-Host ""

return $result
