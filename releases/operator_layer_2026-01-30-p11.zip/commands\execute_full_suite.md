---
name: execute_full_suite
description: Alias for /execute_full_plan (six-lane parallel review).
---

Run `/execute_full_plan`.
