# TXDPS Deep Dive

Search Texas Department of Public Safety criminal records via PublicData.com and extract conviction counts + full statutory offense descriptions.

## What This Does

1. Logs into PublicData.com
2. Navigates to TXDPS-only database (state criminal records)
3. Searches by defendant name
4. Matches person by DOB verification
5. Counts "CONVICTED" occurrences on detail page
6. Extracts full statutory offense descriptions via GPT-4o-mini
7. Returns conviction count, offenses, and verification status

## Script Locations

### Python (Harris - standalone adapter)
```
C:\Users\J\the_brain\lib\adapters\txdps_deepdive.py
C:\Users\J\the_brain\counties\harris_live\harris_pd_deepdive_runner.py
```

### JavaScript (Montgomery - embedded in scrapers)
```
C:\Users\J\the_brain\counties\montgomery\montmisd.js
C:\Users\J\the_brain\counties\montgomery\felony\montfelony.js
(+ 6 other Montgomery scrapers)
```

## Usage

### Python - Single Lookup
```python
from lib.adapters.txdps_deepdive import txdps_deep_dive

result = txdps_deep_dive("SMITH, JOHN", dob="1990-05-15", headless=True)
print(f"Convictions: {result['conviction_count']}")
print(f"Offenses: {result['offenses']}")
print(f"Verified: {result['verified']}")
```

### Python - Context Manager (multiple lookups)
```python
from lib.adapters.txdps_deepdive import TXDPSDeepDive

with TXDPSDeepDive(headless=True) as txdps:
    result1 = txdps.search("SMITH, JOHN", "1990-05-15")
    result2 = txdps.search("DOE, JANE", "1985-03-22")
    # Browser stays open between searches
```

### Python - Batch Processing (Harris)
```bash
cd C:\Users\J\the_brain\counties\harris_live
python harris_pd_deepdive_runner.py "C:\path\to\harris_cases.csv"
```

### JavaScript (Montgomery) - Automatic
Deep dive runs automatically during scraper execution when `PD_TxDPS === 'Y'`:
```bash
node montmisd.js --today
# Deep dive auto-triggers for TXDPS hits
```

## Result Object

```javascript
{
  conviction_count: 3,           // Number of "CONVICTED" on page
  offenses: "AGG ASSLT CAUSES SERIOUS BODILY INJ; DWI 3RD OR MORE",  // GPT-extracted
  verified: "Y",                 // Y = DOB matched, N = no match, SINGLE_RECORD = only one result
  error: ""                      // Error message if failed
}
```

## Output Columns Added to CSV

| Column | Description |
|--------|-------------|
| PD_TxDPS | Y/N - Has TXDPS record |
| PD_DPS_ConvictionCount | Number of convictions found |
| PD_DPS_Offenses | Full statutory offense descriptions (GPT-extracted) |
| PD_DPS_Verified | Y/N/SINGLE_RECORD - DOB verification status |

## Offense Extraction

### GPT-4o-mini (Primary)
Extracts full statutory language from the TXDPS detail page:
```
AGG ASSLT CAUSES SERIOUS BODILY INJ; TERRORISTIC THREAT OF FAMILY/HOUSEHOLD
DRIVING W/LIC INV W/PREV CONV/SUSP/W/O FIN RES
MAN/DEL CS PG 3/4 >=200G < 400G
```

### Keyword Fallback (if GPT fails)
Falls back to keyword detection:
```
DWI; ASSAULT; THEFT
```

## Environment Variables

Set in `C:\Users\J\the_brain\.env`:
```
PUBLICDATA_USERNAME=your_username
PUBLICDATA_PASSWORD=your_password
OPENAI_API_KEY=your_openai_key
```

## Workflow Integration

### Harris Pipeline
```
harris_unified.py
  └── PublicData search (all defendants)
      └── If PD_TxDPS === 'Y':
          └── txdps_deepdive.py (conviction details)
```

### Montgomery Scrapers
```
montmisd.js / montfelony.js
  └── searchPublicData() for each defendant
      └── If txdps === 'Y':
          └── txdpsDeepDive() inline function
```

## DOB Normalization

Accepts multiple date formats:
- `1990-05-15` (ISO)
- `05/15/1990` (US slash)
- `May 15 1990` (Month name)
- `15 May 1990` (Day first)

All normalized internally to `YYYY-MM-DD` for matching.

## Screenshots (Debug)

Montgomery scrapers save debug screenshots to:
```
./screenshots/deep_dive/
  dd_1_main_LASTNAME_FIRST.png
  dd_2_txdps_LASTNAME_FIRST.png
  dd_3_search_LASTNAME_FIRST.png
  dd_4_detail_LASTNAME_FIRST.png
```

## Quick Test

```bash
cd C:\Users\J\the_brain
python -c "
from lib.adapters.txdps_deepdive import txdps_deep_dive
result = txdps_deep_dive('JEFFERSON, DAPHENE', '1992-06-20')
print(result)
"
```

## Notes

- TXDPS = Texas Department of Public Safety (state-level criminal records)
- Different from county records (Harris, Montgomery) also on PublicData
- Deep dive only runs on confirmed TXDPS hits to avoid unnecessary API calls
- GPT extraction added 2026-01-19 for full statutory offense descriptions
