<#
.SYNOPSIS
    Install, query, or remove scheduled update tasks for the operator layer.

.DESCRIPTION
    Creates Windows scheduled tasks that automatically check for and apply updates:
    - Daily: Verify-only check (no changes applied)
    - Weekly: Apply available updates (if configured)

    Tasks run as the current user and send notifications on issues.

.PARAMETER Install
    Create the scheduled tasks.

.PARAMETER Query
    Show current task status.

.PARAMETER Remove
    Delete the scheduled tasks.

.PARAMETER VerifyTime
    Time for daily verify task. Default: "07:00"

.PARAMETER UpdateDay
    Day for weekly update task. Default: "Sunday"

.PARAMETER UpdateTime
    Time for weekly update task. Default: "04:00"

.PARAMETER Channel
    Update channel. Default: "Release"

.PARAMETER ReleaseIndexUrl
    URL to release index.json (optional, baked into task).

.PARAMETER AutoApply
    If set, weekly task applies updates automatically. Otherwise verify-only.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_updates.ps1 -Install
    # Creates daily verify and weekly update tasks

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_updates.ps1 -Query
    # Shows current task status

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File schedule_updates.ps1 -Remove
    # Removes all update tasks

.NOTES
    operator_layer_version: 2026-01-30-p10

    Task names:
    - ClaudeOps\OperatorLayerVerifyDaily
    - ClaudeOps\OperatorLayerUpdateWeekly

    The tasks run silently and send Windows notifications on WARN/ERROR.
    Status written to: C:\Users\J\.claude\lib\update_status.json
    Logs written to: C:\Users\J\.claude\logs\updates\
#>

param(
    [switch]$Install,
    [switch]$Query,
    [switch]$Remove,
    [string]$VerifyTime = "07:00",
    [string]$UpdateDay = "Sunday",
    [string]$UpdateTime = "04:00",
    [string]$Channel = "Release",
    [string]$ReleaseIndexUrl,
    [switch]$AutoApply
)

$TaskFolder = "ClaudeOps"
$VerifyTaskName = "$TaskFolder\OperatorLayerVerifyDaily"
$UpdateTaskName = "$TaskFolder\OperatorLayerUpdateWeekly"
$UpdateScript = "C:\Users\J\.claude\update.ps1"
$NotifyScript = "C:\Users\J\.claude\lib\notify.ps1"
$StatusFile = "C:\Users\J\.claude\lib\update_status.json"
$LogDir = "C:\Users\J\.claude\logs\updates"
$PowerShellPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]     $msg" -ForegroundColor Green }
        "FAIL" { Write-Host "[FAIL]   $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO]   $msg" -ForegroundColor Gray }
        "WARN" { Write-Host "[WARN]   $msg" -ForegroundColor Yellow }
    }
}

function Get-TaskExists($taskName) {
    try {
        $shortName = $taskName -replace "^$TaskFolder\\", ""
        $task = Get-ScheduledTask -TaskName $shortName -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue
        return $null -ne $task
    } catch {
        return $false
    }
}

function Write-UpdateStatus {
    param(
        [string]$Status,
        [string]$Channel,
        [string]$CurrentVersion,
        [string]$AvailableVersion,
        [string]$LastAction
    )

    $statusObj = @{
        last_check_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        status = $Status
        channel = $Channel
        current_version = $CurrentVersion
        available_version = $AvailableVersion
        last_action = $LastAction
    }

    try {
        $statusObj | ConvertTo-Json -Depth 5 | Set-Content $StatusFile -Encoding UTF8
    } catch {
        # Ignore write errors
    }
}

function Install-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  INSTALLING SCHEDULED UPDATE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    # Check if update script exists
    if (-not (Test-Path $UpdateScript)) {
        Write-Status "FAIL" "Update script not found: $UpdateScript"
        exit 1
    }
    Write-Status "OK" "Update script found"

    # Ensure log directory exists
    if (-not (Test-Path $LogDir)) {
        New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
        Write-Status "OK" "Created log directory"
    }

    # Build wrapper script that logs and notifies
    # The wrapper handles logging and notification since Task Scheduler doesn't capture output well
    $wrapperContent = @"

`$ErrorActionPreference = 'Continue'
`$logFile = "$LogDir\update_`$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Redirect all output to log
Start-Transcript -Path `$logFile -Force | Out-Null

try {
    & "$UpdateScript" -Channel $Channel -VerifyOnly
    `$exitCode = `$LASTEXITCODE

    # Write status
    `$status = @{
        last_check_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        status = if (`$exitCode -eq 0) { "OK" } else { "ERROR" }
        channel = "$Channel"
        log_file = `$logFile
        exit_code = `$exitCode
    }
    `$status | ConvertTo-Json | Set-Content "$StatusFile" -Encoding UTF8

    # Notify on error
    if (`$exitCode -ne 0 -and (Test-Path "$NotifyScript")) {
        & "$NotifyScript" -Title "Operator Layer Update" -Message "Update check failed (exit code `$exitCode)" -Type Error
    }
} catch {
    `$errorMsg = `$_.Exception.Message
    & "$NotifyScript" -Title "Operator Layer Update" -Message "Error: `$errorMsg" -Type Error
} finally {
    Stop-Transcript | Out-Null
}

"@

    $verifyWrapperPath = Join-Path $env:TEMP "claude_update_verify_wrapper.ps1"
    $wrapperContent | Set-Content $verifyWrapperPath -Encoding UTF8

    # ── Daily Verify Task ──
    Write-Host ""
    Write-Host "-- Daily Verify Task --" -ForegroundColor Cyan
    Write-Status "INFO" "Task: $VerifyTaskName"
    Write-Status "INFO" "Schedule: Every day at $VerifyTime"
    Write-Status "INFO" "Action: Check for updates (verify-only, no changes)"

    $verifyArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$UpdateScript`" -Channel $Channel -VerifyOnly"

    try {
        # Remove existing if present
        if (Get-TaskExists $VerifyTaskName) {
            Unregister-ScheduledTask -TaskName "OperatorLayerVerifyDaily" -TaskPath "\$TaskFolder\" -Confirm:$false -ErrorAction SilentlyContinue
        }

        $verifyAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument $verifyArgs
        $verifyTrigger = New-ScheduledTaskTrigger -Daily -At $VerifyTime
        $verifySettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false
        $verifyPrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

        Register-ScheduledTask -TaskName "OperatorLayerVerifyDaily" -TaskPath "\$TaskFolder\" -Action $verifyAction -Trigger $verifyTrigger -Settings $verifySettings -Principal $verifyPrincipal -Force | Out-Null
        Write-Status "OK" "Daily verify task created"
    } catch {
        Write-Status "FAIL" "Failed to create daily task: $_"
    }

    # ── Weekly Update Task ──
    Write-Host ""
    Write-Host "-- Weekly Update Task --" -ForegroundColor Cyan
    Write-Status "INFO" "Task: $UpdateTaskName"
    Write-Status "INFO" "Schedule: Every $UpdateDay at $UpdateTime"

    if ($AutoApply) {
        $updateArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$UpdateScript`" -Channel $Channel"
        Write-Status "INFO" "Action: Apply available updates (auto-apply enabled)"
    } else {
        $updateArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$UpdateScript`" -Channel $Channel -VerifyOnly"
        Write-Status "INFO" "Action: Check for updates (verify-only, use -AutoApply for auto-update)"
    }

    try {
        # Remove existing if present
        if (Get-TaskExists $UpdateTaskName) {
            Unregister-ScheduledTask -TaskName "OperatorLayerUpdateWeekly" -TaskPath "\$TaskFolder\" -Confirm:$false -ErrorAction SilentlyContinue
        }

        $updateAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument $updateArgs
        $updateTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $UpdateDay -At $UpdateTime
        $updateSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false
        $updatePrincipal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

        Register-ScheduledTask -TaskName "OperatorLayerUpdateWeekly" -TaskPath "\$TaskFolder\" -Action $updateAction -Trigger $updateTrigger -Settings $updateSettings -Principal $updatePrincipal -Force | Out-Null
        Write-Status "OK" "Weekly update task created"
    } catch {
        Write-Status "FAIL" "Failed to create weekly task: $_"
    }

    # Summary
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  SCHEDULE: INSTALLED" -ForegroundColor Green
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""
    Write-Status "INFO" "Verify task:  $VerifyTaskName (daily at $VerifyTime)"
    Write-Status "INFO" "Update task:  $UpdateTaskName ($UpdateDay at $UpdateTime)"
    Write-Host ""
    Write-Status "INFO" "Channel: $Channel"
    Write-Status "INFO" "Auto-apply: $(if ($AutoApply) { 'Enabled' } else { 'Disabled (verify-only)' })"
    Write-Host ""
    Write-Status "INFO" "Logs: $LogDir"
    Write-Status "INFO" "Status: $StatusFile"
    Write-Host ""
    Write-Status "INFO" "To test: schtasks /Run /TN `"$VerifyTaskName`""
    Write-Status "INFO" "To query: powershell ... schedule_updates.ps1 -Query"
    Write-Status "INFO" "To remove: powershell ... schedule_updates.ps1 -Remove"
}

function Query-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  SCHEDULED UPDATE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    $tasks = @($VerifyTaskName, $UpdateTaskName)
    $found = 0

    foreach ($taskName in $tasks) {
        $shortName = $taskName -replace "^$TaskFolder\\", ""
        try {
            $task = Get-ScheduledTask -TaskName $shortName -TaskPath "\$TaskFolder\" -ErrorAction Stop
            $taskInfo = Get-ScheduledTaskInfo -TaskName $shortName -TaskPath "\$TaskFolder\" -ErrorAction SilentlyContinue

            Write-Host "-- $taskName --" -ForegroundColor Cyan
            Write-Status "INFO" "State: $($task.State)"

            if ($taskInfo.LastRunTime -and $taskInfo.LastRunTime -ne [DateTime]::MinValue) {
                $age = ((Get-Date) - $taskInfo.LastRunTime).TotalHours
                Write-Status "INFO" "Last run: $($taskInfo.LastRunTime.ToString('yyyy-MM-dd HH:mm')) ($([math]::Round($age, 1))h ago)"
                Write-Status "INFO" "Last result: $($taskInfo.LastTaskResult)"
            } else {
                Write-Status "INFO" "Last run: Never"
            }

            if ($taskInfo.NextRunTime -and $taskInfo.NextRunTime -ne [DateTime]::MinValue) {
                Write-Status "INFO" "Next run: $($taskInfo.NextRunTime.ToString('yyyy-MM-dd HH:mm'))"
            }

            Write-Host ""
            $found++
        } catch {
            Write-Status "WARN" "${taskName}: Not found"
            Write-Host ""
        }
    }

    if ($found -eq 0) {
        Write-Status "WARN" "No scheduled update tasks found"
        Write-Status "INFO" "Run with -Install to create tasks"
    }

    # Show last update status
    if (Test-Path $StatusFile) {
        try {
            $status = Get-Content $StatusFile -Raw | ConvertFrom-Json
            Write-Host "-- Last Update Check --" -ForegroundColor Cyan
            Write-Status "INFO" "Time: $($status.last_check_at)"
            Write-Status "INFO" "Status: $($status.status)"
            Write-Status "INFO" "Channel: $($status.channel)"
            if ($status.current_version) {
                Write-Status "INFO" "Current: $($status.current_version)"
            }
            if ($status.available_version) {
                Write-Status "INFO" "Available: $($status.available_version)"
            }
            if ($status.log_file) {
                Write-Status "INFO" "Log: $($status.log_file)"
            }
        } catch {
            # Ignore parse errors
        }
    }
}

function Remove-Tasks {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  REMOVING SCHEDULED UPDATE TASKS" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host ""

    $tasks = @("OperatorLayerVerifyDaily", "OperatorLayerUpdateWeekly")
    $removed = 0

    foreach ($taskName in $tasks) {
        try {
            $task = Get-ScheduledTask -TaskName $taskName -TaskPath "\$TaskFolder\" -ErrorAction Stop
            Unregister-ScheduledTask -TaskName $taskName -TaskPath "\$TaskFolder\" -Confirm:$false
            Write-Status "OK" "Removed: $TaskFolder\$taskName"
            $removed++
        } catch {
            Write-Status "INFO" "${TaskFolder}\${taskName}: Not found (skipped)"
        }
    }

    Write-Host ""
    if ($removed -gt 0) {
        Write-Host "SCHEDULE: REMOVED ($removed tasks)" -ForegroundColor Green
    } else {
        Write-Host "SCHEDULE: No tasks to remove" -ForegroundColor Yellow
    }
}

# ============================================================
# MAIN
# ============================================================

if (-not ($Install -or $Query -or $Remove)) {
    Write-Host ""
    Write-Host "Usage:" -ForegroundColor Yellow
    Write-Host "  schedule_updates.ps1 -Install        # Create scheduled tasks"
    Write-Host "  schedule_updates.ps1 -Query          # Show task status"
    Write-Host "  schedule_updates.ps1 -Remove         # Remove scheduled tasks"
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -VerifyTime <HH:MM>     Daily verify time (default: 07:00)"
    Write-Host "  -UpdateDay <Day>        Weekly update day (default: Sunday)"
    Write-Host "  -UpdateTime <HH:MM>     Weekly update time (default: 04:00)"
    Write-Host "  -Channel <channel>      Update channel (default: Release)"
    Write-Host "  -AutoApply              Enable automatic update application"
    Write-Host ""
    exit 0
}

if ($Install) {
    Install-Tasks
} elseif ($Query) {
    Query-Tasks
} elseif ($Remove) {
    Remove-Tasks
}
