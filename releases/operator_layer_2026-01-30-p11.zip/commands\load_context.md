---
name: load_context
description: Load saved session state from JSON for full interactive restore (deep resume).
operator_layer_version: 2026-01-30
---

# /load_context

Resume from a previously saved session with full interactive restore.

## Relationship to /boot Auto-Rehydration

As of 2026-01-30, `/boot` automatically rehydrates from `latest.json` and displays a summary. This is **passive** context loading.

`/load_context` is the **active** deep restore that:
- Auto-runs the saved project loader
- Presents next actions as an interactive checklist
- Prompts "Which action first?"

**When to use each:**
- `/boot` alone: You see what was saved but want to start fresh or change direction
- `/boot` + `/load_context`: You want to fully resume exactly where you left off

## What Gets Loaded

Read from `C:\Users\J\.claude\context\latest.json`:

- **project_loader** → Auto-run that loader (e.g., `/jhornlaw`)
- **initiative_level** → Set for this session
- **current_objective** → Restate to user
- **work_completed** → Summarize what was done
- **next_actions** → Present as checklist
- **open_questions** → Surface for resolution
- **files_modified** → Context for what was touched

## How to Use

At start of new session:
1. Run `/boot`
2. Say "load context" or "/load_context"

Claude will:
1. Read the saved JSON
2. Run the appropriate project loader
3. Summarize previous session
4. Present next actions as a checklist

## Load Specific Session

To load a specific archived session:
```
/load_context session_20260110_1030
```

Reads from: `C:\Users\J\.claude\context\session_20260110_1030.json`

## Output Format

```
===========================================
CONTEXT LOADED
===========================================
from: C:\Users\J\.claude\context\latest.json
saved: [timestamp from file]
age: [X hours/days ago]

PROJECT: [loader]
OBJECTIVE: [current_objective]

COMPLETED LAST SESSION:
- [item 1]
- [item 2]

NEXT ACTIONS:
- [ ] [action 1]
- [ ] [action 2]

OPEN QUESTIONS:
- [question 1]

FILES TOUCHED:
- [file 1]
- [file 2]

Ready to continue. Which action first?
===========================================
```

## Stale Context Warning

If context is older than 7 days, warn:
```
WARNING: Context is [X] days old. May be outdated.
- Continue anyway?
- Start fresh with /boot?
```

## When to Use

- Starting a new thread to continue previous work
- Resuming after break
- Picking up multi-day project
- Onboarding to where you left off

---

## Operator Notes

**Canonical spec:** See `C:\Users\J\.claude\RUNBOOK_REHYDRATION.md`

- `/boot` = passive rehydrate (displays context, no loader run)
- `/load_context` = active deep restore (runs loader, presents checklist)
- Use `/load_context` when you want to resume exactly where you left off
