---
name: ops_smoke
description: Smoke test the operator layer. Validates boot detection, agent headers, and diagnostics footer.
operator_layer_version: 2026-01-10
---

# /ops_smoke

One-command validation of the entire operator layer. Run periodically or after any changes to global commands.

## Test Suite

### Test 1: Boot from neutral directory (must ASK)
```powershell
cd C:\Users\J\Downloads
```
Run `/boot` logic. **Expected:** No auto-detect match → asks which project.

### Test 2: Boot from AI_CORE (must route to /jhornlaw)
```powershell
cd C:\AI_CORE\v4
```
Run `/boot` logic. **Expected:** Auto-detects → `/jhornlaw`.

### Test 3: Boot from the_brain (must route to /jhornlaw)
```powershell
cd C:\Users\J\the_brain
```
Run `/boot` logic. **Expected:** Auto-detects → `/jhornlaw`.

### Test 4: False-positive protection
```powershell
cd C:\Users\J\Downloads
mkdir test_not_the_brain 2>$null
cd test_not_the_brain
```
Run `/boot` logic. **Expected:** No match → asks.
```powershell
cd ..
rmdir test_not_the_brain
```

### Test 5: Agent header format check
Verify each agent file contains output format requiring:
- `finding_count: N (critical X / high Y / medium Z / low W)`
- `[CRITICAL]`, `[HIGH]`, `[MEDIUM]`, `[LOW]` prefixes

### Test 6: Diagnostics footer present
Verify `/execute_full_plan` contains Step 4 with:
- `REVIEW DIAGNOSTICS` header
- `timestamp`, `project_loader`, `target`, `agents_invoked`
- `total_findings`, severity counts

## Output Format

```
===========================================
OPS SMOKE TEST
===========================================
operator_layer_version: 2026-01-10
timestamp: [current date/time]

Test 1 (neutral boot):    [PASS|FAIL]
Test 2 (AI_CORE boot):    [PASS|FAIL]
Test 3 (the_brain boot):  [PASS|FAIL]
Test 4 (false-positive):  [PASS|FAIL]
Test 5 (agent headers):   [PASS|FAIL]
Test 6 (diagnostics):     [PASS|FAIL]

Result: [ALL PASS | X failures]
===========================================
```

## When to Run

- After modifying any global command
- After updating agents
- Monthly governance check
- Before onboarding to new project

## On Failure

If any test fails:
1. Check `operator_layer_version` matches across files
2. Verify regex patterns in `/boot` Step 2
3. Confirm agent files have required output format
4. Re-run individual failing test with verbose output
