---
name: distress
description: Distressed property pipeline context. Loads doctrine for all counties + guides new county setup.
---

# Distress Properties System

You are working on the **Distressed Real Estate Pipeline** - a system for identifying and targeting distressed properties in Texas counties.

## Step 0: Establish Current Date/Time

**CRITICAL**: Before any work, establish and confirm the current date/time:

```
Run: powershell -Command "Get-Date -Format 'dddd, MMMM dd, yyyy HH:mm:ss'"
```

Store this as `SESSION_DATE` and reference it for:
- All date-based searches (90-day lookbacks, etc.)
- Calculating "days until auction"
- Determining next First Tuesday (tax sale day)
- Knowing which day's operational cadence applies (Mon/Wed/Fri)

**Always state the current date in your status report.**

## Step 1: Load System Context

Read the master doctrine and state:
- `C:\Users\J\distress_properties\DOCTRINE.md` - Core methodology, scoring, distress hierarchy, and new county onboarding guide
- `C:\Users\J\distress_properties\STATE.md` - Current status across all counties

## Step 2: Identify Active Counties

| County | Path | DB |
|--------|------|----|
| **Harris** | `C:\Users\J\distress_properties\harris_county` | `harris_distress.db` |
| **Montgomery** | `C:\Users\J\distress_properties\montgomery_county` | `moco_distress.db` |
| **Fort Bend** | `C:\Users\J\distress_properties\fort_bend_county` | CSV-based |
| **Galveston** | `C:\Users\J\distress_properties\galveston_county` | CSV-based |

Each county has its own:
- `STATE.md` - Current data/pipeline status
- `DOCTRINE.md` - County-specific sources and rules

## Step 3: Determine User Intent

Ask if needed:
1. **Which county?** (Harris, Montgomery, Fort Bend, or NEW)
2. **What task?**
   - Run pipeline / refresh data
   - Review exceptions / unmatched
   - Generate mail merge
   - Debug scraper
   - Onboard new county
   - Add new signal source

## For Existing Counties

Load the county-specific state and doctrine:
```
C:\Users\J\distress_properties\{county}\STATE.md
C:\Users\J\distress_properties\{county}\DOCTRINE.md
```

Then proceed with the requested task.

## For New County Onboarding

Follow the phases in master `DOCTRINE.md`:

### Phase 1: Discovery
1. Identify CAD name and data portal
2. Find County Clerk foreclosure system
3. Find Tax Office / attorney sites
4. Locate struck-off inventory pages
5. Draft TPIA request

### Phase 2: Setup
1. Create `{county}/` folder inside `distress_properties/`
2. Create `STATE.md` and `DOCTRINE.md`
3. Configure field maps
4. Write/adapt scrapers

### Phase 3: Initial Load
1. Download parcel master
2. Scrape current signals
3. Run full pipeline
4. Review exceptions

## Distress Hierarchy (Motivation Levels)

### Tier 1: Imminent Loss (HIGHEST)
- FC_SALE_SOON (+90) - Auction in days
- TAX_SALE_SET (+70) - On tax sale list

### Tier 2: Process Started
- FC_LISTED (+60) - Foreclosure posted
- NOD_FILED (+45) - Pre-foreclosure notice
- TAX_SUIT (+40) - Tax suit filed

### Tier 3: Chronic Distress
- TAX_MULTIYEAR (+50) - 2+ years behind
- PROBATE (+35) - Deceased owner
- LIS_PENDENS (+30) - Litigation pending
- STRUCK_OFF (+25) - County-owned

### Tier 4: Early Warning
- TAX_1YR (+30) - 1 year behind
- DIVORCE (+25) - Family court case
- CODE_VIOLATION (+20) - Fines accruing

### Tier 5: Amplifiers
- ABSENTEE (+15) - Out-of-state owner
- VACANT_LIKELY (+15) - Property empty
- LOW_IMPROV (+10) - Teardown/land play

## Operational Cadence
- **Monday:** Full refresh + scoring
- **Wednesday:** Delta + exceptions
- **Friday:** Mail freeze + watchlist
- **First Tuesday:** Tax sale day

## Report Ready

After loading context, confirm:
```
═══════════════════════════════════════════════════
DISTRESS PIPELINE ACTIVE
Session Date: [CURRENT DATE - e.g., Monday, December 29, 2025]
Next Tax Sale (First Tuesday): [calculated date]
═══════════════════════════════════════════════════
Counties:
  - Harris: [status]
  - Montgomery: [status]
  - Fort Bend: [status]
  - Galveston: [status]

Today's Cadence: [Monday=Full Refresh | Wednesday=Delta | Friday=Mail Freeze]
Focus: [user's stated goal or ask]
Ready.
```
