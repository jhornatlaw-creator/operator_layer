---
name: tangent
description: Force Task-Switch Protocol. Declares switch, asks routing, generates handoff packet if needed.
---

# Tangent Command

Apply the Global Task-Switch Protocol now.

## Input
The user's tangent objective (one sentence), provided after `/tangent:` or in the follow-up.

## Required Output

### Step 1: Determine Tier
- **Tier 1** (Task-switch): New objective, same project/workspace.
- **Tier 2** (Workstream-switch): New objective AND different project loader or repo root.

### Step 2: Declare the Switch
```
TASK SWITCH (Tier 1): <Current Objective> → <New Objective>
```
or
```
WORKSTREAM SWITCH (Tier 2): <Workstream A> → <Workstream B>
```

### Step 3: For Tier 2 Only - Produce Workstream Cards
```
Workstream Card (PARKED)
- Name:
- Objective (one sentence):
- Scope (paths/modules):
- Next action (single step):
- Done condition (one sentence):

Workstream Card (NEW)
- Name:
- Objective (one sentence):
- Scope (paths/modules):
- Next action (single step):
- Done condition (one sentence):
```

### Step 4: Ask Routing (required)
```
Stay in this thread for <New Objective>, or open a new tab?
```

### Step 5: If User Chooses "New Tab"
Produce Context Handoff Packet:
```
Context Handoff Packet
- Project loader:
- Execution mode: review_only (default unless elevated)
- Objective (one sentence):
- Scope (paths/modules):
- Current state (2-4 bullets):
- Decisions made (bullets):
- Done condition:
- Next 3 actions:
```

Then offer: "Want me to /save_context for the parked objective?"

## Rules
- Do NOT proceed with the new objective until routing is explicit.
- "Go" without routing answer = re-ask routing.
- New objectives default to `review_only` unless user elevates.
- Credentials are sacred: never request/open secrets.
