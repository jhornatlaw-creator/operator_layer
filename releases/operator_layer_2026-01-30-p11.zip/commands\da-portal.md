---
name: da-portal
description: Access Harris County DA Defense Portal for discovery, case files, and defendant information on your active cases.
---

# Harris DA Defense Portal

Access your active criminal cases through the Harris County DA Defense Portal.

## What This Does

This command opens the DA Defense Portal to access:
- Discovery files (videos, documents, photos)
- Offense report narratives (Summary of Facts)
- Plea offer history
- Defendant information (mugshots, criminal history)
- Jail call records
- Witness information

## Portal Script Location

```
C:\Users\J\the_brain\counties\harris\da_portal\harris_da_portal.py
```

## Usage

When the user invokes `/da-portal`, run the script with appropriate arguments:

### List all active cases
```powershell
cd C:\Users\J\the_brain\counties\harris\da_portal
python harris_da_portal.py
```

### Open specific case by defendant name
After listing cases, user can ask to open by name - the script supports `find_case_by_name()`.

### Open by SPN
The script supports `open_case(spn_number)` to open by SPN directly.

## Portal Structure Reference

### eDocs Case Landing Page Tabs
| Tab | Purpose |
|-----|---------|
| Summary | Case overview, bond, next setting |
| Images | Filed documents, offense reports |
| Bonds | Bond details and history |
| Activities | Case activities log |
| Criminal History | Prior criminal history |
| Witness | Witness information |
| Parties | Attorneys, prosecutors |
| Settings | Court settings history |

### DA Defense Portal Tabs
| Tab | Purpose |
|-----|---------|
| CCH | Criminal Case History - full rap sheet |
| Sum. Facts | **Offense report narrative** - key for case review |
| Case Jacket | **Plea offers, offer history** - critical |
| Files | **Discovery files** - videos, documents |
| Jail Calls | Jail phone call records |
| DWI PTI | DWI Pre-Trial Intervention info |

### Key Actions in Portal
| Button | Purpose |
|--------|---------|
| View Report | Full defendant report PDF |
| Download Files | Bulk download all discovery |
| M. Health | Mental health records |

## Current Active Cases (19 total)

Run the script to get current list. Cases include:
- OSAGIE, OSAMWONYI (SPN: 03319023) - DWI
- MEDINA SABILLON, HECTOR (SPN: 03318164)
- ALMANZA, ANTHONY SAMUEL (SPN: 03205406)
- JOHNSON, BRYSON JAVON (SPN: 02617554)
- MARTINEZ, FRANCISCO (SPN: 03313446)
- ELLIS, CHRISSIE SHANTAY (SPN: 03310813)
- DOBBS, MEGAN LANAE (SPN: 03176530)
- And more...

## Environment Variables Required

- `EDOCS_USERNAME` - eDocs login email (default: jhorn@jhornlaw.com)
- `EDOCS_PASSWORD` - eDocs password (required)

Set in `C:\Users\J\the_brain\.env`

## Example Workflow

1. User: "/da-portal"
2. Run script, list all 19 active cases
3. User: "open JONES case"
4. Find JONES, open case, navigate to DA Portal
5. User: "what's the offense report say?"
6. Click Sum. Facts tab, extract narrative
7. User: "any plea offers?"
8. Click Case Jacket tab, extract offer history

## Data Available Per Case

**Defendant Info**: Name, DOB, Race, Sex, SPN, Height/Weight, Address, Mugshot

**Case Info**: Cause Number, Court, Charge, Bond, Next Setting, ADA assigned

**Discovery**: Offense reports, witness statements, body cam, photos, lab reports

## Notes

- Browser opens non-headless by default for visual verification
- Script handles popup windows automatically
- Login credentials are same for eDocs and DA Portal
- Portal URL: `https://web.dao.hctx.net/defense/`
