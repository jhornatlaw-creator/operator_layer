---
name: kalshi
description: Load Kalshi prediction market trading bot context
---

# /kalshi - Prediction Market Trading Bot

Load the Kalshi trading bot workspace for development, testing, and operations.

## Workspace

| Item | Value |
|------|-------|
| Path | `C:\Users\J\kalshi` |
| GitHub | https://github.com/jhornatlaw-creator/kalshi-bot |
| Supabase | `ngpyrlupvyoapprotqdnk` (us-east-1) |
| Tests | 630+ passing |

## Boot Sequence

1. Read `C:\Users\J\kalshi\STATE.md`
2. Read `C:\Users\J\kalshi\.claude\CLAUDE.md`
3. Check git status: `git -C "C:\Users\J\kalshi" status --short`
4. Check test count: `cd C:\Users\J\kalshi && python -m pytest --collect-only -q 2>nul | findstr "test"`

## Critical Safety Rules

### NEVER
- Commit secrets, API keys, or credentials
- Enable live trading without explicit `--live --i-understand-live-trading` flags
- Bypass kill switch checks
- Log sensitive data (tokens, passwords, API responses with PII)

### ALWAYS
- Run `make test` before committing
- Update STATE.md after significant changes
- Use integer cents (1-99) for all prices
- Check kill switch before any order placement

## Price Convention

**ALL prices are INTEGER CENTS (1-99).** Never use floats for prices.
- BUY YES at 45 = pay 45 cents, win $1 if YES
- Implied ask = 100 - opposite_bid

## CLI Quick Reference

```powershell
# Paper trading
kalshi run-paper <ticker> --fair-value 0.55
kalshi run-paper-multi TICKER1:0.55,TICKER2:0.60

# Smoke test
kalshi smoke-paper <ticker> --fair-value 0.55 --ws

# Shadow burn-in (mock)
kalshi shadow-burnin <ticker> --fair-value 0.55 --duration 600 --mock

# Shadow burn-in (real)
kalshi shadow-burnin <ticker> --fair-value 0.55 --duration 7200

# Live trading (DANGER - requires both flags)
kalshi run-live <ticker> --fair-value 0.55 --live --i-understand-live-trading

# Kill switch
kalshi kill-switch on --persist
kalshi kill-switch off --persist

# Status
kalshi health
kalshi status
```

## Milestone Status

### M1 - Offline Reliability (Mock) - COMPLETE
- [x] Baseline (10 min) - PASS
- [x] Burst (10 min) - PASS
- [x] STOP-2 tripwire - PASS (correctly triggered)
- [x] STOP-6 tripwire - PASS (correctly triggered)
- [x] Injected12 (2h) - PASS
- [x] Combined (2h) - PASS

### M2 - Real Network Shadow (Requires Signup) - PENDING
- [ ] 5-min auth check
- [ ] 2h real shadow burn-in
- [ ] 24h shadow run

### M3 - Two-Key Turn Drill - PENDING
- [ ] Verify all safety gates
- [ ] Test kill switch mid-run

## Directory Structure

```
src/kalshi/
  api/          # REST + WebSocket clients
  db/           # Supabase persistence
  live/         # Live trading broker
  mock/         # K-20 mock harness
  ops/          # Alerts, rate limiting, state
  paper/        # Paper trading broker
  risk/         # Risk manager
  runner/       # Paper, live, backtest, smoke, burnin
  strategies/   # directional_v1, directional_v2
tests/
  fixtures/     # REST + WS payload fixtures
```

## Workflow

| Role | Owner |
|------|-------|
| Planning | Claude |
| Architecture | GPT |
| Building | Claude |
| Review | GPT + Claude |

## Config

- `.env` - Local environment (gitignored)
- `.env.example` - Template with placeholders
- `src/kalshi/config.py` - Pydantic Settings

Required for M2+:
```
KALSHI_EMAIL=
KALSHI_PASSWORD=
```
