<#
.SYNOPSIS
    Update the Claude Code operator layer.

.DESCRIPTION
    Pulls newer version from source or release channel, verifies hashes, updates VERSION.
    Never touches context\ (user session state is preserved).

.PARAMETER Source
    Source of operator layer updates. Uses manifest source if not specified.

.PARAMETER Channel
    Update channel: 'Local' (default) or 'Release'.
    - Local: Update from git/path source
    - Release: Update from release zip via -ReleaseUrl or -ReleaseIndexUrl

.PARAMETER ReleaseUrl
    Direct URL or path to release zip (for -Channel Release).

.PARAMETER ReleaseIndexUrl
    URL to index.json containing release metadata (for -Channel Release).

.PARAMETER ExpectedHash
    Expected SHA256 hash of release zip.

.PARAMETER Force
    Update even if versions match.

.PARAMETER VerifyOnly
    Check for updates without applying them.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File update.ps1
    # Update from manifest source (Local channel)

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File update.ps1 -VerifyOnly
    # Check if update is available

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -ReleaseUrl C:\releases\operator_layer_p10.zip
    # Update from release zip

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File update.ps1 -Channel Release -VerifyOnly
    # Check for release updates without applying

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File update.ps1 -Source C:\new_source -Force
    # Force update from specific source

.NOTES
    operator_layer_version: 2026-01-30-p10

    SAFETY:
    - context\ is NEVER touched
    - Manifest verification after update
    - Backup created before applying release updates
    - Rollback documented in RUNBOOK_REHYDRATION.md
#>

param(
    [string]$Source,

    [ValidateSet('Local', 'Release')]
    [string]$Channel = 'Local',

    [string]$ReleaseUrl,
    [string]$ReleaseIndexUrl,
    [string]$ExpectedHash,

    [switch]$Force,
    [switch]$VerifyOnly
)

$Target = "C:\Users\J\.claude"
$ManifestPath = Join-Path $Target "operator_layer_manifest.json"
$VersionPath = Join-Path $Target "VERSION"
$InstallScript = Join-Path $Target "install.ps1"
$DownloadScript = Join-Path $Target "lib\download_release.ps1"
$StatusFile = Join-Path $Target "lib\update_status.json"
$BackupDir = Join-Path $Target "backups"

function Write-Header($text) {
    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor White
    Write-Host "  $text" -ForegroundColor White
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor White
}

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]   $msg" -ForegroundColor Green }
        "SKIP" { Write-Host "[SKIP] $msg" -ForegroundColor Yellow }
        "FAIL" { Write-Host "[FAIL] $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO] $msg" -ForegroundColor Gray }
        "NEW"  { Write-Host "[NEW]  $msg" -ForegroundColor Cyan }
    }
}

function Test-IsGitUrl($str) {
    return $str -match "^(https?://|git@|git://)" -or $str -match "\.git$"
}

function Compare-Versions($v1, $v2) {
    # Simple string comparison for now (YYYY-MM-DD-pN format)
    # Returns: -1 if v1 < v2, 0 if equal, 1 if v1 > v2
    if ($v1 -eq $v2) { return 0 }
    if ($v1 -lt $v2) { return -1 }
    return 1
}

function Write-UpdateStatus {
    param(
        [string]$Status,
        [string]$CurrentVersion,
        [string]$AvailableVersion,
        [string]$Action
    )

    $statusObj = @{
        last_check_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        status = $Status
        channel = $Channel
        current_version = $CurrentVersion
        available_version = $AvailableVersion
        last_action = $Action
    }

    try {
        $statusDir = Split-Path -Parent $StatusFile
        if (-not (Test-Path $statusDir)) {
            New-Item -ItemType Directory -Path $statusDir -Force | Out-Null
        }
        $statusObj | ConvertTo-Json -Depth 5 | Set-Content $StatusFile -Encoding UTF8
    } catch {
        # Ignore write errors
    }
}

# ============================================================
# MAIN
# ============================================================

Write-Header "OPERATOR LAYER UPDATE"
Write-Host "  Channel: $Channel" -ForegroundColor Gray

# Get current version
$currentVersion = "unknown"
if (Test-Path $VersionPath) {
    $currentVersion = (Get-Content $VersionPath -Raw).Trim()
}
Write-Host "  Current version: $currentVersion" -ForegroundColor Gray

# ══════════════════════════════════════════════════════════════
# RELEASE CHANNEL HANDLING
# ══════════════════════════════════════════════════════════════
if ($Channel -eq 'Release') {
    Write-Host ""

    # Need either -ReleaseUrl or -ReleaseIndexUrl
    if (-not $ReleaseUrl -and -not $ReleaseIndexUrl) {
        # Try to find a release in the releases\ folder
        $releasesDir = Join-Path $Target "releases"
        if (Test-Path $releasesDir) {
            $latestRelease = Get-ChildItem "$releasesDir\operator_layer_*.zip" -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                Select-Object -First 1

            if ($latestRelease) {
                $ReleaseUrl = $latestRelease.FullName
                Write-Host "  Source: $ReleaseUrl (auto-detected)" -ForegroundColor Gray
            }
        }

        if (-not $ReleaseUrl) {
            Write-Host "ERROR: -Channel Release requires -ReleaseUrl or -ReleaseIndexUrl" -ForegroundColor Red
            Write-Host ""
            Write-Host "Examples:" -ForegroundColor Yellow
            Write-Host "  update.ps1 -Channel Release -ReleaseUrl C:\releases\operator_layer_p10.zip" -ForegroundColor Gray
            Write-Host "  update.ps1 -Channel Release -ReleaseIndexUrl https://example.com/index.json" -ForegroundColor Gray
            Write-UpdateStatus -Status "ERROR" -CurrentVersion $currentVersion -Action "missing_release_url"
            exit 1
        }
    } else {
        Write-Host "  Source: $(if ($ReleaseUrl) { $ReleaseUrl } else { $ReleaseIndexUrl }) (release)" -ForegroundColor Gray
    }

    # Handle -ReleaseIndexUrl: fetch index and get latest release URL
    if ($ReleaseIndexUrl -and -not $ReleaseUrl) {
        Write-Host ""
        Write-Host "── Fetching release index ──" -ForegroundColor Cyan

        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            if ($ReleaseIndexUrl -match "^https?://") {
                $indexContent = (Invoke-WebRequest -Uri $ReleaseIndexUrl -UseBasicParsing).Content
            } else {
                $indexContent = Get-Content $ReleaseIndexUrl -Raw
            }

            $index = $indexContent | ConvertFrom-Json
            $latestVersion = $index.latest_version
            $latestRelease = $index.releases | Where-Object { $_.version -eq $latestVersion } | Select-Object -First 1

            if (-not $latestRelease) {
                $latestRelease = $index.releases | Select-Object -First 1
            }

            if ($latestRelease) {
                $ReleaseUrl = $latestRelease.download_url
                $ExpectedHash = $latestRelease.sha256
                Write-Status "OK" "Found release: $($latestRelease.version)"
                Write-Status "INFO" "Download URL: $ReleaseUrl"
            } else {
                Write-Status "FAIL" "No releases found in index"
                Write-UpdateStatus -Status "ERROR" -CurrentVersion $currentVersion -Action "no_releases_in_index"
                exit 1
            }
        } catch {
            Write-Status "FAIL" "Failed to fetch release index: $_"
            Write-UpdateStatus -Status "ERROR" -CurrentVersion $currentVersion -Action "index_fetch_failed"
            exit 1
        }
    }

    # Download release to check version
    if (-not (Test-Path $DownloadScript)) {
        Write-Host "ERROR: download_release.ps1 not found" -ForegroundColor Red
        exit 1
    }

    Write-Host ""
    Write-Host "── Checking release version ──" -ForegroundColor Cyan

    $downloadParams = @{ Url = $ReleaseUrl }
    if ($ExpectedHash) { $downloadParams.ExpectedHash = $ExpectedHash }

    $downloadResult = & $DownloadScript @downloadParams

    if (-not $downloadResult.Success) {
        Write-Status "FAIL" "Release verification failed: $($downloadResult.Error)"
        Write-UpdateStatus -Status "ERROR" -CurrentVersion $currentVersion -Action "release_verification_failed"
        exit 1
    }

    $releaseExtractPath = $downloadResult.ExtractPath
    $releaseVersionPath = Join-Path $releaseExtractPath "VERSION"

    if (-not (Test-Path $releaseVersionPath)) {
        Write-Status "FAIL" "No VERSION file in release"
        Remove-Item -Recurse -Force $releaseExtractPath -ErrorAction SilentlyContinue
        exit 1
    }

    $sourceVersion = (Get-Content $releaseVersionPath -Raw).Trim()
    Write-Status "INFO" "Release version: $sourceVersion"
    Write-Status "INFO" "Current version: $currentVersion"

    $comparison = Compare-Versions $sourceVersion $currentVersion

    if ($comparison -eq 0 -and -not $Force) {
        Write-Host ""
        Write-Status "OK" "Already at latest version: $currentVersion"
        Remove-Item -Recurse -Force $releaseExtractPath -ErrorAction SilentlyContinue
        Write-UpdateStatus -Status "CURRENT" -CurrentVersion $currentVersion -AvailableVersion $sourceVersion -Action "already_latest"

        Write-Header "UPDATE: CURRENT"
        Write-Host "  Status: Already at latest" -ForegroundColor Green
        Write-Host "  Version: $currentVersion" -ForegroundColor Gray
        Write-Host "  Channel: Release" -ForegroundColor Gray
        exit 0
    }

    if ($comparison -lt 0 -and -not $Force) {
        Write-Status "WARN" "Release version ($sourceVersion) is older than current ($currentVersion)"
        Write-Status "INFO" "Use -Force to downgrade"
        Remove-Item -Recurse -Force $releaseExtractPath -ErrorAction SilentlyContinue
        Write-UpdateStatus -Status "CURRENT" -CurrentVersion $currentVersion -AvailableVersion $sourceVersion -Action "release_older"
        exit 0
    }

    Write-Status "NEW" "Update available: $currentVersion -> $sourceVersion"

    if ($VerifyOnly) {
        Write-Host ""
        Write-Header "UPDATE: AVAILABLE"
        Write-Host "  Current: $currentVersion" -ForegroundColor Gray
        Write-Host "  Available: $sourceVersion" -ForegroundColor Green
        Write-Host "  Channel: Release" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Run without -VerifyOnly to apply update." -ForegroundColor Yellow
        Remove-Item -Recurse -Force $releaseExtractPath -ErrorAction SilentlyContinue
        Write-UpdateStatus -Status "AVAILABLE" -CurrentVersion $currentVersion -AvailableVersion $sourceVersion -Action "verify_only"
        exit 0
    }

    # Apply update via install.ps1 using extracted release as source
    Write-Host ""
    Write-Host "── Applying release update ──" -ForegroundColor Cyan

    # Create backup
    $backupPath = Join-Path $BackupDir "pre_update_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    if (-not (Test-Path $BackupDir)) {
        New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    }
    Write-Status "INFO" "Creating backup: $backupPath"

    # Backup current managed files (not context\)
    New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
    $managedPatterns = @("commands", "lib", "VERSION", "*.md", "*.ps1", "operator_layer_manifest.json")
    foreach ($pattern in $managedPatterns) {
        $items = Get-ChildItem (Join-Path $Target $pattern) -ErrorAction SilentlyContinue
        foreach ($item in $items) {
            $relativePath = $item.FullName.Substring($Target.Length + 1)
            $backupItemPath = Join-Path $backupPath $relativePath
            $backupItemDir = Split-Path -Parent $backupItemPath

            if (-not (Test-Path $backupItemDir)) {
                New-Item -ItemType Directory -Path $backupItemDir -Force | Out-Null
            }

            if ($item.PSIsContainer) {
                Copy-Item -Path $item.FullName -Destination $backupItemPath -Recurse -Force
            } else {
                Copy-Item -Path $item.FullName -Destination $backupItemPath -Force
            }
        }
    }
    Write-Status "OK" "Backup created"

    # Apply update
    & powershell -ExecutionPolicy Bypass -File $InstallScript -Source $releaseExtractPath -Force
    $installResult = $LASTEXITCODE

    # Cleanup release extract
    Remove-Item -Recurse -Force $releaseExtractPath -ErrorAction SilentlyContinue

    # Verify result
    $newVersion = "unknown"
    if (Test-Path $VersionPath) {
        $newVersion = (Get-Content $VersionPath -Raw).Trim()
    }

    $verifyScript = Join-Path $Target "lib\verify_manifest.ps1"
    $verifyStatus = "unverified"
    if (Test-Path $verifyScript) {
        & powershell -ExecutionPolicy Bypass -File $verifyScript -Quiet
        if ($LASTEXITCODE -eq 0) {
            $verifyStatus = "verified"
        } else {
            $verifyStatus = "FAILED"
        }
    }

    Write-Header "UPDATE COMPLETE"

    if ($installResult -eq 0 -and $verifyStatus -eq "verified") {
        Write-Host "  Status: OK" -ForegroundColor Green
        Write-UpdateStatus -Status "OK" -CurrentVersion $newVersion -AvailableVersion $sourceVersion -Action "updated"
    } else {
        Write-Host "  Status: PARTIAL (check errors above)" -ForegroundColor Yellow
        Write-UpdateStatus -Status "PARTIAL" -CurrentVersion $newVersion -AvailableVersion $sourceVersion -Action "update_partial"
    }

    Write-Host "  Previous version: $currentVersion" -ForegroundColor Gray
    Write-Host "  New version: $newVersion" -ForegroundColor Green
    Write-Host "  Channel: Release" -ForegroundColor Gray
    Write-Host "  Manifest: $verifyStatus" -ForegroundColor $(if ($verifyStatus -eq "verified") { "Green" } else { "Red" })
    Write-Host ""
    Write-Host "  Context preserved: $Target\context\ (not touched)" -ForegroundColor Yellow
    Write-Host "  Backup: $backupPath" -ForegroundColor Gray
    Write-Host ""

    exit $(if ($verifyStatus -eq "verified") { 0 } else { 1 })
}

# ══════════════════════════════════════════════════════════════
# LOCAL CHANNEL HANDLING (original behavior)
# ══════════════════════════════════════════════════════════════

# Determine source
if (-not $Source) {
    if (Test-Path $ManifestPath) {
        $manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
        $Source = $manifest.source
        Write-Host "  Source: $Source (from manifest)" -ForegroundColor Gray
    } else {
        Write-Host ""
        Write-Host "ERROR: No source specified and no manifest found." -ForegroundColor Red
        Write-Host "Run install.ps1 first, or specify -Source parameter." -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "  Source: $Source (specified)" -ForegroundColor Gray
}

Write-Host ""

# ── Step 1: Fetch source to temp ──
Write-Host "── Fetching source ──" -ForegroundColor Cyan

$tempDir = $null
$actualSource = $Source

if (Test-IsGitUrl $Source) {
    $gitPath = Get-Command git -ErrorAction SilentlyContinue
    if (-not $gitPath) {
        Write-Status "FAIL" "git not found"
        exit 1
    }

    $tempDir = Join-Path $env:TEMP "operator_layer_update_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    Write-Status "INFO" "Cloning to temp..."

    try {
        git clone --depth 1 $Source $tempDir 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "git clone failed" }
        Write-Status "OK" "Fetched from git"
    } catch {
        Write-Status "FAIL" "Git clone failed: $_"
        exit 1
    }

    if (Test-Path (Join-Path $tempDir ".claude")) {
        $actualSource = Join-Path $tempDir ".claude"
    } else {
        $actualSource = $tempDir
    }
} else {
    $actualSource = (Resolve-Path $Source -ErrorAction SilentlyContinue).Path
    if (-not $actualSource -or -not (Test-Path $actualSource)) {
        Write-Status "FAIL" "Source path not found: $Source"
        exit 1
    }
    Write-Status "OK" "Using local source"
}

# ── Step 2: Check source version ──
Write-Host ""
Write-Host "── Checking versions ──" -ForegroundColor Cyan

$sourceVersionPath = Join-Path $actualSource "VERSION"
if (-not (Test-Path $sourceVersionPath)) {
    Write-Status "FAIL" "No VERSION file in source"
    if ($tempDir) { Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue }
    exit 1
}

$sourceVersion = (Get-Content $sourceVersionPath -Raw).Trim()
Write-Status "INFO" "Source version: $sourceVersion"
Write-Status "INFO" "Current version: $currentVersion"

$comparison = Compare-Versions $sourceVersion $currentVersion

if ($comparison -eq 0 -and -not $Force) {
    Write-Host ""
    Write-Host "── No update needed ──" -ForegroundColor Cyan
    Write-Status "OK" "Already at latest version: $currentVersion"

    # Still verify current installation
    Write-Host ""
    Write-Host "── Verifying current installation ──" -ForegroundColor Cyan
    $verifyScript = Join-Path $Target "lib\verify_manifest.ps1"
    if (Test-Path $verifyScript) {
        & powershell -ExecutionPolicy Bypass -File $verifyScript -Quiet
        if ($LASTEXITCODE -eq 0) {
            Write-Status "OK" "Manifest verified"
        } else {
            Write-Status "FAIL" "Manifest verification failed - consider reinstalling"
        }
    }

    if ($tempDir) { Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue }

    Write-Header "UPDATE: NOOP"
    Write-Host "  Status: Already latest" -ForegroundColor Green
    Write-Host "  Version: $currentVersion" -ForegroundColor Gray
    exit 0
}

if ($comparison -lt 0 -and -not $Force) {
    Write-Status "WARN" "Source version ($sourceVersion) is older than current ($currentVersion)"
    Write-Status "INFO" "Use -Force to downgrade"
    if ($tempDir) { Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue }
    exit 0
}

Write-Status "NEW" "Update available: $currentVersion -> $sourceVersion"

if ($VerifyOnly) {
    Write-Host ""
    Write-Header "UPDATE AVAILABLE"
    Write-Host "  Current: $currentVersion" -ForegroundColor Gray
    Write-Host "  Available: $sourceVersion" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Run without -VerifyOnly to apply update." -ForegroundColor Yellow
    if ($tempDir) { Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue }
    exit 0
}

# ── Step 3: Apply update via install.ps1 ──
Write-Host ""
Write-Host "── Applying update ──" -ForegroundColor Cyan

# Use install.ps1 with Force
if (Test-Path $InstallScript) {
    & powershell -ExecutionPolicy Bypass -File $InstallScript -Source $actualSource -Force
    $installResult = $LASTEXITCODE
} else {
    Write-Status "FAIL" "install.ps1 not found"
    if ($tempDir) { Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue }
    exit 1
}

# ── Step 4: Cleanup ──
if ($tempDir -and (Test-Path $tempDir)) {
    Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}

# ── Step 5: Final verification ──
Write-Host ""
Write-Host "── Final verification ──" -ForegroundColor Cyan

$newVersion = "unknown"
if (Test-Path $VersionPath) {
    $newVersion = (Get-Content $VersionPath -Raw).Trim()
}

$verifyScript = Join-Path $Target "lib\verify_manifest.ps1"
$verifyStatus = "unverified"
if (Test-Path $verifyScript) {
    & powershell -ExecutionPolicy Bypass -File $verifyScript -Quiet
    if ($LASTEXITCODE -eq 0) {
        $verifyStatus = "verified"
        Write-Status "OK" "Manifest verified"
    } else {
        $verifyStatus = "FAILED"
        Write-Status "FAIL" "Manifest verification failed"
    }
}

# ── Summary ──
Write-Header "UPDATE COMPLETE"

if ($installResult -eq 0 -and $verifyStatus -eq "verified") {
    Write-Host "  Status: OK" -ForegroundColor Green
} else {
    Write-Host "  Status: PARTIAL (check errors above)" -ForegroundColor Yellow
}

Write-Host "  Previous version: $currentVersion" -ForegroundColor Gray
Write-Host "  New version: $newVersion" -ForegroundColor Green
Write-Host "  Manifest: $verifyStatus" -ForegroundColor $(if ($verifyStatus -eq "verified") { "Green" } else { "Red" })
Write-Host ""
Write-Host "  Context preserved: $Target\context\ (not touched)" -ForegroundColor Yellow
Write-Host ""

exit $(if ($verifyStatus -eq "verified") { 0 } else { 1 })
