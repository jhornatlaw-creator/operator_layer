<#
.SYNOPSIS
    Verify operator layer files against manifest.

.DESCRIPTION
    Computes SHA256 hashes of managed files and compares against operator_layer_manifest.json.
    Used by install.ps1, update.ps1, and optionally by /boot for integrity checking.

.PARAMETER ManifestPath
    Path to manifest file. Default: C:\Users\J\.claude\operator_layer_manifest.json

.PARAMETER BasePath
    Base directory for file resolution. Default: C:\Users\J\.claude
    Use this to verify extracted release contents against their embedded manifest.

.PARAMETER Quick
    Skip hash verification, only check file existence. Faster for /boot.

.PARAMETER Quiet
    Suppress detailed output, only return exit code.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File verify_manifest.ps1
    # Full verification with detailed output

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File verify_manifest.ps1 -Quick
    # Quick existence check only

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File verify_manifest.ps1 -ManifestPath C:\temp\release\manifest.json -BasePath C:\temp\release
    # Verify extracted release against its manifest

.NOTES
    operator_layer_version: 2026-01-30-p10

    Exit codes:
    0 = VERIFIED (all files match)
    1 = FAILED (hash mismatch or missing files)
    2 = NO_MANIFEST (manifest file not found)
#>

param(
    [string]$ManifestPath = "C:\Users\J\.claude\operator_layer_manifest.json",
    [string]$BasePath,
    [switch]$Quick,
    [switch]$Quiet
)

# Use provided BasePath or derive from ManifestPath or use default
if ($BasePath) {
    $BaseDir = $BasePath
} elseif ($ManifestPath -ne "C:\Users\J\.claude\operator_layer_manifest.json") {
    # If custom manifest path, use its directory as base
    $BaseDir = Split-Path -Parent $ManifestPath
} else {
    $BaseDir = "C:\Users\J\.claude"
}

function Write-Status($status, $msg) {
    if ($Quiet) { return }

    switch ($status) {
        "PASS" { Write-Host "[PASS] $msg" -ForegroundColor Green }
        "FAIL" { Write-Host "[FAIL] $msg" -ForegroundColor Red }
        "WARN" { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
        "INFO" { Write-Host "[INFO] $msg" -ForegroundColor Gray }
    }
}

function Get-FileHash256($path) {
    if (-not (Test-Path $path)) { return $null }
    return (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLower()
}

# Check manifest exists
if (-not (Test-Path $ManifestPath)) {
    Write-Status "FAIL" "Manifest not found: $ManifestPath"
    if (-not $Quiet) {
        Write-Host ""
        Write-Host "MANIFEST: NO_MANIFEST" -ForegroundColor Red
        Write-Host "Run install.ps1 to create manifest." -ForegroundColor Yellow
    }
    exit 2
}

# Load manifest
try {
    $manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
} catch {
    Write-Status "FAIL" "Invalid manifest JSON"
    exit 1
}

if (-not $Quiet) {
    Write-Host ""
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  MANIFEST VERIFICATION" -ForegroundColor White
    Write-Host "=======================================================" -ForegroundColor White
    Write-Host "  Version: $($manifest.version)" -ForegroundColor Gray
    Write-Host "  Generated: $($manifest.generated_at)" -ForegroundColor Gray
    Write-Host "  Mode: $(if ($Quick) { 'QUICK (existence only)' } else { 'FULL (hash verification)' })" -ForegroundColor Gray
    Write-Host ""
}

$passed = 0
$failed = 0
$missing = 0
$mismatches = @()

foreach ($file in $manifest.files) {
    $fullPath = Join-Path $BaseDir $file.path

    if (-not (Test-Path $fullPath)) {
        Write-Status "FAIL" "Missing: $($file.path)"
        $missing++
        $failed++
        $mismatches += @{ path = $file.path; reason = "missing" }
        continue
    }

    if ($Quick) {
        # Quick mode: only check existence
        Write-Status "PASS" "Exists: $($file.path)"
        $passed++
        continue
    }

    # Full mode: verify hash
    $actualHash = Get-FileHash256 $fullPath

    if ($actualHash -eq $file.sha256) {
        Write-Status "PASS" "$($file.path)"
        $passed++
    } else {
        Write-Status "FAIL" "$($file.path) (hash mismatch)"
        $failed++
        $mismatches += @{
            path = $file.path
            reason = "hash_mismatch"
            expected = $file.sha256.Substring(0, 16) + "..."
            actual = $actualHash.Substring(0, 16) + "..."
        }
    }
}

# Summary
if (-not $Quiet) {
    Write-Host ""
    Write-Host "-------------------------------------------------------" -ForegroundColor Gray
}

if ($failed -eq 0) {
    if (-not $Quiet) {
        Write-Host ('MANIFEST: VERIFIED (' + $passed + ' files)') -ForegroundColor Green
    }
    exit 0
} else {
    if (-not $Quiet) {
        Write-Host ('MANIFEST: FAILED (' + $failed + ' issues, ' + $passed + ' passed)') -ForegroundColor Red
        Write-Host ''
        Write-Host 'Mismatches:' -ForegroundColor Yellow
        foreach ($m in $mismatches) {
            if ($m.reason -eq 'missing') {
                Write-Host ('  - ' + $m.path + ': MISSING') -ForegroundColor Red
            } else {
                Write-Host ('  - ' + $m.path + ': expected ' + $m.expected + ', got ' + $m.actual) -ForegroundColor Red
            }
        }
        Write-Host ''
        Write-Host 'Recovery: Run update.ps1 or reinstall with install.ps1' -ForegroundColor Yellow
    }
    exit 1
}
