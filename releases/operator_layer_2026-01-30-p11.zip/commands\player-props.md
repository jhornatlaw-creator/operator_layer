# /player-props - Player Props Arbitrage Scanner

Load the player props workspace for sportsbook and Kalshi arbitrage.

## Workspace

| Item | Path |
|------|------|
| xprediction | `C:\Users\J\xprediction` |
| Electron App | `C:\Users\J\xprediction\player-props-app` |
| Desktop Shortcut | `C:\Users\J\Desktop\Player Props.bat` |

## Boot Sequence

1. Read `C:\Users\J\xprediction\STATE.md`
2. Check git status
3. Verify app runs: `cd player-props-app && npm start`

## Data Sources

| Source | Endpoint | Auth | Props |
|--------|----------|------|-------|
| TheOddsApi | `/events/{id}/odds?markets=player_*` | API Key | 85+ sportsbooks |
| Underdog | `/beta/v6/over_under_lines` | None | DFS props |
| **Kalshi** | `/trade-api/v2/markets` | None (public) | NBA/NFL player props |

## Kalshi Player Props Markets

Kalshi has individual player prop series (discovered 2026-01-29):

| Series | Sport | Stat |
|--------|-------|------|
| KXNBAPTS | NBA | Points |
| KXNBAREB | NBA | Rebounds |
| KXNBAAST | NBA | Assists |
| KXNFLPASSTDS | NFL | Passing TDs |
| KXNFLPASSYDS | NFL | Passing Yards |
| KXNFLRSHYDS | NFL | Rushing Yards |
| KXNFLRECYDS | NFL | Receiving Yards |
| KXNFLANYTD | NFL | Anytime TD |

**Ticker Format:** `KXNBAPTS-26JAN30DETGSW-GSWSCURRY30-40`
- Series + Date + Game + Player + Line

**Title Format:** "Stephen Curry: 40+ points"

## CLI Commands

```bash
# List NBA games (sportsbook)
python -m xprediction.tools.props_api games

# Fetch props for a game (sportsbook)
python -m xprediction.tools.props_api props EVENT_ID --books dk,fd,ud

# Find arbs between sportsbooks
python -m xprediction.tools.props_api arbs EVENT_ID --min-edge 0.005

# Compare all props from sportsbooks
python -m xprediction.tools.props_api compare EVENT_ID --books dk,fd,ud

# List Kalshi player prop series (--sport can be before or after subcommand)
python -m xprediction.tools.props_api kalshi-series --sport nba
python -m xprediction.tools.props_api --sport nba kalshi-series  # also works

# Fetch Kalshi player props
python -m xprediction.tools.props_api kalshi-props --series KXNBAPTS --sport nba

# Compare Kalshi vs sportsbooks (fee-adjusted arb detection)
python -m xprediction.tools.props_api kalshi-compare EVENT_ID --books dk,fd --kalshi-series KXNBAPTS
```

## Fee-Adjusted Arb Calculations

**Kalshi taker fee:** `7% × P × (1-P)` (max 1.75¢ at 50¢)

The `kalshi-compare` and Props Comparison use fee-adjusted probabilities:
- Sportsbook odds: vig is embedded, no additional fee
- Kalshi prices: fee added to effective probability

**Output fields when arb exists:**
| Field | Description |
|-------|-------------|
| `total_implied` | Fee-adjusted sum of both sides |
| `profit_pct` | Realistic profit after fees |
| `stake_kalshi_yes/no` | Kalshi stake fraction |
| `stake_book_under/over` | Sportsbook stake fraction |
| `kalshi_fee_cents` | The Kalshi fee amount |
| `has_arb` | Boolean: is there an arb? |

**Example:** Kalshi 45¢ + Book 50% → raw 95%, but fee-adjusted 96.73% (3.4% profit, not 5.3%)

## Launch App

```bash
# Via shortcut
"C:\Users\J\Desktop\Player Props.bat"

# Or directly
cd C:\Users\J\xprediction\player-props-app && npm start
```

## Key Modules

```python
from xprediction.props import (
    PropsAggregator,      # Fetch from sportsbooks
    PropsArbDetector,     # Find Over/Under arbs
    PropMatcher,          # Fuzzy name matching
    NormalizedProp,       # Unified prop model
    PropArbOpportunity,   # Detected arb
    StatType,             # POINTS, REBOUNDS, etc.
    KalshiPropsClient,    # Kalshi API client
    KalshiProp,           # Kalshi prop model
    parse_prop_title,     # Parse "Stephen Curry: 40+ points"
)
```

## UI Features

The Electron app has four tabs:

1. **Arb Scanner** - Find Over/Under arbs across sportsbooks
   - **Profit (Fee-Adj)**: Explicitly labeled fee-adjusted profit %
   - **Dollar Stakes**: Shows "$X Over / $Y Under" for chosen stake total
   - **Stake Total Input**: Configurable total stake (default $100)
   - **Expected Profit**: Shows "+$X.XX" expected return
   - Hover profit cell for raw vs fee-adjusted comparison

2. **Props Comparison** - Compare odds across all books
3. **Kalshi Props** - View Kalshi player prop markets
4. **Kalshi Compare** - Match Kalshi props vs sportsbooks with confidence scores

## Safety Rules

### NEVER
- Bet both sides at same book (no arb possible)
- Trust stale odds (check `fetched_at`)
- Assume Kalshi has no player props (it does!)

### ALWAYS
- Verify arbs manually before betting
- Check line matches exactly (25.5 =/= 26.5)
- Use kalshi-compare for cross-platform arb detection

## Related Skills

- `/xprediction` - Full xprediction workspace
- `/kalshi` - Kalshi trading bot
- `/sports-arb` - Cross-platform sports arbitrage
