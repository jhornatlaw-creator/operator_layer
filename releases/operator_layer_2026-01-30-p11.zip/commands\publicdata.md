# PublicData Address Lookup

Run PublicData.com Texas criminal records search for address enrichment.

## What This Does

- Searches PublicData.com for defendant by name + DOB
- Extracts address information from Texas DPS records
- Returns street address, city, state, ZIP (including ZIP+4 when available)
- Tracks criminal record counts (Harris, Montgomery, TXDPS matches)

## Script Location

```
C:\Users\J\the_brain\lib\adapters\publicdata_adapter.py
```

## Usage

### Single Lookup (Interactive)
```python
import sys
sys.path.insert(0, r'C:\Users\J\the_brain')
from lib.adapters.publicdata_adapter import PublicDataSearcher

class App:
    def log(self, msg): print(msg)

searcher = PublicDataSearcher(app=App(), headless=False)
results = searcher.search("SMITH, JOHN", dob="01/15/1980")
print(results)
searcher.close()
```

### Batch Processing (DataFrame)
```python
from lib.adapters.publicdata_adapter import run_publicdata_automation, run_txdps_deep_dive
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler())

# First pass - search all defendants
df = run_publicdata_automation(df, "output.csv", logger)

# Second pass - deep dive on TXDPS hits
df = run_txdps_deep_dive(df, "output.csv", logger)
```

### Address Enrichment (Q1 addresses)
```python
from lib.address_enrichment import enrich_csv

# Enrich invalid addresses using PublicData DPS lookup
enrich_csv("data_melissa.csv", limit=20, headless=False)
```

## Environment Variables

Set in `C:\Users\J\the_brain\.env`:
- `PUBLICDATA_USERNAME` - PublicData login
- `PUBLICDATA_PASSWORD` - PublicData password

## Output Columns Added

| Column | Description |
|--------|-------------|
| pd_status | Search result status |
| pd_txdps_match | Y/N for Texas DPS match |
| pd_harris_count | Harris County record count |
| pd_montgomery_count | Montgomery County record count |
| pd_exact_match | Exact name matches |
| pd_exact_with_dob | DOB-verified matches |
| pd_dps_conviction_count | Conviction count (deep dive) |
| pd_dps_offenses | Offense descriptions (deep dive) |

## Integration with Scrapers

Fort Bend, Harris, Montgomery scrapers can call PublicData for address enrichment:

```python
# In scraper, after extracting defendant info:
from lib.adapters.publicdata_adapter import PublicDataSearcher

# Initialize once
pd_searcher = PublicDataSearcher(app=self, headless=True)
pd_searcher.navigate_to_texas_criminal()

# For each defendant:
results = pd_searcher.search(defendant_name, dob=defendant_dob)
# results contains address data if found

pd_searcher.close()
```

## Quick Test

```powershell
cd C:\Users\J\the_brain
python -c "from lib.adapters.publicdata_adapter import PublicDataSearcher; print('PublicData adapter OK')"
```
