# Address Synthesizer

Build the best address from multiple sources (Bond, Landing, Original).

## What This Does

- Combines address data from Bond (authoritative), Landing, and Original sources
- Bond always trumps Landing when addresses differ completely
- Complements Bond with apt/lot/unit from Landing when same base address
- Fixes common OCR truncation issues (D R → DR, FORES T → FOREST, etc.)
- Outputs synthesized street, city, state, zip with confidence score

## Script Location

```
C:\Users\J\OneDrive\HarrisCounty\SYNTHESIZE_addresses.py
```

## Priority Logic

1. **All sources match (85%+ similarity)** → Build complete address from all, pick longest base + best apt
2. **Bond exists, different from Landing** → Bond wins (downstream Melissa/AE09/Google verifies)
3. **Same street number, Landing has apt/lot** → Use Bond base + append Landing's apt/lot
4. **No Bond** → Use Landing (with Original complement if matching)
5. **Only Original** → Use Original

## Usage

### Standalone CLI (drag-and-drop or argument)
```powershell
python "C:\Users\J\OneDrive\HarrisCounty\SYNTHESIZE_addresses.py" "input.csv"
# Output: input_synthesized.csv (same directory)
```

### Programmatic (import functions)
```python
import sys
sys.path.insert(0, r'C:\Users\J\OneDrive\HarrisCounty')

# Import core functions
exec(open(r'C:\Users\J\OneDrive\HarrisCounty\SYNTHESIZE_addresses.py', encoding='utf-8').read().split('# Main processing')[0])

# Single address synthesis
street, score = build_address(original_street, landing_street, bond_street)

# Location synthesis (city/state/zip)
city = synthesize_location(row, 'City')   # Bond > Landing > Original
state = synthesize_location(row, 'State')
zip_code = synthesize_location(row, 'Zip')
```

### Batch Processing (DataFrame)
```python
import pandas as pd
import sys
sys.path.insert(0, r'C:\Users\J\OneDrive\HarrisCounty')
exec(open(r'C:\Users\J\OneDrive\HarrisCounty\SYNTHESIZE_addresses.py', encoding='utf-8').read().split('# Main processing')[0])

df = pd.read_csv('input.csv')

results = df.apply(lambda row: build_address(
    row.get('address'),
    row.get('LandingStreet'),
    row.get('BondStreet')
), axis=1)

df['Synthesized_Street'] = results.apply(lambda x: x[0])
df['Synthesized_Score'] = results.apply(lambda x: x[1])
df['Synthesized_City'] = df.apply(lambda r: synthesize_location(r, 'City'), axis=1)
df['Synthesized_State'] = df.apply(lambda r: synthesize_location(r, 'State'), axis=1)
df['Synthesized_Zip'] = df.apply(lambda r: synthesize_location(r, 'Zip'), axis=1)

df.to_csv('output.csv', index=False)
```

## Expected Input Columns

| Column | Description |
|--------|-------------|
| address | Original/disposition address |
| LandingStreet | Court website landing page address |
| BondStreet | OCR'd bond document address |
| city / LandingCity / BondCity | City from each source |
| state / LandingState / BondState | State from each source |
| zip / LandingZip / BondZip | ZIP from each source |

## Output Columns Added

| Column | Description |
|--------|-------------|
| Synthesized_Street | Best combined street address |
| Synthesized_City | Best city (Bond > Landing > Original) |
| Synthesized_State | Best state |
| Synthesized_Zip | Best ZIP |
| Synthesized_Score | Confidence score (see below) |

## Score Guide

| Score | Meaning |
|-------|---------|
| 95 | All 3 sources match + apartment found |
| 90 | All 3 sources match perfectly |
| 85 | 2 sources match + apartment found |
| 80 | 2 sources match |
| 75 | Bond + Landing apt/lot complement |
| 70 | Built from 2 matching sources |
| 65 | Bond used (sources differ) |
| 60 | Landing only |
| 50 | Only 1 source available |
| 0 | No address data |

## Core Functions

### `build_address(original, landing, bond)`
Returns `(synthesized_street, score)` tuple.

### `synthesize_location(row, field)`
Returns best value for City/State/Zip using Bond > Landing > Original priority.

### `fix_truncation(addr)`
Fixes common OCR truncation: `D R` → `DR`, `FORES T` → `FOREST`, etc.

### `get_apartment(addr)`
Extracts apt/unit/suite/lot number from address string.

### `addresses_match(a, b)`
Returns True if addresses are 85%+ similar with same street number.

## Integration with harris_unified.py

harris_unified.py has its own synthesis phase that:
1. Tries GPT-4o synthesis first (when 2+ sources)
2. Falls back to similar logic (but GPT biases toward Landing)

This standalone script is the **authoritative Bond-first** implementation.

## Downstream Verification

After synthesis, addresses go through:
1. **Melissa** - USPS validation
2. **AE09** - Additional enrichment
3. **Google** - Geocoding verification

These downstream phases correct any OCR errors that Bond-first logic preserves.
