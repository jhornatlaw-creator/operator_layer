---
name: bootstrap_context
description: Create baseline context for first-time users or after context loss. One-step recovery from BLOCKED boot state.
operator_layer_version: 2026-01-30-p5
---

# /bootstrap_context

Creates a minimal valid `latest.json` to resolve the first-run deadlock when `/boot` is BLOCKED due to missing context.

## When to Use

- First-time Claude Code user (no prior `/save_context`)
- Lost `latest.json` and no archives available
- Want to reset context to clean baseline

## Behavior

1. Captures runtime timestamp (single source of truth)
2. Creates minimal context object with safe defaults
3. Writes atomically to `latest.json`
4. Creates timestamped archive
5. Emits WRITEBACK status block

---

## Execution Steps

### Step 1: Generate timestamp (CRITICAL - capture ONCE)

**This is the single source of truth for the bootstrap timestamp.**

```powershell
powershell -Command "Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'"
```

**IMPORTANT:** Capture this value ONCE and use it for:
1. The `timestamp` field in latest.json
2. The archive filename

Store as `$BOOTSTRAP_TIMESTAMP` (conceptually). Example: `2026-01-30T14:25:00`

Derive archive filename: `session_20260130_1425.json` (from same timestamp)

### Step 2: Build minimal context object

Create a JSON object with safe defaults. **Use ONLY fields from the existing schema (see Appendix in boot.md):**

```json
{
  "timestamp": "<$BOOTSTRAP_TIMESTAMP>",
  "operator_layer_version": "2026-01-30-p5",
  "project_loader": "none",
  "execution_mode": "review_only",
  "project_path": "unknown",
  "initiative_level": 2,
  "target": "none",
  "last_commands": [
    "/bootstrap_context"
  ],
  "current_objective": "none",
  "work_completed": [],
  "next_actions": [],
  "open_questions": [],
  "files_modified": [],
  "notes": "Bootstrap baseline created. Run /boot to start session."
}
```

### Step 3: Atomic write to latest.json

**Step 3.1: Write to temp file**

Write the JSON to: `C:\Users\J\.claude\context\latest.json.tmp`

**Step 3.2: Atomic move**

```powershell
powershell -Command "Move-Item -Force 'C:\Users\J\.claude\context\latest.json.tmp' 'C:\Users\J\.claude\context\latest.json'"
```

**Step 3.3: Post-write verification (MANDATORY)**

```powershell
powershell -Command "(Get-Content 'C:\Users\J\.claude\context\latest.json' -Raw | ConvertFrom-Json).timestamp"
```

**Compare output to `$BOOTSTRAP_TIMESTAMP`:**

- **If match:** Write succeeded. Continue to Step 4.
- **If mismatch or error:** Write failed. See error handling below.

### Step 4: Create timestamped archive (MANDATORY)

Always create an archive copy:

```powershell
powershell -Command "Copy-Item 'C:\Users\J\.claude\context\latest.json' 'C:\Users\J\.claude\context\session_<YYYYMMDD_HHMM>.json'"
```

Derive filename from `$BOOTSTRAP_TIMESTAMP`: `2026-01-30T14:25:00` -> `session_20260130_1425.json`

### Step 5: Report WRITEBACK status

**On success:**

```
-- WRITEBACK -----------------------------------
status: OK
timestamp: <$BOOTSTRAP_TIMESTAMP>
verified: timestamp in latest.json matches expected

files_written:
  latest.json: OK (timestamp verified)
  archive: session_YYYYMMDD_HHMM.json

summary:
  project_loader: none
  execution_mode: review_only
  objective: none
  next_actions: 0

Bootstrap complete. Run /boot to start session.
------------------------------------------------
```

**On failure:**

```
-- WRITEBACK -----------------------------------
status: FAILED
reason: <error message>
path: C:\Users\J\.claude\context\latest.json

RECOVERY:
1. Check disk space: dir C:\Users\J\.claude\context\
2. Check permissions: icacls C:\Users\J\.claude\context\
3. Try again: /bootstrap_context

Your bootstrap JSON (copy this if needed):
<JSON content here>
------------------------------------------------
```

---

## Schema Validation

The bootstrap creates a JSON that passes `/boot` validation:

| Check | Requirement | Bootstrap Provides |
|-------|-------------|-------------------|
| JSON parses | Valid JSON syntax | Yes (generated) |
| timestamp exists | ISO8601 string | Yes ($BOOTSTRAP_TIMESTAMP) |
| timestamp parseable | DateTime.Parse succeeds | Yes (standard format) |
| optional fields | Default safely | All set to safe defaults |

---

## Error Handling

### Directory doesn't exist

```powershell
powershell -Command "New-Item -ItemType Directory -Force -Path 'C:\Users\J\.claude\context'"
```

Then retry write.

### Write permission denied

```
-- WRITEBACK -----------------------------------
status: FAILED
reason: Permission denied writing to context directory

RECOVERY:
1. Check permissions: icacls C:\Users\J\.claude\context\
2. Create directory manually: mkdir C:\Users\J\.claude\context
3. Retry: /bootstrap_context
------------------------------------------------
```

### Timestamp mismatch after write

This indicates a write race or corruption. Report FAILED and include the JSON for manual recovery.

---

## Relationship to Other Commands

| Command | Relationship |
|---------|--------------|
| `/boot` | Bootstrap resolves BLOCKED state; then run /boot |
| `/save_context` | Bootstrap is minimal version; save_context captures full session state |
| `/load_context` | Works after bootstrap creates latest.json |

---

## When NOT to Use

- **Valid latest.json exists:** Use `/boot` directly
- **Archives exist:** Prefer restoring from archive (more context preserved)
- **Mid-session:** Use `/save_context` instead (preserves work)

---

## Example Workflow

```
User: /boot
Claude: REHYDRATION: BLOCKED (missing latest.json)
        Run /bootstrap_context to create baseline, then rerun /boot.

User: /bootstrap_context
Claude: WRITEBACK: OK, timestamp: 2026-01-30T14:25:00
        Bootstrap complete. Run /boot to start session.

User: /boot
Claude: REHYDRATION: LOADED, age: 0.0h
        Ready.
```

---

## Operator Notes

**Canonical spec:** See `C:\Users\J\.claude\RUNBOOK_REHYDRATION.md`

- Use only for first-time setup or when all recovery options exhausted
- **Idempotent but destructive:** Overwrites existing `latest.json` (archive created)
- Prefer restoring from `session_*.json` archive if available (preserves more context)
- After bootstrap, immediately run `/boot` to verify LOADED status
- Does NOT create memory bundle; that happens on first `/save_context` in a managed repo
