# /find-ncaab-game - Find NCAAB Game on Kalshi

Find moneyline, spread, and total markets for any NCAAB game on Kalshi.

## Usage

```bash
python -m xprediction.tools.find_ncaab_game TEAM1 TEAM2
```

## Examples

```bash
# Find Lehigh vs Army
python -m xprediction.tools.find_ncaab_game lehigh army

# Find Michigan vs Michigan State
python -m xprediction.tools.find_ncaab_game michigan "michigan st"

# Output as JSON
python -m xprediction.tools.find_ncaab_game lehigh army --json
```

## Output

Returns all available markets:
- **Moneyline**: `KXNCAAMBGAME-{DATE}{AWAY}{HOME}-{TEAM}`
- **Spread**: `KXNCAAMBSPREAD-{DATE}{AWAY}{HOME}-{TEAM}{SPREAD}`
- **Total**: `KXNCAAMBTOTAL-{DATE}{AWAY}{HOME}-{TOTAL}`

Each market shows:
- Ticker (for trading)
- Title
- Yes bid/ask
- No bid/ask
- Volume

## Series Reference

| Market Type | Series Ticker |
|-------------|---------------|
| Moneyline | `KXNCAAMBGAME` |
| Spread | `KXNCAAMBSPREAD` |
| Total | `KXNCAAMBTOTAL` |

## Ticker Format

`KX{SERIES}-{YY}{MON}{DD}{AWAY}{HOME}-{OUTCOME}`

Example: `KXNCAAMBSPREAD-26JAN28LEHARMY-ARMY2`
- Series: NCAAMBSPREAD (spread)
- Date: 26JAN28 (Jan 28, 2026)
- Away: LEH (Lehigh)
- Home: ARMY (Army)
- Outcome: ARMY2 (Army -2.5)
