---
name: crypto
description: Load crypto trading context for 15-min direction markets
---

# /crypto - Crypto 15-Minute Direction Trading

Load the crypto trading workspace for BTC/ETH/SOL 15-minute direction markets on Kalshi.

## Workspace

| Item | Path |
|------|------|
| xprediction | `C:\Users\J\xprediction` |
| kalshi | `C:\Users\J\kalshi` |
| polymarket | `C:\Users\J\polymarket` |

## Boot Sequence

1. Read `C:\Users\J\kalshi\STATE.md`
2. Check git status for all three repos
3. Run kalshi tests: `cd C:\Users\J\kalshi && python -m pytest tests/ -q`

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    CRYPTO TRADING                           │
├─────────────────────────────────────────────────────────────┤
│  Price Feeds                                                │
│    CoinGecko, Binance → real-time crypto prices             │
├─────────────────────────────────────────────────────────────┤
│  Polymarket (Emitter)                                       │
│    pm.crypto.CryptoPriceEmitter → price signals             │
│    pm.crypto.Crypto15MFleet → multi-symbol fleet            │
├─────────────────────────────────────────────────────────────┤
│  xprediction (Shared Data)                                  │
│    xprediction.signals.SqliteSignalStore → signal bus       │
├─────────────────────────────────────────────────────────────┤
│  Kalshi (Consumer)                                          │
│    kalshi.runner.CrossPlatformRunner → consumes signals     │
│    kalshi.strategies → OrderFlowSignal, MeanReversionSignal │
└─────────────────────────────────────────────────────────────┘
```

## Market Tickers

| Symbol | Kalshi Ticker Pattern |
|--------|----------------------|
| BTC | KXBTC15M-*, KXBTC-*-T* |
| ETH | KXETH15M-*, KXETH-*-T* |
| SOL | KXSOL15M-*, KXSOL-*-T* |

## Key Modules

### From Polymarket (emitter side)
```python
from pm.crypto import (
    CryptoPriceEmitter,
    CryptoEmitterConfig,
    Crypto15MFleet,
    run_crypto_fleet,
    SqliteSignalStore,
)

# Run the crypto emitter
emitter = CryptoPriceEmitter(signal_store, config)
await emitter.run()

# Or run the full fleet
await run_crypto_fleet(config)
```

### From Kalshi (consumer side)
```python
from kalshi.runner import CrossPlatformRunner, CrossPlatformConfig
from kalshi.strategies import (
    OrderFlowSignal,
    MeanReversionSignal,
    CombinedSignal,
)
from xprediction.signals import SqliteSignalStore

store = SqliteSignalStore("./signals.db")
runner = CrossPlatformRunner(
    client=kalshi_client,
    signal_store=store,
    tickers=["KXBTC-26JAN14-T95000"],
)
await runner.run(duration_s=3600)
```

### Signal Types (crypto-specific)
```python
from kalshi.strategies import OrderFlowSignal, MeanReversionSignal, CombinedSignal

# Order flow imbalance
of_signal = OrderFlowSignal(ticker="KXBTC15M")
of_signal.add_trade(trade)
print(of_signal.signal)  # BULLISH/BEARISH/NEUTRAL

# Mean reversion
mr_signal = MeanReversionSignal(ticker="KXBTC15M")
mr_signal.add_tick(snapshot)
print(mr_signal.signal)  # FADE_LONG/FADE_SHORT/NEUTRAL

# Combined signals
combined = CombinedSignal(ticker="KXBTC15M")
combined.add_trade(trade)
combined.add_tick(snapshot)
print(combined.signal)  # STRONG_BUY/BUY/SELL/STRONG_SELL/HOLD
```

## Fee Calculations

**Kalshi**: 7% × P × (1-P) taker, 1.75% × P × (1-P) maker

```python
from xprediction.arb.models import calc_kalshi_fee_cents

fee = calc_kalshi_fee_cents(50, is_maker=False)  # 1.75¢
fee = calc_kalshi_fee_cents(50, is_maker=True)   # 0.4375¢
```

## CLI Commands

```powershell
# Polymarket side - run crypto emitter
cd C:\Users\J\polymarket
pm crypto-emit --store ./signals.db

# Run crypto fleet (multi-symbol)
pm crypto-fleet --config ./fleet_config.yaml

# Kalshi side - paper trade with signals
cd C:\Users\J\kalshi
kalshi run-paper KXBTC15M-... --signal-store ./signals.db

# Discovery - find active crypto markets
kalshi discover-crypto --symbol BTC
```

## Distinct from Sports Arb

| Aspect | Crypto | Sports Arb |
|--------|--------|------------|
| Module | `pm.crypto`, `kalshi.strategies` | `pm.sports`, `kalshi.sports` |
| Signal Source | CoinGecko/Binance prices | Polymarket game odds |
| Market Type | 15-min direction | Game outcome |
| Signal Class | OrderFlowSignal, MeanReversionSignal | CrossPlatformSignal |
| Time Horizon | 15 minutes | Game duration |

## Safety Rules

### NEVER
- Trade live without `--live --i-understand-live-trading`
- Exceed position limits (check risk manager)
- Ignore circuit breaker triggers

### ALWAYS
- Monitor price feed health
- Check for stale orderbook data
- Use paper mode for testing
