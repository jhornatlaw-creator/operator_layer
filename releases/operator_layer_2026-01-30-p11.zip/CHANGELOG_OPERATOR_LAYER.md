# Operator Layer Changelog

All notable changes to the Claude Code operator layer (commands, rehydration, memory persistence).

Format: `[version] - YYYY-MM-DD`

---

## [2026-01-30-p11] - 2026-01-30

### Added
- `lib/boot_guard.ps1` - Read-only safety check for /boot
- `lib/guard_policy.json` - Configurable guard thresholds
- BOOT GUARD step in `/boot` (Step 1.6, after rehydration)
- Safety modes: SAFE, CAUTION, LOCKED
- Detection signals: dirty repo, unpushed commits, recent conflicts, stale context, live processes
- `guard_mode` diagnostic in `/boot` output

### Changed
- `/boot` now includes BOOT GUARD block before project detection
- LOCKED mode halts boot until environment is safe
- CAUTION mode warns but allows proceed
- `RUNBOOK_REHYDRATION.md` - Added BOOT GUARD section

### Non-Destructive Guarantee
BOOT GUARD never modifies git state, never kills processes, never auto-commits. It only reports and recommends.

---

## [2026-01-30-p10] - 2026-01-30

### Added
- `release.ps1` - Build distributable release zip + manifest from installed tree
- `lib/download_release.ps1` - HTTPS download + SHA256 verification + extraction
- `lib/schedule_updates.ps1` - Install/query/remove scheduled update tasks
- `releases/` directory for local release builds
- `-ReleaseUrl` parameter for `install.ps1` (install from release zip)
- `-Channel Release` parameter for `update.ps1` (update from release zip)
- `-ReleaseIndexUrl` parameter for `update.ps1` (fetch release metadata)
- `-BasePath` parameter for `verify_manifest.ps1` (verify extracted releases)
- `lib/update_status.json` - Status snapshot from update checks
- `backups/` directory for pre-update backups

### Changed
- `install.ps1` - Now supports `-ReleaseUrl` for installing from release zips
- `update.ps1` - Now supports `-Channel Release` for release-based updates
- `verify_manifest.ps1` - Now supports custom base path for release verification

### Scheduled Tasks
- `ClaudeOps\OperatorLayerVerifyDaily` - Runs daily at 7:00 AM (verify-only)
- `ClaudeOps\OperatorLayerUpdateWeekly` - Runs Sunday at 4:00 AM (configurable)

### Distribution Workflow
1. `release.ps1` builds `releases/operator_layer_<version>.zip`
2. `install.ps1 -ReleaseUrl <zip>` installs from release
3. `update.ps1 -Channel Release -ReleaseUrl <zip>` updates from release
4. `schedule_updates.ps1 -Install` enables automatic update checks

---

## [2026-01-30-p9] - 2026-01-30

### Added
- `lib/schedule_maintenance.ps1` - Install/query/remove scheduled maintenance tasks
- `lib/notify.ps1` - Windows toast notifications with fallback
- `lib/maintenance_status.json` - Status snapshot from last maintenance run
- `logs/maintenance/` - Log files from scheduled maintenance runs
- Maintenance status line in `/boot` diagnostics
- `-Silent`, `-Notify`, `-RunConflicts` parameters for maintenance.ps1

### Changed
- `lib/maintenance.ps1` - Extended with logging, status output, notifications
- `/boot` now shows `maintenance_last: <age>h | status: OK/WARN/ERROR`
- `RUNBOOK_REHYDRATION.md` - Added Scheduled Maintenance section

### Scheduled Tasks
- `ClaudeOps\MaintenanceDaily` - Runs daily at 6:00 AM (DryRun + conflicts)
- `ClaudeOps\MaintenanceWeekly` - Runs Sunday at 3:00 AM (retention + conflicts)

---

## [2026-01-30-p8] - 2026-01-30

### Added
- `lib/context_conflicts.ps1` - Conflict detection and resolution for multi-machine sync
- `context/machine_id.txt` - Stable machine identifier (GUID) for conflict tracking
- `context/latest.pointer` - Pointer to newest archive (fallback reference)
- `context/CONFLICTS/` - Preservation directory for conflict artifacts
- Conflict detection in `/boot` (Step 1.5.1.5)
- CONTEXT_CONFLICT diagnostic block in `/boot`
- Smoke tests E, F, G for conflict scenarios

### Changed
- `/boot` now detects and resolves sync conflicts (OneDrive, Dropbox, etc.)
- `/save_context` now creates machine_id.txt and latest.pointer
- `smoke_tests.ps1` extended from 4 to 7 tests
- `RUNBOOK_REHYDRATION.md` - Added Conflict Resolution section

### Resolution Rules
Conflict resolution is deterministic: newest JSON timestamp wins, with file mtime and lexical filename as tie-breakers. All candidates are preserved in `CONFLICTS/` folder with full audit trail.

---

## [2026-01-30-p7] - 2026-01-30

### Added
- `install.ps1` - One-command installer for operator layer
- `update.ps1` - Updater that preserves user state (context\)
- `VERSION` - Current version string file
- `operator_layer_manifest.json` - File hashes for verification
- `lib/verify_manifest.ps1` - Manifest verification utility
- `INSTALLER_README.md` - Installer documentation
- Version reporting in `/boot` diagnostics (Step 0.5)

### Changed
- `/boot` now displays `operator_layer: <version> | manifest: <status>`
- `RUNBOOK_REHYDRATION.md` - Added Install/Update section

### Notes
- Installer is idempotent (safe to re-run)
- Context directory (latest.json, archives) is NEVER touched by install/update
- Source can be local path or git repository URL

---

## [2026-01-30-p6] - 2026-01-30

### Added
- `CHANGELOG_OPERATOR_LAYER.md` - Version tracking for operator layer
- `lib/maintenance.ps1` - Archive retention, integrity checks, smoke test runner
- Rollback procedure documented in `RUNBOOK_REHYDRATION.md`
- Retention policy (configurable: keep N days or N archives)

### Changed
- `RUNBOOK_REHYDRATION.md` - Added Release, Rollback, Retention, Maintenance sections

---

## [2026-01-30-p5] - 2026-01-30

### Added
- `/bootstrap_context` command - One-step recovery for missing `latest.json`
- Schema validation in `/boot` (timestamp exists + parseable)
- Schema validation in `/save_context` (post-write verification)
- `lib/smoke_tests.ps1` - Automated test harness (4 scenarios)
- `RUNBOOK_REHYDRATION.md` - Canonical spec for rehydration system
- Operator Notes sections in all command files

### Changed
- `/boot` missing-file recovery now points to `/bootstrap_context`
- Smoke tests include PowerShell help header

---

## [2026-01-30-p4] - 2026-01-30

### Added
- Memory bundle loading in `/boot` (MEMORY BUNDLE block)
- Timestamp integrity check (JSON timestamp vs file mtime)
- Marker self-auditing in `/save_context`
- Runtime timestamp capture (single source of truth)
- Post-write verification for `latest.json`

### Changed
- `/boot` now surfaces recent entries from verified.md, decisions.md, runbook.md

---

## [2026-01-30-p3] - 2026-01-30

### Added
- Per-project memory bundle (`.claude/memory/*.md`)
- 6 bundle files: progress.md, decisions.md, verified.md, runbook.md, context.md, proof.md
- Marker system: `DECISION:`, `VERIFIED:`, `RUNBOOK:`, `UPDATE_CONTEXT:`
- Bundle write-back in `/save_context`
- `memory_bundle` diagnostic in `/boot`

---

## [2026-01-30-p2] - 2026-01-30

### Added
- Atomic writes for `latest.json` (write to .tmp, then Move-Item)
- Mandatory timestamped archives (`session_YYYYMMDD_HHMM.json`)
- WRITEBACK status block in `/save_context`

### Changed
- Archive creation is now mandatory (not optional)

---

## [2026-01-30-p1] - 2026-01-30

### Added
- Auto-rehydration gate in `/boot` (Step 1.5)
- REHYDRATION block (LOADED/BLOCKED status)
- Freshness warnings (>24h, >7d)
- Recovery instructions for missing/corrupt JSON

### Changed
- `/boot` is now a hard gate (cannot proceed if BLOCKED)
- `/load_context` updated for compatibility with auto-rehydration

---

## [2026-01-26] - 2026-01-26

### Added
- Initial `/save_context` and `/load_context` commands
- `latest.json` schema defined
- Basic session persistence

---

## Version Naming Convention

`YYYY-MM-DD-pN` where:
- `YYYY-MM-DD` = release date
- `pN` = patch number within that day (p1, p2, ...)

Example: `2026-01-30-p5` = 5th iteration on January 30, 2026

---

## Rollback Reference

To rollback to a previous version:
1. Identify target version from this changelog
2. Restore command files from git or backup
3. Restore `latest.json` from appropriate `session_*.json` archive
4. See `RUNBOOK_REHYDRATION.md` → Rollback Procedure for details
