---
name: boot
description: GLOBAL session start. Loads operating doctrine, auto-rehydrates session context, and auto-detects project from pwd.
operator_layer_version: 2026-01-30-p11
---

# Global Boot Sequence

You are starting a JHORN Claude session across multiple projects.

## Step 0: Verify Date & Time (MANDATORY FIRST)

Run:
```powershell
powershell -Command "Get-Date -Format 'dddd, MMMM dd, yyyy  h:mm tt'"
```

Display prominently:
```
===========================================
SESSION: [Day], [Month] [DD], [YYYY] [HH:MM AM/PM]
===========================================
```

Reference this timestamp throughout the session for date-sensitive operations.

## Step 0.5: Report Operator Layer Version (Phase 7)

Read VERSION file if present:
```powershell
powershell -Command "if (Test-Path 'C:\Users\J\.claude\VERSION') { Get-Content 'C:\Users\J\.claude\VERSION' -Raw } else { 'unknown' }"
```

**Display in diagnostics:**
```
operator_layer: <version from VERSION file>
```

**Optional: Quick manifest check (existence only, not full hash verification):**
```powershell
powershell -Command "if (Test-Path 'C:\Users\J\.claude\operator_layer_manifest.json') { 'present' } else { 'missing' }"
```

**If VERSION missing:**
```
WARNING: VERSION file not found. Operator layer may not be properly installed.
         Run: powershell -File C:\Users\J\.claude\install.ps1 -Source <source>
```

**If manifest missing:**
```
WARNING: Manifest not found. Run install.ps1 or update.ps1 to generate.
```

These are warnings only. Do NOT block boot on version/manifest issues.

**Optional: Check last maintenance status (Phase 9):**
```powershell
powershell -Command "if (Test-Path 'C:\Users\J\.claude\lib\maintenance_status.json') { $s = Get-Content 'C:\Users\J\.claude\lib\maintenance_status.json' | ConvertFrom-Json; $age = [math]::Round(((Get-Date) - [DateTime]::Parse($s.last_run_at)).TotalHours, 1); Write-Output \"$($s.status) | ${age}h ago\" } else { 'not configured' }"
```

**Display in diagnostics:**
```
maintenance_last: <age>h | status: <OK|WARN|ERROR>
```

**If status is ERROR:**
```
WARNING: Last maintenance found errors. Check: C:\Users\J\.claude\lib\maintenance_status.json
```

This is a warning only. Do NOT block boot on maintenance issues.

## Step 1: Load Global Doctrine

Read the global operating doctrine:
- `C:\Users\J\.claude\CLAUDE.md`

Then restate the non-negotiables briefly:
- Initiative default (Level 2 unless overridden by project loader)
- Self-test required
- Plain English + proof
- Credentials sacred
- Small diffs preferred

## Windows Shell Rule
This environment is Windows. Use PowerShell or Git Bash consistently—not both in the same task. Prefer forward-slash paths in quotes (`"C:/Users/J/project"`) for cross-shell compatibility. After writing files, always run `npm install` (or equivalent) in the same working directory before executing.

## Step 1.5: Auto-Rehydrate Session Context (MANDATORY GATE)

**This is a hard gate.** Boot cannot proceed to "Ready" until rehydration status is resolved.

### Check for latest.json

Path: `C:\Users\J\.claude\context\latest.json`

**Step 1.5.1: Check existence**
```powershell
powershell -Command "Test-Path 'C:\Users\J\.claude\context\latest.json'"
```

**If returns `False` (file missing):**
```
── REHYDRATION ─────────────────────────
status: BLOCKED
reason: latest.json not found
path: C:\Users\J\.claude\context\latest.json

RECOVERY (one step):
  Run /bootstrap_context to create baseline, then rerun /boot.

ALTERNATIVE (if archives exist):
  dir C:\Users\J\.claude\context\session_*.json
  copy C:\Users\J\.claude\context\session_YYYYMMDD_HHMM.json C:\Users\J\.claude\context\latest.json

BOOT HALTED. Resolve rehydration before proceeding.
─────────────────────────────────────────
```
**STOP HERE. Do not proceed to Step 2.**

**If returns `True` (file exists):**
Continue to Step 1.5.1.5.

### Step 1.5.1.5: Conflict Detection (Phase 8)

**Check for sync conflicts** (multiple machines writing to same context directory via OneDrive/Dropbox/etc.)

Run conflict detection:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\context_conflicts.ps1" -Normalize
```

**Interpreting results:**

Exit code 0 = NO_CONFLICT (single valid latest.json, not stale)
```
CONFLICT_STATUS: NONE
```
→ Continue to Step 1.5.2.

Exit code 1 = CONFLICT_RESOLVED (conflicts detected and preserved)
```
── CONTEXT_CONFLICT ────────────────────
status: RESOLVED
winner: <filename>
rule: <timestamp_newest|mtime_newest|filename_lexical>
candidates: <N>
preserved: context\CONFLICTS\<timestamp>\
normalized: <true|false>
────────────────────────────────────────
```
→ If `normalized: true`, latest.json was atomically updated to winner content
→ All competing candidates preserved in CONFLICTS folder with resolution.json
→ This is **non-blocking** if winner is valid JSON
→ Continue to Step 1.5.2.

Exit code 2 = ERROR (script failure)
→ Treat as warning only; continue to Step 1.5.2

**Conflict detection catches:**
- OneDrive "conflicted copy" files (e.g., `latest (DESKTOP-ABC123's conflicted copy).json`)
- Dropbox conflict patterns (e.g., `latest (1).json`)
- Stale latest.json (older than newest archive by >5 minutes)
- Any `latest*.json` variant

**Resolution rules (deterministic, newest-wins):**
1. max(parsed_timestamp) from JSON
2. Tie-breaker: max(file_mtime)
3. Tie-breaker: lexical filename sort (stable)

**Preservation guarantee:**
All competing candidates are copied (never moved/deleted) to `context\CONFLICTS\<YYYYMMDD_HHMMSS>\` with a `resolution.json` audit trail.

### Step 1.5.2: Parse and Validate JSON

Read the file:
```powershell
powershell -Command "Get-Content 'C:\Users\J\.claude\context\latest.json' -Raw"
```

**If JSON parse fails (malformed):**
```
── REHYDRATION ─────────────────────────
status: BLOCKED
reason: invalid JSON in latest.json
path: C:\Users\J\.claude\context\latest.json

RECOVERY OPTIONS:
1. Restore from newest valid archive:
   dir C:\Users\J\.claude\context\session_*.json
   copy C:\Users\J\.claude\context\session_YYYYMMDD_HHMM.json C:\Users\J\.claude\context\latest.json
2. Delete and recreate: run /save_context after completing work

BOOT HALTED. Resolve rehydration before proceeding.
─────────────────────────────────────────
```
**STOP HERE. Do not proceed to Step 2.**

**If JSON parses successfully:**
Continue to Step 1.5.2.5.

### Step 1.5.2.5: Schema Validation (Phase 5)

Validate the parsed JSON meets minimum requirements:

**Check 1: timestamp field exists**
```powershell
powershell -Command "$j = Get-Content 'C:\Users\J\.claude\context\latest.json' | ConvertFrom-Json; if ($j.timestamp) { 'EXISTS' } else { 'MISSING' }"
```

**If MISSING:**
```
── REHYDRATION ─────────────────────────
status: BLOCKED
reason: latest.json missing required 'timestamp' field
path: C:\Users\J\.claude\context\latest.json

RECOVERY:
  Run /bootstrap_context to create valid baseline, then rerun /boot.

BOOT HALTED. Resolve rehydration before proceeding.
─────────────────────────────────────────
```
**STOP HERE. Do not proceed.**

**Check 2: timestamp is parseable**
```powershell
powershell -Command "try { [DateTime]::Parse((Get-Content 'C:\Users\J\.claude\context\latest.json' | ConvertFrom-Json).timestamp); 'VALID' } catch { 'INVALID' }"
```

**If INVALID:**
```
── REHYDRATION ─────────────────────────
status: BLOCKED
reason: latest.json 'timestamp' field is not a valid datetime
path: C:\Users\J\.claude\context\latest.json

RECOVERY:
  Run /bootstrap_context to create valid baseline, then rerun /boot.

BOOT HALTED. Resolve rehydration before proceeding.
─────────────────────────────────────────
```
**STOP HERE. Do not proceed.**

**If both checks pass:**
Continue to Step 1.5.3.

### Step 1.5.3: Compute Freshness and Render REHYDRATION Block

Calculate age from `timestamp` field vs current time.

```powershell
powershell -Command "$j = Get-Content 'C:\Users\J\.claude\context\latest.json' | ConvertFrom-Json; $ts = [DateTime]::Parse($j.timestamp); $age = (Get-Date) - $ts; Write-Output $age.TotalHours"
```

**Render the REHYDRATION block (always, when parse succeeds):**

```
── REHYDRATION ─────────────────────────
status: LOADED
path: C:\Users\J\.claude\context\latest.json
timestamp: <timestamp from file>
age_hours: <computed, rounded to 1 decimal>

project_loader: <value or "none">
execution_mode: <value or "unknown">
project_path: <value or "unknown">

current_objective:
  <value or "none specified">

work_completed:
  - <item 1>
  - <item 2>
  (or "none" if empty/missing)

next_actions:
  - [ ] <action 1>
  - [ ] <action 2>
  (or "none" if empty/missing)

open_questions:
  - <question 1>
  (or "none" if empty/missing)

files_modified:
  - <path 1>
  - <path 2>
  (or "none" if empty/missing)

notes: <value or "none">
─────────────────────────────────────────
```

### Step 1.5.4: Freshness Warning (non-blocking)

**If age_hours > 24:**
```
WARNING: Session context is >24 hours old. Verify objective is still current.
```

**If age_hours > 168 (7 days):**
```
WARNING: Session context is >7 days old. Consider starting fresh or updating objective.
```

These are warnings only. Do NOT block on staleness alone.

### Step 1.5.5: Timestamp Integrity Check (Phase 4)

Compare `timestamp` field to file mtime as a sanity check:

```powershell
powershell -Command "(Get-Item 'C:\Users\J\.claude\context\latest.json').LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss')"
```

**If timestamp and file mtime diverge by >1 hour:**
```
WARNING: latest.json timestamp differs from file mtime by >1 hour
  timestamp: <from JSON>
  file_mtime: <from filesystem>
  This may indicate a write bug or manual file edit.
```

This is a warning only. Do NOT block on mtime divergence.

### Step 1.5.6: Set rehydration_status

- If LOADED: set `rehydration_status=LOADED` and continue to Step 2
- If BLOCKED: boot is halted (already stopped above)

### Rehydration vs /load_context

- **Auto-rehydration (this step):** Always runs. Loads summary from latest.json. Does NOT auto-run project loader.
- **/load_context:** Optional deep restore. Auto-runs project loader. Use when you want to fully resume previous session.

After rehydration, you may still run `/load_context` for the full interactive restore experience.

---

## Step 1.6: BOOT GUARD (Safety Check)

**This step detects risky conditions and classifies the session into a safety mode.**

Run the guard check:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\J\.claude\lib\boot_guard.ps1" -RepoPath "<current_directory>"
```

Parse the JSON output and render:

```
── BOOT GUARD ──────────────────────────
mode: SAFE|CAUTION|LOCKED
reasons:
  - <reason 1>
  - <reason 2>
  (max 5 reasons)
recommended:
  - <action 1>
  - <action 2>
  - <action 3>
  (first 3 recommended_actions)
────────────────────────────────────────
```

### Behavior by Mode

| Mode | Action |
|------|--------|
| **SAFE** | Proceed normally to Step 2 |
| **CAUTION** | Proceed, but print: `Recommendation: stay in review_only / patch_plan mode.` |
| **LOCKED** | **STOP.** Print BOOT GUARD block + recovery steps. Do NOT proceed to Step 2. |

### LOCKED Recovery

When LOCKED, end with:
```
BOOT HALTED: Environment not safe for patch operations.
Follow the recommended steps above, then re-run /boot.
```

### Allowed Actions by Mode

| Mode | review_only | patch_plan | patch_apply |
|------|-------------|------------|-------------|
| SAFE | ✓ | ✓ | ✓ |
| CAUTION | ✓ | ✓ | ⚠ (warned) |
| LOCKED | ✓ | ✗ | ✗ |

**Note:** LOCKED mode still allows read-only operations (`review_only`) but blocks any execution modes that could modify state.

---

## Step 2: Identify Active Project (Auto-detect)

### Priority 0: Manual override
If the user says **"no autodetect"** or **"manual project"**, skip auto-detect entirely and always ask which project.

### Priority 1: Explicit user request (with aliases)
If the user explicitly named a project in this thread, obey and skip auto-detect:

| User says | Loader |
|-----------|--------|
| "law", "legal", "scrapers", "leads", "cases" | `/jhornlaw` |
| "distress", "distressed", "real estate", "property", "foreclosure" | `/distress` |
| "dfs", "fantasy", "best ball", "drafts" | `/dfs` |
| "xprediction", "cross-platform", "score shock", "pm to kalshi", "kalshi polymarket" | `/xprediction` |

### Priority 2: Auto-detect from pwd
Get and normalize current working directory:
```powershell
powershell -Command "(Get-Location).Path.ToLower().Replace('/', '\')"
```

**Normalization:**
1. Convert to lowercase
2. Replace `/` with `\`
3. If Git Bash style (`/c/Users/...`), convert to Windows (`c:\users\...`)

**Detection rules (folder boundary OR end-of-path):**
| Normalized pwd matches | Project | Loader |
|------------------------|---------|--------|
| `\the_brain\` or `\the_brain` at end | Law Practice | `/jhornlaw` |
| `\ai_core\` or `\ai_core` at end | Law Practice | `/jhornlaw` |
| `\distress\` or `\distress` at end | Distressed Property | `/distress` |
| `\dfs\` or `\dfs` at end | DFS/Fantasy | `/dfs` |
| `\xprediction\` or `\xprediction` at end | Cross-Platform Trading | `/xprediction` |

**Regex pattern (for reference):** `\\the_brain(\\|$)|\\ai_core(\\|$)|\\xprediction(\\|$)`

If a match is found, run that loader immediately.

## Step 2.5: Install Enforcement Framework (MANDATORY)

**This step is NOT optional.** Every project under /boot gets enforcement installed automatically.

Run from the detected project root:
```bash
cd "<project_root>" && python -c "import sys; sys.path.insert(0, 'C:/Users/J'); from boot.cli import main; sys.argv = ['boot', 'run', '--skip-install']; main()" 2>/dev/null || python -c "import sys; sys.path.insert(0, 'C:/Users/J'); from boot.cli import main; sys.argv = ['boot', 'install']; main()"
```

**If not inside a git repo under /boot:** Skip this step silently (global doctrine still applies from CLAUDE.md).

**If inside a git repo under /boot:**
1. Install/refresh managed enforcement files
2. Compile rules (inbox.md -> rules.yml)
3. Run preflight gate
4. Write audit artifact

**On BLOCK:** Stop and report the blocking issue. Do not proceed to project loader.

**On PASS:** Continue to project loader.

Include in diagnostics:
```
enforcement: installed | <N> rules compiled | preflight PASS
```

### Priority 3: Ask (fail-safe)
If detection is ambiguous or no match, ask:
> Which project are we working on?
> - Law practice automation: `/jhornlaw`
> - Distressed property: `/distress`
> - DFS/fantasy: `/dfs`
> - Cross-platform trading (PM->Kalshi): `/xprediction`
> - Other (name it; we can create a loader)

## Step 2.5: Initialize Token Optimizer (if enabled)

Check if `C:\Users\J\.claude\token-optimizer\config.json` exists.

**If config exists:**
1. Load config and determine workstream budget (use override if workstream matches, else default)
2. Load `C:\Users\J\.claude\token-optimizer\cache\manifest.json`
3. Initialize session in manifest (generate session_id, set started timestamp)
4. Set `token_optimizer_enabled: true`
5. **ACTIVATE REDUCTION RULES** (see below)
6. Note budget and cache hit_rate for diagnostics

**If config does NOT exist:**
- Set `token_optimizer_enabled: false`
- Skip silently (no error, no warning)

### Token Reduction Mechanisms (ENFORCED when optimizer enabled)

**Execute READ DECISION GATE before EVERY Read tool call:**

```
GATE CHECK (mandatory):
1. □ File in manifest.entries? -> Return cached summary, DO NOT Read
2. □ File > 50KB? -> MUST use offset/limit
3. □ File > 200KB? -> MUST grep-first
4. □ Exploration query? -> MUST grep-first if file unknown
```

**After EVERY Read:**
- Generate summary_1l (≤100 chars)
- Write to manifest.entries with source_hash
- Add to current_session.files_read_this_session

**When launching agents:**
- Generate PRELOADED CONTEXT block from manifest
- Include in agent prompt
- Agents MUST NOT re-read listed files

Full gate procedure: `/token_optimizer` -> see "READ DECISION GATE"

## Step 2.6: Load Memory Bundle (Non-Blocking - Phase 4)

**This step loads and surfaces project memory.** Do NOT block boot based on bundle presence/absence.

After project detection, check if memory bundle exists:

```powershell
powershell -Command "Test-Path '<project_path>\.claude\memory'"
```

### If `False` (no bundle): SKIPPED

Set: `bundle_loaded: SKIPPED`

Continue to Step 3.

### If `True` (bundle exists): Load and Parse

**Step 2.6.1: Get bundle metadata**

```powershell
powershell -Command "(Get-ChildItem '<project_path>\.claude\memory\*.md' | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime.ToString('yyyy-MM-dd HH:mm')"
```

**Step 2.6.2: Read primary bundle files**

Target files (in order):
1. `verified.md` - Verified facts (truth source)
2. `decisions.md` - Decisions made
3. `runbook.md` - Failure patterns and fixes

For each file:
- If exists: read content
- If missing/unreadable: note as missing, continue

**Step 2.6.3: Extract recent entries (deterministic)**

For each file, extract the **last N entries** (default N=3):

**Parsing strategy:**
- Split on `### [` (entry header marker from templates)
- Take last N chunks
- Cap each entry at 300 characters
- If split fails (no markers found): fallback to last 10 non-empty lines

**Step 2.6.4: Render MEMORY BUNDLE block**

```
── MEMORY BUNDLE ───────────────────────
status: OK
path: <project_path>\.claude\memory
last_updated: <max mtime across files>

counts:
  verified_recent: <N>
  decisions_recent: <N>
  runbook_recent: <N>

verified (most recent):
  - <fact 1, truncated to 150 chars>...
  - <fact 2>
  - <fact 3>
  (or "none" if empty)

decisions (most recent):
  - <decision 1, truncated>...
  - <decision 2>
  (or "none" if empty)

runbook (most recent):
  - <pattern 1, truncated>...
  (or "none" if empty)
─────────────────────────────────────────
```

**If some files missing/unreadable:**

```
── MEMORY BUNDLE ───────────────────────
status: PARTIAL
path: <project_path>\.claude\memory
last_updated: <max mtime>
missing: verified.md, runbook.md

counts:
  verified_recent: 0 (file missing)
  decisions_recent: 2
  runbook_recent: 0 (file missing)

decisions (most recent):
  - <decision 1>
  - <decision 2>
─────────────────────────────────────────
```

**Step 2.6.5: Set bundle_loaded status**

- `OK`: All primary files loaded successfully
- `PARTIAL`: Some files missing/unreadable
- `SKIPPED`: Bundle directory doesn't exist

This is non-blocking. Absence or partial load does not halt boot.

---

## Step 3: Report Ready

**Always include diagnostics line:**
```
operator_layer: <version from VERSION> | manifest: <verified|unverified|missing>
rehydration: LOADED | age: <N>h | objective: <truncated summary>
guard_mode: SAFE|CAUTION|LOCKED
pwd: <actual path>
project: <auto|explicit|asked>
loader: </jhornlaw|/distress|/dfs|/xprediction|none>
enforcement: <installed | N rules | preflight PASS> OR <not under /boot>
execution_mode: <review_only|patch_plan|patch_apply|emergency>
bundle_loaded: <OK | PARTIAL | SKIPPED> | verified: <N> | decisions: <N> | runbook: <N>
token_optimizer: <enabled | budget: NNK | cache: NN% hit> OR <not configured>
maintenance_last: <N>h | status: <OK|WARN|ERROR> OR <not configured>
```

**Execution modes:**
| Mode | Behavior |
|------|----------|
| `review_only` | Default. Identify issues, no patch plan. |
| `patch_plan` | Produce patch plan, wait for approval. |
| `patch_apply` | Apply patches immediately (Level 3). |
| `emergency` | Critical review only (Security + Concurrency). |

Default is `review_only` unless project loader overrides (e.g., `/jhornlaw` sets `patch_apply`).

Then confirm:
```
===========================================
SESSION: [Day], [Month] [DD], [YYYY] [HH:MM AM/PM]
===========================================
Global doctrine loaded.
Task switches require routing (Tier 1/2). Use /tangent <objective>.
operator_layer: 2026-01-30-p11 | manifest: verified
rehydration: LOADED | age: 4.2h | objective: Plan migration of jhornlaw scrapers...
guard_mode: SAFE
pwd: C:\Users\J\the_brain
project: auto-detected
loader: /jhornlaw
enforcement: installed | 4 rules | preflight PASS
bundle_loaded: OK | verified: 2 | decisions: 1 | runbook: 3
token_optimizer: enabled | budget: 180K | cache: 72% hit | REDUCTION ACTIVE
maintenance_last: 4.2h | status: OK
Ready.

At end of session: run /save_context to persist.
```

**When bundle is loaded, also display the MEMORY BUNDLE block before Ready:**
```
── MEMORY BUNDLE ───────────────────────
status: OK
path: C:\Users\J\the_brain\.claude\memory
last_updated: 2026-01-30 09:15

counts:
  verified_recent: 2
  decisions_recent: 1
  runbook_recent: 3

verified (most recent):
  - API rate limit is 100 req/min (verified 2026-01-29)
  - Supabase connection requires SSL (verified 2026-01-28)

decisions (most recent):
  - Use PostgreSQL over SQLite for scale

runbook (most recent):
  - Chrome crash -> increase shared memory to 2GB
  - Puppeteer timeout -> add explicit waitForSelector
  - Rate limit hit -> implement exponential backoff
─────────────────────────────────────────
```

**If token_optimizer enabled, also display:**
```
TOKEN REDUCTION: read-once | search-first | smart-load | agent-share
```

## Available Commands
- `/jhornlaw` (law practice dual-workspace loader)
- `/distress` (distressed property pipeline)
- `/dfs` (DFS/fantasy sports)
- `/xprediction` (cross-platform PM->Kalshi trading)
- `/kalshi` (Kalshi trading bot)
- `/polymarket` (Polymarket trading bot)
- `/execute_full_plan` (six-lane parallel review)
- `/critical_review` (security + concurrency only)
- `/rules-audit` (compliance audit with dated artifact)
- `/tangent` (force task-switch protocol)
- `/token_optimizer` (token budget, cache status, reduction controls)

---

## Appendix: latest.json Schema Reference

**Path:** `C:\Users\J\.claude\context\latest.json`

**Written by:** `/save_context`
**Read by:** `/boot` (auto-rehydration), `/load_context` (deep restore)

### Required Fields

| Field | Type | Description | If Missing |
|-------|------|-------------|------------|
| `timestamp` | ISO8601 string | When context was saved | Parse fails |

### Optional Fields (graceful fallback)

| Field | Type | Description | If Missing |
|-------|------|-------------|------------|
| `project_loader` | string | Loader command (e.g., "/jhornlaw") | Shows "none" |
| `execution_mode` | string | review_only, patch_plan, patch_apply, emergency | Shows "unknown" |
| `project_path` | string | Absolute path to project root | Shows "unknown" |
| `initiative_level` | number | 1-3 | Not displayed |
| `current_objective` | string | User's stated goal | Shows "none specified" |
| `work_completed` | array of strings | Items completed last session | Shows "none" |
| `next_actions` | array of strings | Pending tasks | Shows "none" |
| `open_questions` | array of strings | Unresolved questions | Shows "none" |
| `files_modified` | array of strings | Files touched last session | Shows "none" |
| `notes` | string | Freeform notes | Shows "none" |

### Backward Compatibility

- New fields may be added by future `/save_context` versions
- Unknown fields are ignored during rehydration
- Missing optional fields render as "none" or "unknown"
- Only malformed JSON (parse failure) blocks boot

---

## Operator Notes

**Canonical spec:** See `C:\Users\J\.claude\RUNBOOK_REHYDRATION.md`
**Install/Update:** See `C:\Users\J\.claude\INSTALLER_README.md`

- `/boot` is a **hard gate**: BLOCKED status halts session until resolved
- Missing `latest.json` → run `/bootstrap_context` first
- Memory bundle is **non-blocking**: SKIPPED/PARTIAL do not halt boot
- Freshness warnings (>24h, >7d) are informational only
- For deep restore with project loader, use `/load_context` after boot
- Version/manifest warnings are non-blocking (diagnostics only)
- **Conflict detection** (Phase 8): Sync conflicts are auto-resolved using newest-wins rule
- All conflict candidates are preserved in `context\CONFLICTS\` with audit trail
- Machine identifier stored in `context\machine_id.txt` (sidecar, not in JSON schema)
- **Scheduled maintenance** (Phase 9): Install with `schedule_maintenance.ps1 -Install`
- Maintenance status shown in diagnostics if configured
- Logs stored in `logs\maintenance\`
