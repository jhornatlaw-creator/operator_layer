# /kalshi-arb - Kalshi Arbitrage Finder

Given a bet on Underdog, find optimal Kalshi positions for arbitrage or hedging.

## Usage

```bash
# Spread bet
python -m xprediction.tools.kalshi_arb_finder TEAM1 TEAM2 --spread "TEAM:SPREAD:ODDS:STAKE"

# Total bet
python -m xprediction.tools.kalshi_arb_finder TEAM1 TEAM2 --total "SIDE:LINE:ODDS:STAKE"
```

## Examples

```bash
# Find arb for Army +2.5 @ -133 ($7.98 stake)
python -m xprediction.tools.kalshi_arb_finder lehigh army --spread "Army:+2.5:-133:7.98"

# Find arb for Over 140.5 @ -110 ($10 stake)
python -m xprediction.tools.kalshi_arb_finder lehigh army --total "over:140.5:-110:10"

# JSON output
python -m xprediction.tools.kalshi_arb_finder lehigh army --spread "Army:+2.5:-133:7.98" --json
```

## Input Formats

**Spread:** `TEAM:SPREAD:ODDS:STAKE`
- `Army:+2.5:-133:7.98` = Army getting 2.5 points, -133 odds, $7.98 stake

**Total:** `SIDE:LINE:ODDS:STAKE`
- `over:140.5:-110:10` = Over 140.5, -110 odds, $10 stake
- `under:150.5:-110:10` = Under 150.5, -110 odds, $10 stake

## Output

The tool will:
1. Search Kalshi for the game
2. Analyze all spread/total markets
3. Find arbitrage opportunities (guaranteed profit)
4. Find hedge opportunities (reduced risk)
5. Show recommended action with exact contracts and price

```
======================================================================
  KALSHI ARB FINDER
======================================================================

Your Underdog bet: underdog: Army +2.5
  Stake: $7.98
  Payout: $13.98
  Profit if win: $6.00

----------------------------------------------------------------------
ARBITRAGE OPPORTUNITIES (guaranteed profit):
----------------------------------------------------------------------

  KXNCAAMBSPREAD-26JAN28LEHARMY-LEH1 [ARB]
  Lehigh wins by over 1.5 Points?
  Action: Buy YES @ 38c x 13 contracts
  Stake: $4.94
  P&L Range: $0.08 to $14.06
  Scenarios:
    Lehigh wins by 3+: $+0.08
    Lehigh wins by 2: $+14.06
    Army wins or close: $+1.06
```

## How Arbs Work

**Spreads:**
- +X and -X are NOT exact opposites (gap/overlap exists)
- Army +2.5 wins if margin > -2.5
- Lehigh -1.5 wins if Lehigh margin > 1.5 (Army margin < -1.5)
- Overlap at "Lehigh wins by 2" where both hit

**Totals:**
- Over 140.5 + Under 141.5 overlap at total = 141
- Both bets win in the overlap
- Prices must be inefficient enough for arb

## Workflow

1. Place bet on Underdog
2. Run this tool immediately
3. If ARB found → execute Kalshi trade
4. If no arb → check hedge opportunities or let it ride

## Related Tools

- `/find-ncaab-game` - Find NCAAB markets on Kalshi
- `/spread-arb` - Manual spread analysis (no Kalshi lookup)
