<#
.SYNOPSIS
    Install the Claude Code operator layer.

.DESCRIPTION
    One-command installer for the operator layer at C:\Users\J\.claude\.
    Creates directory structure, copies managed files, generates manifest.

    Idempotent: safe to re-run. Will not delete user state (context\).

.PARAMETER Source
    Source of operator layer files. Can be:
    - Local path (e.g., C:\source\operator_layer)
    - Git repository URL (requires git installed)

.PARAMETER ReleaseUrl
    URL or local path to a release zip file (operator_layer_<version>.zip).
    Alternative to -Source. The zip must contain operator_layer_manifest.json.

.PARAMETER ExpectedHash
    Expected SHA256 hash of the release zip (for -ReleaseUrl).

.PARAMETER Target
    Target installation directory. Default: C:\Users\J\.claude

.PARAMETER Force
    Overwrite existing managed files without prompting.

.PARAMETER SkipVerify
    Skip post-install manifest verification.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -Source C:\source\operator_layer
    # Install from local source

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -Source https://github.com/user/operator-layer.git
    # Install from git repository

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl C:\releases\operator_layer_p10.zip
    # Install from release zip

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -ReleaseUrl https://example.com/release.zip -ExpectedHash abc123...
    # Install from URL with hash verification

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -Source . -Force
    # Reinstall from current directory, overwriting existing

.NOTES
    operator_layer_version: 2026-01-30-p10

    MANAGED FILES (installed/updated):
    - commands\*.md
    - lib\*.ps1
    - RUNBOOK_REHYDRATION.md
    - CHANGELOG_OPERATOR_LAYER.md
    - INSTALLER_README.md
    - VERSION
    - operator_layer_manifest.json
    - install.ps1, update.ps1, release.ps1

    UNMANAGED (never touched):
    - context\* (user session state)
    - CLAUDE.md (user global config)
    - rules\* (user rules)
    - Any .env or credential files

    SAFETY:
    - Release installs verify zip integrity + manifest before writing any files
    - context\ is protected and never modified
#>

param(
    [Parameter(Mandatory=$false)]
    [string]$Source,

    [string]$ReleaseUrl,

    [string]$ExpectedHash,

    [string]$Target = "C:\Users\J\.claude",

    [switch]$Force,

    [switch]$SkipVerify
)

# Managed file patterns (relative to .claude root)
$ManagedPatterns = @(
    "commands\*.md",
    "lib\*.ps1",
    "RUNBOOK_REHYDRATION.md",
    "CHANGELOG_OPERATOR_LAYER.md",
    "INSTALLER_README.md",
    "VERSION"
)

# Files to never touch
$ProtectedPaths = @(
    "context",
    "CLAUDE.md",
    "rules"
)

function Write-Header($text) {
    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor White
    Write-Host "  $text" -ForegroundColor White
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor White
}

function Write-Status($status, $msg) {
    switch ($status) {
        "OK"   { Write-Host "[OK]   $msg" -ForegroundColor Green }
        "SKIP" { Write-Host "[SKIP] $msg" -ForegroundColor Yellow }
        "FAIL" { Write-Host "[FAIL] $msg" -ForegroundColor Red }
        "INFO" { Write-Host "[INFO] $msg" -ForegroundColor Gray }
        "COPY" { Write-Host "[COPY] $msg" -ForegroundColor Cyan }
    }
}

function Get-FileHash256($path) {
    if (-not (Test-Path $path)) { return $null }
    return (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLower()
}

function Test-IsGitUrl($str) {
    return $str -match "^(https?://|git@|git://)" -or $str -match "\.git$"
}

function Get-SourceFiles($sourcePath) {
    $files = @()

    foreach ($pattern in $ManagedPatterns) {
        $searchPath = Join-Path $sourcePath $pattern
        $matches = Get-ChildItem -Path $searchPath -ErrorAction SilentlyContinue

        foreach ($file in $matches) {
            # Get relative path from source root
            $relativePath = $file.FullName.Substring($sourcePath.Length + 1)
            $files += @{
                SourcePath = $file.FullName
                RelativePath = $relativePath
                Bytes = $file.Length
            }
        }
    }

    return $files
}

# ============================================================
# MAIN
# ============================================================

Write-Header "OPERATOR LAYER INSTALLER"
Write-Host "  Version: 2026-01-30-p10" -ForegroundColor Gray
Write-Host "  Target: $Target" -ForegroundColor Gray

# ── Handle -ReleaseUrl (takes precedence over -Source) ──
if ($ReleaseUrl) {
    Write-Host "  Source: $ReleaseUrl (release zip)" -ForegroundColor Gray
    Write-Host ""

    # Safety check: ensure context\ is not inadvertently targeted
    $contextPath = Join-Path $Target "context"
    if ($Target -like "*\context*" -or $Target -like "*\context") {
        Write-Host "ERROR: Target path appears to be inside context\. Refusing to operate." -ForegroundColor Red
        exit 1
    }

    # Download and verify release
    $downloadScript = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "lib\download_release.ps1"

    if (-not (Test-Path $downloadScript)) {
        # Try relative to target
        $downloadScript = Join-Path $Target "lib\download_release.ps1"
    }

    if (-not (Test-Path $downloadScript)) {
        Write-Host "ERROR: download_release.ps1 not found. Cannot install from release URL." -ForegroundColor Red
        Write-Host "Install from source first, then use -ReleaseUrl for updates." -ForegroundColor Yellow
        exit 1
    }

    Write-Host "── Downloading and verifying release ──" -ForegroundColor Cyan

    $downloadParams = @{
        Url = $ReleaseUrl
    }
    if ($ExpectedHash) {
        $downloadParams.ExpectedHash = $ExpectedHash
    }

    $downloadResult = & $downloadScript @downloadParams

    if (-not $downloadResult.Success) {
        Write-Host ""
        Write-Host "INSTALL: FAILED" -ForegroundColor Red
        Write-Host "  Error: $($downloadResult.Error)" -ForegroundColor Red
        Write-Host ""
        Write-Host "  Release verification failed. No files were modified." -ForegroundColor Yellow
        exit 1
    }

    # Use extracted release as source
    $actualSource = $downloadResult.ExtractPath
    $releaseCleanup = $downloadResult.ExtractPath

    Write-Host ""
    Write-Host "── Installing from verified release ──" -ForegroundColor Cyan
    Write-Status "OK" "Release verified: $($downloadResult.ZipHash.Substring(0, 16))..."
    Write-Status "INFO" "Extract path: $actualSource"

    # Continue with installation from extracted source
    # (falls through to normal install logic below)
    $Source = $actualSource
}

# Handle no source (self-install mode)
if (-not $Source) {
    # Check if we're already in an operator layer directory
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

    if (Test-Path (Join-Path $scriptDir "VERSION")) {
        $Source = $scriptDir
        Write-Host "  Source: $Source (self-install)" -ForegroundColor Gray
    } else {
        Write-Host ""
        Write-Host "ERROR: -Source parameter required" -ForegroundColor Red
        Write-Host ""
        Write-Host "Usage:" -ForegroundColor Yellow
        Write-Host "  install.ps1 -Source <path_or_git_url>" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Examples:" -ForegroundColor Yellow
        Write-Host "  install.ps1 -Source C:\source\operator_layer" -ForegroundColor Gray
        Write-Host "  install.ps1 -Source https://github.com/user/repo.git" -ForegroundColor Gray
        Write-Host "  install.ps1 -Source .  # Install from current directory" -ForegroundColor Gray
        exit 1
    }
}

# Resolve source
$tempDir = $null
$actualSource = $Source

if (Test-IsGitUrl $Source) {
    Write-Host "  Source: $Source (git)" -ForegroundColor Gray
    Write-Host ""

    # Check git is available
    $gitPath = Get-Command git -ErrorAction SilentlyContinue
    if (-not $gitPath) {
        Write-Host "ERROR: git not found. Install git or use a local source path." -ForegroundColor Red
        exit 1
    }

    # Clone to temp
    $tempDir = Join-Path $env:TEMP "operator_layer_install_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    Write-Status "INFO" "Cloning to temp: $tempDir"

    try {
        git clone --depth 1 $Source $tempDir 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "git clone failed" }
    } catch {
        Write-Status "FAIL" "Git clone failed: $_"
        exit 1
    }

    # Look for .claude subfolder or use root
    if (Test-Path (Join-Path $tempDir ".claude")) {
        $actualSource = Join-Path $tempDir ".claude"
    } else {
        $actualSource = $tempDir
    }
} else {
    # Local path
    $actualSource = (Resolve-Path $Source -ErrorAction SilentlyContinue).Path

    if (-not $actualSource -or -not (Test-Path $actualSource)) {
        Write-Host "ERROR: Source path not found: $Source" -ForegroundColor Red
        exit 1
    }

    Write-Host "  Source: $actualSource (local)" -ForegroundColor Gray
}

Write-Host ""

# ── Step 1: Ensure target directories exist ──
Write-Host "── Creating directories ──" -ForegroundColor Cyan

$directories = @("", "commands", "lib", "context")
foreach ($dir in $directories) {
    $fullPath = Join-Path $Target $dir
    if (-not (Test-Path $fullPath)) {
        New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
        Write-Status "OK" "Created: $dir\"
    } else {
        Write-Status "SKIP" "Exists: $dir\"
    }
}

# ── Step 2: Get list of files to install ──
Write-Host ""
Write-Host "── Scanning source files ──" -ForegroundColor Cyan

$sourceFiles = Get-SourceFiles $actualSource

if ($sourceFiles.Count -eq 0) {
    Write-Status "FAIL" "No managed files found in source"
    exit 1
}

Write-Status "INFO" "Found $($sourceFiles.Count) managed files"

# ── Step 3: Copy managed files ──
Write-Host ""
Write-Host "── Installing files ──" -ForegroundColor Cyan

$installed = @()
$skipped = 0

foreach ($file in $sourceFiles) {
    $targetPath = Join-Path $Target $file.RelativePath
    $targetDir = Split-Path -Parent $targetPath

    # Ensure parent directory exists
    if (-not (Test-Path $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    # Check if source and target are the same file (self-install to same location)
    $sourceFull = (Resolve-Path $file.SourcePath -ErrorAction SilentlyContinue).Path
    $targetFull = $targetPath
    if ($sourceFull -eq $targetFull) {
        Write-Status "SKIP" "$($file.RelativePath) (same location)"
        $skipped++
        $installed += $file
        continue
    }

    # Check if file exists and whether to overwrite
    $exists = Test-Path $targetPath
    $shouldCopy = $Force -or (-not $exists)

    if (-not $shouldCopy -and $exists) {
        # Check if content differs
        $sourceHash = Get-FileHash256 $file.SourcePath
        $targetHash = Get-FileHash256 $targetPath

        if ($sourceHash -eq $targetHash) {
            Write-Status "SKIP" "$($file.RelativePath) (unchanged)"
            $skipped++
            $installed += $file
            continue
        } else {
            # Different content, need Force or prompt
            Write-Status "SKIP" "$($file.RelativePath) (differs, use -Force to overwrite)"
            $skipped++
            continue
        }
    }

    # Copy file
    try {
        Copy-Item -Path $file.SourcePath -Destination $targetPath -Force
        Write-Status "COPY" $file.RelativePath
        $installed += $file
    } catch {
        Write-Status "FAIL" "$($file.RelativePath): $_"
    }
}

# ── Step 4: Generate manifest ──
Write-Host ""
Write-Host "── Generating manifest ──" -ForegroundColor Cyan

$manifestFiles = @()
foreach ($file in $installed) {
    $targetPath = Join-Path $Target $file.RelativePath
    $hash = Get-FileHash256 $targetPath
    $size = (Get-Item $targetPath).Length

    $manifestFiles += @{
        path = $file.RelativePath
        sha256 = $hash
        bytes = $size
    }
}

# Add manifest itself (will be written after)
$manifestPath = Join-Path $Target "operator_layer_manifest.json"

$manifest = @{
    version = (Get-Content (Join-Path $Target "VERSION") -Raw).Trim()
    generated_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
    source = $Source
    files = $manifestFiles
}

$manifest | ConvertTo-Json -Depth 10 | Set-Content $manifestPath -Encoding UTF8
Write-Status "OK" "Wrote operator_layer_manifest.json"

# ── Step 5: Verify installation ──
if (-not $SkipVerify) {
    Write-Host ""
    Write-Host "── Verifying installation ──" -ForegroundColor Cyan

    $verifyScript = Join-Path $Target "lib\verify_manifest.ps1"
    $targetManifestPath = Join-Path $Target "operator_layer_manifest.json"
    if (Test-Path $verifyScript) {
        & powershell -ExecutionPolicy Bypass -File $verifyScript -ManifestPath $targetManifestPath -BasePath $Target -Quiet
        if ($LASTEXITCODE -eq 0) {
            Write-Status "OK" "Manifest verified"
        } else {
            Write-Status "FAIL" "Manifest verification failed"
        }
    } else {
        Write-Status "SKIP" "Verifier not found (new install)"
    }
}

# ── Step 6: Cleanup ──
if ($tempDir -and (Test-Path $tempDir)) {
    Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}

# Cleanup release extract directory if we used -ReleaseUrl
if ($releaseCleanup -and (Test-Path $releaseCleanup)) {
    Remove-Item -Recurse -Force $releaseCleanup -ErrorAction SilentlyContinue
}

# ── Summary ──
Write-Header "INSTALL COMPLETE"

$version = (Get-Content (Join-Path $Target "VERSION") -Raw).Trim()

Write-Host "  Status: OK" -ForegroundColor Green
Write-Host "  Version: $version" -ForegroundColor Gray
Write-Host "  Files installed: $($installed.Count)" -ForegroundColor Gray
Write-Host "  Files skipped: $skipped" -ForegroundColor Gray
Write-Host "  Target: $Target" -ForegroundColor Gray
Write-Host ""
Write-Host "  Context preserved: $Target\context\ (not touched)" -ForegroundColor Yellow
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run /boot in Claude Code to verify" -ForegroundColor Gray
Write-Host "  2. Run verify_manifest.ps1 to check integrity" -ForegroundColor Gray
Write-Host ""

exit 0
