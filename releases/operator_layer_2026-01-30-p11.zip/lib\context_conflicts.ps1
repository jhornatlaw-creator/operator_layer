<#
.SYNOPSIS
    Detect and resolve context file conflicts from multi-machine sync.

.DESCRIPTION
    Scans context directory for multiple "latest" candidates (sync conflicts),
    validates JSON, ranks by timestamp, preserves all candidates, and optionally
    normalizes latest.json to the winning file.

    Compatible with OneDrive, Dropbox, and other sync tools that create
    "conflicted copy" or "(1)" variants.

.PARAMETER ContextDir
    Path to context directory. Default: C:\Users\J\.claude\context

.PARAMETER Normalize
    If set, overwrites latest.json with winner content (atomic).

.PARAMETER StaleThresholdMinutes
    Minutes after which latest.json is considered stale vs newest archive.
    Default: 5

.PARAMETER Quiet
    Suppress detailed output, return structured object only.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File context_conflicts.ps1
    # Check for conflicts, preserve artifacts, report status

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File context_conflicts.ps1 -Normalize
    # Check and normalize latest.json to winner if conflict detected

.NOTES
    operator_layer_version: 2026-01-30-p8

    Exit codes:
    0 = NO_CONFLICT (single valid latest.json, not stale)
    1 = CONFLICT_RESOLVED (conflicts detected and preserved)
    2 = ERROR (unrecoverable error)
#>

param(
    [string]$ContextDir = "C:\Users\J\.claude\context",
    [switch]$Normalize,
    [int]$StaleThresholdMinutes = 5,
    [switch]$Quiet
)

# ============================================================
# HELPER FUNCTIONS
# ============================================================

function Write-Status($status, $msg) {
    if ($Quiet) { return }
    switch ($status) {
        "INFO"  { Write-Host "[INFO]  $msg" -ForegroundColor Gray }
        "WARN"  { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }
        "OK"    { Write-Host "[OK]    $msg" -ForegroundColor Green }
        "FAIL"  { Write-Host "[FAIL]  $msg" -ForegroundColor Red }
        "FOUND" { Write-Host "[FOUND] $msg" -ForegroundColor Cyan }
    }
}

function Get-JsonTimestamp($path) {
    # Returns parsed timestamp or $null if invalid/missing
    try {
        $content = Get-Content $path -Raw -ErrorAction Stop
        $json = $content | ConvertFrom-Json -ErrorAction Stop
        if ($json.timestamp) {
            $parsed = [DateTime]::Parse($json.timestamp)
            return $parsed
        }
    } catch {
        # Invalid JSON or missing timestamp
    }
    return $null
}

function Get-CandidateInfo($file) {
    $info = @{
        filename = $file.Name
        path = $file.FullName
        mtime = $file.LastWriteTime
        valid = $false
        timestamp = $null
        timestamp_parsed = $null
    }

    $ts = Get-JsonTimestamp $file.FullName
    if ($ts) {
        $info.valid = $true
        $info.timestamp_parsed = $ts
        # Read raw timestamp string for display
        try {
            $json = Get-Content $file.FullName -Raw | ConvertFrom-Json
            $info.timestamp = $json.timestamp
        } catch {}
    }

    return $info
}

# ============================================================
# MAIN
# ============================================================

if (-not (Test-Path $ContextDir)) {
    Write-Status "FAIL" "Context directory not found: $ContextDir"
    exit 2
}

# ── Step 1: Enumerate candidates ──
$candidates = @()

# Pattern 1: latest.json and variants
$latestVariants = Get-ChildItem -Path $ContextDir -Filter "latest*.json" -ErrorAction SilentlyContinue

# Pattern 2: Sync conflict patterns (OneDrive, Dropbox, etc.)
$conflictPatterns = @(
    "*conflicted*copy*.json",
    "*conflict*.json",
    "* - Copy*.json",
    "* (1).json",
    "* (2).json",
    "* (3).json"
)

$conflictFiles = @()
foreach ($pattern in $conflictPatterns) {
    $matches = Get-ChildItem -Path $ContextDir -Filter $pattern -ErrorAction SilentlyContinue
    $conflictFiles += $matches
}

# Combine and deduplicate
$allFiles = @()
$allFiles += $latestVariants
$allFiles += $conflictFiles
$uniqueFiles = $allFiles | Sort-Object FullName -Unique

foreach ($file in $uniqueFiles) {
    # Skip archives (session_*.json)
    if ($file.Name -match "^session_") { continue }

    $info = Get-CandidateInfo $file
    $candidates += $info

    $validStr = if ($info.valid) { "valid" } else { "INVALID" }
    Write-Status "FOUND" "$($info.filename) [$validStr] mtime=$($info.mtime.ToString('yyyy-MM-dd HH:mm:ss'))"
}

# ── Step 2: Check for stale latest.json vs archives ──
$latestCandidate = $candidates | Where-Object { $_.filename -eq "latest.json" } | Select-Object -First 1
$newestArchive = $null

if ($latestCandidate -and $latestCandidate.valid) {
    # Find newest valid archive
    $archives = Get-ChildItem -Path $ContextDir -Filter "session_*.json" -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending

    foreach ($archive in $archives) {
        $archiveTs = Get-JsonTimestamp $archive.FullName
        if ($archiveTs) {
            $newestArchive = @{
                filename = $archive.Name
                path = $archive.FullName
                mtime = $archive.LastWriteTime
                valid = $true
                timestamp_parsed = $archiveTs
            }
            break
        }
    }

    # Check if stale
    if ($newestArchive -and $latestCandidate.timestamp_parsed -and $newestArchive.timestamp_parsed) {
        $ageDiff = ($newestArchive.timestamp_parsed - $latestCandidate.timestamp_parsed).TotalMinutes

        if ($ageDiff -gt $StaleThresholdMinutes) {
            Write-Status "WARN" "latest.json is stale: $([int]$ageDiff) minutes older than newest archive"

            # Add newest archive as a candidate for resolution
            $archiveInfo = Get-CandidateInfo (Get-Item $newestArchive.path)
            $candidates += $archiveInfo
            Write-Status "FOUND" "$($archiveInfo.filename) [valid, promoted from archive]"
        }
    }
}

# ── Step 3: Determine if conflict exists ──
$validCandidates = $candidates | Where-Object { $_.valid }
$hasConflict = ($candidates.Count -gt 1)

if (-not $hasConflict) {
    Write-Status "OK" "No conflict detected (single candidate)"

    # Return structured result
    $result = @{
        detected = $false
        winner_path = if ($latestCandidate) { $latestCandidate.path } else { $null }
        candidates = $candidates
        reason = "single_candidate"
        normalized = $false
        preserved_path = $null
    }

    if (-not $Quiet) {
        Write-Host ""
        Write-Host "CONFLICT_STATUS: NONE" -ForegroundColor Green
    }

    exit 0
}

# ── Step 4: Rank candidates (deterministic) ──
Write-Status "INFO" "Ranking $($validCandidates.Count) valid candidates..."

# Sort by: timestamp_parsed DESC, mtime DESC, filename ASC
$ranked = $validCandidates | Sort-Object -Property @(
    @{ Expression = { $_.timestamp_parsed }; Descending = $true },
    @{ Expression = { $_.mtime }; Descending = $true },
    @{ Expression = { $_.filename }; Descending = $false }
)

$winner = $ranked | Select-Object -First 1
$ruleUsed = "timestamp_newest"

# Determine which rule was decisive
if ($ranked.Count -ge 2) {
    $second = $ranked | Select-Object -Skip 1 -First 1
    if ($winner.timestamp_parsed -eq $second.timestamp_parsed) {
        if ($winner.mtime -ne $second.mtime) {
            $ruleUsed = "mtime_newest"
        } else {
            $ruleUsed = "filename_lexical"
        }
    }
}

Write-Status "OK" "Winner: $($winner.filename) (rule: $ruleUsed)"

# ── Step 5: Preserve all candidates ──
$nowStamp = Get-Date -Format "yyyyMMdd_HHmmss"
$conflictsDir = Join-Path $ContextDir "CONFLICTS"
$preserveDir = Join-Path $conflictsDir $nowStamp

# Create preservation directory
if (-not (Test-Path $conflictsDir)) {
    New-Item -ItemType Directory -Path $conflictsDir -Force | Out-Null
}
New-Item -ItemType Directory -Path $preserveDir -Force | Out-Null

Write-Status "INFO" "Preserving candidates to: CONFLICTS\$nowStamp\"

foreach ($candidate in $candidates) {
    $destPath = Join-Path $preserveDir $candidate.filename
    Copy-Item -Path $candidate.path -Destination $destPath -Force
    Write-Status "INFO" "  Preserved: $($candidate.filename)"
}

# Write resolution.json
$resolution = @{
    resolved_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
    winner = @{
        filename = $winner.filename
        path = $winner.path
        timestamp = $winner.timestamp
        mtime = $winner.mtime.ToString("yyyy-MM-ddTHH:mm:ss")
    }
    rule_used = $ruleUsed
    candidates = @()
    normalized = $false
}

foreach ($candidate in $candidates) {
    $resolution.candidates += @{
        filename = $candidate.filename
        valid = $candidate.valid
        timestamp = $candidate.timestamp
        mtime = $candidate.mtime.ToString("yyyy-MM-ddTHH:mm:ss")
        is_winner = ($candidate.filename -eq $winner.filename)
    }
}

# ── Step 6: Normalize if requested ──
$latestPath = Join-Path $ContextDir "latest.json"

if ($Normalize -and ($winner.path -ne $latestPath)) {
    Write-Status "INFO" "Normalizing latest.json to winner..."

    try {
        # Atomic write: copy to temp, then move
        $tempPath = Join-Path $ContextDir "latest.json.conflict_resolve.tmp"
        Copy-Item -Path $winner.path -Destination $tempPath -Force
        Move-Item -Path $tempPath -Destination $latestPath -Force

        $resolution.normalized = $true
        Write-Status "OK" "Normalized latest.json to $($winner.filename)"
    } catch {
        Write-Status "FAIL" "Normalization failed: $_"
    }
} elseif ($winner.path -eq $latestPath) {
    Write-Status "INFO" "Winner is already latest.json, no normalization needed"
}

# Write resolution.json
$resolutionPath = Join-Path $preserveDir "resolution.json"
$resolution | ConvertTo-Json -Depth 10 | Set-Content $resolutionPath -Encoding UTF8
Write-Status "OK" "Wrote resolution.json"

# ── Summary ──
if (-not $Quiet) {
    Write-Host ""
    Write-Host "-------------------------------------------------------" -ForegroundColor Gray
    Write-Host "CONFLICT_STATUS: RESOLVED" -ForegroundColor Yellow
    Write-Host "  Winner: $($winner.filename)" -ForegroundColor Green
    Write-Host "  Rule: $ruleUsed" -ForegroundColor Gray
    Write-Host "  Candidates: $($candidates.Count)" -ForegroundColor Gray
    Write-Host "  Preserved: CONFLICTS\$nowStamp\" -ForegroundColor Gray
    Write-Host "  Normalized: $($resolution.normalized)" -ForegroundColor Gray
}

exit 1
