---
name: sports-arb
description: Load sports arbitrage context for PM → Kalshi trading
---

# /sports-arb - Cross-Platform Sports Arbitrage

Load the sports arbitrage workspace for trading NBA/NFL/MLB games across Polymarket and Kalshi.

## Workspace

| Item | Path |
|------|------|
| xprediction | `C:\Users\J\xprediction` |
| kalshi | `C:\Users\J\kalshi` |
| polymarket | `C:\Users\J\polymarket` |

## Boot Sequence

1. Read `C:\Users\J\xprediction\STATE.md`
2. Check git status for all three repos
3. Run xprediction tests: `cd C:\Users\J\xprediction && python -m pytest tests/ -q`

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    SPORTS ARBITRAGE                         │
├─────────────────────────────────────────────────────────────┤
│  Polymarket (Emitter)                                       │
│    pm.sports.SignalEmitter  → watches PM orderbooks         │
│    pm.sports.find_market_matches → PM ↔ Kalshi mapping      │
├─────────────────────────────────────────────────────────────┤
│  xprediction (Shared Data)                                  │
│    xprediction.signals.SqliteSignalStore → signal bus       │
│    xprediction.sports.BallDontLieClient → live scores       │
│    xprediction.arb.models → fee calculations                │
├─────────────────────────────────────────────────────────────┤
│  Kalshi (Consumer)                                          │
│    kalshi.sports.CrossPlatformSignal → consumes signals     │
│    kalshi.runner → executes trades                          │
└─────────────────────────────────────────────────────────────┘
```

## Fee Calculations

**Kalshi**: 7% × P × (1-P) taker, 1.75% × P × (1-P) maker
- At 50¢: 1.75¢ taker, 0.4375¢ maker
- At 3¢: 0.2037¢ taker

**Polymarket US Sports**: 0.10% flat taker fee

**Sportsbooks**: Vig is EMBEDDED in American odds (no additional fee)
- -110/-110 = 4.5% vig already priced in

## Key Modules

### From Polymarket (emitter side)
```python
from pm.sports import (
    SignalEmitter,
    SignalEmitterConfig,
    find_market_matches,
    get_lineups_once,
    SqliteSignalStore,
)
```

### From Kalshi (consumer side)
```python
from kalshi.sports import CrossPlatformSignal
from xprediction.signals import SqliteSignalStore

store = SqliteSignalStore("./signals.db")
signal = CrossPlatformSignal(ticker="KXNBAGAME-...", signal_store=store)
result = signal.get_signal(kalshi_mid_cents)  # BUY/SELL/HOLD
```

### From xprediction (shared)
```python
from xprediction.arb.models import (
    calc_kalshi_fee_cents,
    calc_polymarket_fee_cents,
    round_to_tenth_cent,
)
from xprediction.sports import BallDontLieClient, get_lineups_once
```

## Staleness Filtering

Live game odds older than 75 seconds are rejected. the-odds-api returns `last_update` per bookmaker.

```python
from xprediction.arb.detector import ArbitrageDetector

detector = ArbitrageDetector(max_odds_age_seconds=75)
```

## CLI Commands

```powershell
# Polymarket side - emit signals
cd C:\Users\J\polymarket
pm xp-emit --mapping ./mapping.yaml --store ./signals.db

# Kalshi side - run with signals
cd C:\Users\J\kalshi
kalshi run-paper KXNBAGAME-... --signal-store ./signals.db

# List live games for pilot
cd C:\Users\J\xprediction
python -m xprediction.pilot.score_pilot --list-games
```

## Safety Rules

### NEVER
- Compare stale sportsbook odds to live exchange odds
- Add vig to sportsbook calculations (already embedded)
- Round fees until final display (use exact floats)

### ALWAYS
- Check `last_update` timestamp on sportsbook odds
- Reject odds older than 75 seconds during live games
- Round to 1/10 penny (0.1 cent) for display only
