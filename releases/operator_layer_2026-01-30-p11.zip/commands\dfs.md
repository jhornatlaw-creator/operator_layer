---
name: dfs
description: Load DFS framework for NFL/MLB best ball drafts
---

# /dfs - Daily Fantasy Sports Framework

Load the DFS architectural framework for contest-based draft/lineup optimization.

## CRITICAL: Date Anchor

**ALWAYS run this command at session start to establish temporal context.**

Before any work, execute:
```bash
powershell -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss'"
```

This establishes the TRUE current date. Use this to:
- Determine which sports season we're in (NFL: Sept-Feb, MLB: Apr-Oct)
- Know if we're pre-season (drafting) or in-season (results available)
- Correctly interpret file timestamps (system clock may be wrong)
- Understand what data is available vs pending

### Current Season Context
- **NFL 2024 Season**: Sept 2024 - Feb 2025 (Week 17 = late Dec 2024)
- **BBM VI (2025-26)**: Drafting NOW, plays NFL 2025 season (Sept 2025)
- **MLB 2025**: Drafts start ~March 2025, season Apr-Oct 2025

## Workspaces

| Workspace | Path | Sport | Role |
|-----------|------|-------|------|
| ud_bestball_mania | `C:\Users\J\ud_bestball_mania` | NFL | Underdog BBM VI (2025-26) |
| bestball_brain | `C:\Users\J\bestball_brain` | MLB | Data collection, normalization, snapshots |
| maddux | `C:\Users\J\maddux` | MLB | Decision engine, valuation, optimization |
| dk_playoff_bestball | `C:\Users\J\dk_playoff_bestball` | NFL | DraftKings playoff best ball engine |

## Boot Sequence

### NFL (Underdog BBM)
1. Run date check: `powershell -Command "Get-Date -Format 'yyyy-MM-dd'"`
2. Read `C:\Users\J\ud_bestball_mania\STATE.md`
3. Read `C:\Users\J\ud_bestball_mania\DOCTRINE.md`

### MLB (Underdog)
4. Read `C:\Users\J\bestball_brain\STATE.md`
5. Read `C:\Users\J\bestball_brain\DOCTRINE.md`
6. Read `C:\Users\J\maddux\STATE.md` (if exists)
7. Read `C:\Users\J\maddux\DOCTRINE.md` (if exists)

### NFL (DraftKings)
8. Read `C:\Users\J\dk_playoff_bestball\STATE.md` (if exists)
9. Read `C:\Users\J\dk_playoff_bestball\DOCTRINE.md` (if exists)

## Available Data by Date

### NFL Stats (nfl-data-py)
| Data | Available | Updates |
|------|-----------|---------|
| 2024 weekly stats | NOW | Weekly through Feb 2025 |
| 2023 weekly stats | NOW | Complete |
| 2025 weekly stats | Sept 2025 | After games played |

### BBM Draft Data
| File | Period | Status |
|------|--------|--------|
| best_ball_mania_vi_rd1.csv | BBM VI 2025-26 | Active drafts |
| best_ball_mania_v_rd1/rd2.csv | BBM V 2024-25 | Complete |
| best_ball_mania_iv_*.csv | BBM IV 2023-24 | Complete |

## Locked Doctrine (Framework Core)

### State-Based Replacement
```
R(S, t) = E[BestSurvivor for slot S at time t_next]
```
- Replacement is a function of STATE, not static lookup
- Variables: position in sequence, gap to next action, board composition, scarcity pressure, need state

### Decision Physics
```
Surplus    = Value - EV_wait
Urgency    = 1 - P_survive
AdjValue   = Surplus - OpportunityCost + UrgencyBonus + CorrelationBonus
```
- EV_wait derives FROM replacement (same engine)

### Empirical Rules (BBM IV + V validated)
- Team record ≠ stack success (r = 0.13 to 0.36)
- RB rooms (3+) = AVOID (6-7% advance)
- Pass rooms (4+ WR/TE) with QB = +EV (16-20%)
- 5+ from 2 teams = consistent +2-3% edge
- QB timing: R1-2 OR R12+ (never R3-11)
- Ownership death zone: 5-8%

### Bounded Adjustments
- Additive in value space (not multiplicative)
- Hard caps prevent any factor from dominating
- Two-sided: bonuses AND penalties
- Every component visible and auditable

### Post-Hoc Optimization
- Selection happens AFTER outcomes resolve
- Optimize for probability of insertion, not "starting lineup"

## Module Map

```
DATA BRAIN                          DECISION ENGINE
├── scrapers/                       ├── scoring.py      (contest rules)
│   └── nfl_stats.py (nfl-data-py) ├── lineup.py       (selection model)
├── normalize/                      ├── valuation.py    (PAR/MBV)
│   ├── player_resolver.py (IDs)   ├── replacement.py  (R(S,t) DOCTRINE)
│   └── projections.py (points)    ├── decision.py     (take vs wait)
├── analysis/                       ├── stacking.py     (correlation)
│   ├── advanced_insights.py       ├── scarcity.py     (tier cliffs)
│   ├── stack_record_correlation.py├── optimizer.py    (constraints)
│   └── position_room_stacks.py    ├── portfolio.py    (exposure mgmt)
└── data/snapshots/                 └── audit.py        (explainability)
```

## Contest Variants

| Platform | Sport | Structure | Status |
|----------|-------|-----------|--------|
| Underdog | NFL | Best Ball Mania VI (2025-26) | ACTIVE DRAFTS |
| Underdog | MLB | Best ball draft (post-hoc selection) | Off-season |
| DraftKings | NFL | Playoff best ball draft | Active |

## Operating Rules

1. **DATE FIRST** — Always establish current date before work
2. Load all relevant workspaces before work
3. Doctrine tests enforce invariants
4. State-based, not static
5. Bounded, auditable adjustments
6. Plain English + proof — explainability required

## Quick Reference

### NFL (Underdog BBM)
- State: `ud_bestball_mania/STATE.md`
- Doctrine: `ud_bestball_mania/DOCTRINE.md`
- NFL stats: `from scrapers.nfl_stats import get_weekly_data`
- Analysis: `python -m analysis.<module_name>`
- Test suite: `pytest ud_bestball_mania/tests/`

### MLB (Underdog)
- Snapshot location: `bestball_brain/data/snapshots/`
- Live draft CLI: `python -m apps.live_draft`
- Test suite: `pytest maddux/tests/`

### NFL (DraftKings)
- Rules: `dk_playoff_bestball/rules/dk_playoff_best_ball.json`
- CLI: `python -m maddux.apps.cli --rules rules/dk_playoff_best_ball.json --snapshot snapshots/demo`
- Test suite: `pytest dk_playoff_bestball/tests/`
